import { Routes } from '@angular/router';

/**
 * Configurazione delle routes dell'applicazione
 * Tutte le route usano lazy loading per ottimizzare le performance
 */
export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./components/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'observable-basics',
    loadComponent: () => import('./components/observable-basics/observable-basics.component').then(m => m.ObservableBasicsComponent)
  },
  {
    path: 'subjects',
    loadComponent: () => import('./components/subjects/subjects.component').then(m => m.SubjectsComponent)
  },
  {
    path: 'operators',
    loadComponent: () => import('./components/operators/operators.component').then(m => m.OperatorsComponent)
  },
  {
    path: 'error-handling',
    loadComponent: () => import('./components/error-handling/error-handling.component').then(m => m.ErrorHandlingComponent)
  },
  {
    path: 'memory-leak',
    loadComponent: () => import('./components/memory-leak/memory-leak.component').then(m => m.MemoryLeakComponent)
  },
  {
    path: 'common-patterns',
    loadComponent: () => import('./components/common-patterns/common-patterns.component').then(m => m.CommonPatternsComponent)
  },
  {
    path: '**',
    redirectTo: ''
  }
];
