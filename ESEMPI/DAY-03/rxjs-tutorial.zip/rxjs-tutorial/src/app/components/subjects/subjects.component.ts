import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Subject, BehaviorSubject, ReplaySubject } from 'rxjs';

/**
 * Componente che dimostra la famiglia dei Subject:
 * - Subject: multicasting base, non mantiene valore
 * - BehaviorSubject: mantiene l'ultimo valore, richiede valore iniziale
 * - ReplaySubject: riproduce gli ultimi N valori ai nuovi subscriber
 */
@Component({
  selector: 'app-subjects',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a routerLink="/">Home</a></li>
          <li class="breadcrumb-item active">Subject Family</li>
        </ol>
      </nav>

      <h1 class="mb-4">🎯 Subject Family</h1>

      <div class="alert alert-info">
        <strong>💡 Cosa sono i Subject?</strong><br>
        I Subject sono un tipo speciale di Observable che permette di fare <strong>multicasting</strong>:
        un singolo Subject può avere multipli observer e può sia ricevere che emettere valori.
      </div>

      <!-- Sezione 1: Subject Base -->
      <div class="demo-section">
        <h3>1. Subject</h3>
        <p>
          Un <code>Subject</code> è sia un Observable che un Observer.
          Non mantiene alcun valore: i subscriber ricevono solo i valori emessi <strong>dopo</strong> la subscription.
        </p>

        <div class="code-block">
          const subject = new Subject&lt;string&gt;();<br>
          subject.subscribe(value => console.log('Observer A:', value));<br>
          subject.next('Primo valore'); // Solo A lo riceve<br>
          subject.subscribe(value => console.log('Observer B:', value));<br>
          subject.next('Secondo valore'); // Sia A che B lo ricevono
        </div>

        <button class="btn btn-primary me-2" (click)="demoSubject()">
          Esegui Demo Subject
        </button>
        <button class="btn btn-secondary" (click)="resetSubject()">
          Reset
        </button>

        <div class="result-box">
          <div *ngFor="let msg of subjectMessages()">{{ msg }}</div>
          <div *ngIf="subjectMessages().length === 0" class="text-muted">
            Clicca "Esegui Demo Subject" per vedere il comportamento
          </div>
        </div>

        <h5 class="mt-3">📊 Caso d'uso:</h5>
        <p>
          Usa Subject per <strong>eventi</strong> o <strong>messaggi</strong> dove non serve
          mantenere lo stato (es: click del pulsante, notifiche).
        </p>
      </div>

      <!-- Sezione 2: BehaviorSubject -->
      <div class="demo-section">
        <h3>2. BehaviorSubject</h3>
        <p>
          <code>BehaviorSubject</code> mantiene sempre l'<strong>ultimo valore</strong> emesso.
          I nuovi subscriber ricevono immediatamente l'ultimo valore.
          Richiede un <strong>valore iniziale</strong>.
        </p>

        <div class="code-block">
          const behaviorSubject = new BehaviorSubject&lt;number&gt;(0); // valore iniziale<br>
          behaviorSubject.subscribe(v => console.log('Observer A:', v)); // riceve 0<br>
          behaviorSubject.next(1);<br>
          behaviorSubject.next(2);<br>
          behaviorSubject.subscribe(v => console.log('Observer B:', v)); // riceve 2 immediatamente
        </div>

        <div class="mb-3">
          <strong>Valore corrente:</strong>
          <span class="highlight ms-2">{{ currentBehaviorValue() }}</span>
        </div>

        <button class="btn btn-success me-2" (click)="emitBehaviorValue()">
          📤 Emetti Valore Random
        </button>
        <button class="btn btn-info me-2" (click)="addBehaviorSubscriber()">
          👁️ Aggiungi Subscriber
        </button>
        <button class="btn btn-secondary" (click)="resetBehaviorSubject()">
          Reset
        </button>

        <div class="result-box">
          <div *ngFor="let msg of behaviorMessages()">{{ msg }}</div>
        </div>

        <h5 class="mt-3">📊 Caso d'uso:</h5>
        <p>
          Usa BehaviorSubject per <strong>stato dell'applicazione</strong> (es: user data,
          configurazioni, filtri attivi). È perfetto quando serve sempre un valore corrente.
        </p>
      </div>

      <!-- Sezione 3: ReplaySubject -->
      <div class="demo-section">
        <h3>3. ReplaySubject</h3>
        <p>
          <code>ReplaySubject</code> riproduce gli ultimi <strong>N valori</strong> ai nuovi subscriber.
          Puoi specificare quanti valori "bufferizzare".
        </p>

        <div class="code-block">
          const replaySubject = new ReplaySubject&lt;string&gt;(3); // buffer di 3 valori<br>
          replaySubject.next('A');<br>
          replaySubject.next('B');<br>
          replaySubject.next('C');<br>
          replaySubject.next('D');<br>
          // Un nuovo subscriber riceverà: B, C, D (ultimi 3 valori)
        </div>

        <div class="mb-3">
          <strong>Buffer size:</strong>
          <span class="badge bg-primary">{{ replayBufferSize }}</span>
        </div>

        <button class="btn btn-success me-2" (click)="emitReplayValue()">
          📤 Emetti Messaggio
        </button>
        <button class="btn btn-info me-2" (click)="addReplaySubscriber()">
          👁️ Aggiungi Subscriber (riceverà ultimi {{ replayBufferSize }})
        </button>
        <button class="btn btn-secondary" (click)="resetReplaySubject()">
          Reset
        </button>

        <div class="result-box">
          <div *ngFor="let msg of replayMessages()">{{ msg }}</div>
        </div>

        <h5 class="mt-3">📊 Caso d'uso:</h5>
        <p>
          Usa ReplaySubject per mantenere uno <strong>storico di eventi</strong>
          (es: ultimi messaggi di chat, cronologia azioni, log recenti).
        </p>
      </div>

      <!-- Sezione 4: Confronto -->
      <div class="demo-section">
        <h3>4. 📊 Tabella di Confronto</h3>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead class="table-light">
              <tr>
                <th>Tipo</th>
                <th>Valore Iniziale</th>
                <th>Emissione a nuovi subscriber</th>
                <th>Caso d'uso principale</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Subject</strong></td>
                <td>❌ No</td>
                <td>Solo nuovi valori</td>
                <td>Eventi, notifiche</td>
              </tr>
              <tr>
                <td><strong>BehaviorSubject</strong></td>
                <td>✅ Richiesto</td>
                <td>Ultimo valore</td>
                <td>Stato corrente</td>
              </tr>
              <tr>
                <td><strong>ReplaySubject</strong></td>
                <td>❌ No</td>
                <td>Ultimi N valori</td>
                <td>Storico eventi</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Esempio Pratico: Service con BehaviorSubject -->
      <div class="demo-section">
        <h3>5. 🎯 Esempio Pratico: State Management</h3>
        <p>
          Esempio comune: gestire lo stato dell'utente in un servizio usando BehaviorSubject
        </p>

        <div class="code-block">
          @Injectable({{'{'}} providedIn: 'root' {{'}'}})<br>
          export class UserService {{'{'}}
          <br>&nbsp;&nbsp;// BehaviorSubject privato per controllare le emissioni
          <br>&nbsp;&nbsp;private userState$ = new BehaviorSubject&lt;User | null&gt;(null);
          <br>
          <br>&nbsp;&nbsp;// Observable pubblico (read-only) per i componenti
          <br>&nbsp;&nbsp;user$ = this.userState$.asObservable();
          <br>
          <br>&nbsp;&nbsp;setUser(user: User) {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;this.userState$.next(user);
          <br>&nbsp;&nbsp;{{'}'}}
          <br>
          <br>&nbsp;&nbsp;getCurrentUser(): User | null {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;return this.userState$.value; // Accesso sincrono al valore
          <br>&nbsp;&nbsp;{{'}'}}
          <br>{{'}'}}
        </div>

        <div class="alert alert-success">
          <h5>✅ Best Practice:</h5>
          <ul class="mb-0">
            <li>Esponi il Subject come <code>private</code></li>
            <li>Esponi un Observable <code>readonly</code> con <code>.asObservable()</code></li>
            <li>Crea metodi pubblici per modificare lo stato (<code>setUser</code>)</li>
            <li>Usa BehaviorSubject per stato, Subject per eventi</li>
          </ul>
        </div>
      </div>

      <div class="mt-4">
        <a routerLink="/observable-basics" class="btn btn-secondary">← Observable Basics</a>
        <a routerLink="/operators" class="btn btn-primary ms-2">Operatori RxJS →</a>
      </div>
    </div>
  `,
  styles: [`
    .badge {
      font-size: 1rem;
    }

    .table {
      background: white;
    }
  `]
})
export class SubjectsComponent {
  // === Subject Demo ===
  private subject = new Subject<string>();
  subjectMessages = signal<string[]>([]);
  private subjectSubscriberCount = 0;

  // === BehaviorSubject Demo ===
  private behaviorSubject = new BehaviorSubject<number>(0);
  currentBehaviorValue = signal<number>(0);
  behaviorMessages = signal<string[]>([]);
  private behaviorSubscriberCount = 0;

  // === ReplaySubject Demo ===
  replayBufferSize = 3;
  private replaySubject = new ReplaySubject<string>(this.replayBufferSize);
  replayMessages = signal<string[]>([]);
  private replaySubscriberCount = 0;
  private replayMessageCount = 0;

  constructor() {
    // Inizializza BehaviorSubject con valore 0
    this.currentBehaviorValue.set(this.behaviorSubject.value);
  }

  /**
   * Demo 1: Subject -  Non mantiene valori
   * I subscriber ricevono solo valori emessi DOPO la subscription
   */
  demoSubject() {
    this.resetSubject();

    const messages: string[] = [];

    // Primo subscriber
    messages.push('📌 Observer A si iscrive');
    this.subject.subscribe({
      next: (value) => {
        messages.push(`  Observer A riceve: "${value}"`);
        this.subjectMessages.set([...messages]);
      }
    });

    // Emissione prima che B si iscriva
    setTimeout(() => {
      messages.push('📤 Emetto: "Primo valore"');
      this.subject.next('Primo valore');
      this.subjectMessages.set([...messages]);
    }, 500);

    // Secondo subscriber (dopo prima emissione)
    setTimeout(() => {
      messages.push('📌 Observer B si iscrive');
      this.subject.subscribe({
        next: (value) => {
          messages.push(`  Observer B riceve: "${value}"`);
          this.subjectMessages.set([...messages]);
        }
      });
      this.subjectMessages.set([...messages]);
    }, 1000);

    // Seconda emissione (entrambi ricevono)
    setTimeout(() => {
      messages.push('📤 Emetto: "Secondo valore"');
      this.subject.next('Secondo valore');
      this.subjectMessages.set([...messages]);
    }, 1500);

    // Nota conclusiva
    setTimeout(() => {
      messages.push('');
      messages.push('✅ Nota: Observer B non ha ricevuto "Primo valore" perché si è iscritto dopo!');
      this.subjectMessages.set([...messages]);
    }, 2000);
  }

  resetSubject() {
    this.subject = new Subject<string>();
    this.subjectMessages.set([]);
    this.subjectSubscriberCount = 0;
  }

  /**
   * Demo 2: BehaviorSubject - Mantiene l'ultimo valore
   * Nuovi subscriber ricevono immediatamente l'ultimo valore emesso
   */
  emitBehaviorValue() {
    // Genera numero random tra 1 e 100
    const randomValue = Math.floor(Math.random() * 100) + 1;
    this.behaviorSubject.next(randomValue);
    this.currentBehaviorValue.set(randomValue);

    const msg = `📤 Emesso valore: ${randomValue}`;
    this.behaviorMessages.update(msgs => [...msgs, msg]);
  }

  addBehaviorSubscriber() {
    this.behaviorSubscriberCount++;
    const subscriberId = this.behaviorSubscriberCount;

    const msg = `📌 Subscriber ${subscriberId} si iscrive e riceve immediatamente: ${this.behaviorSubject.value}`;
    this.behaviorMessages.update(msgs => [...msgs, msg]);

    // Aggiungi subscription per ricevere valori futuri
    this.behaviorSubject.subscribe({
      next: (value) => {
        const subMsg = `  Subscriber ${subscriberId} riceve: ${value}`;
        this.behaviorMessages.update(msgs => [...msgs, subMsg]);
      }
    });
  }

  resetBehaviorSubject() {
    this.behaviorSubject = new BehaviorSubject<number>(0);
    this.currentBehaviorValue.set(0);
    this.behaviorMessages.set([]);
    this.behaviorSubscriberCount = 0;
  }

  /**
   * Demo 3: ReplaySubject - Riproduce ultimi N valori
   * Buffer dei valori che vengono "rigiocati" ai nuovi subscriber
   */
  emitReplayValue() {
    this.replayMessageCount++;
    const message = `Messaggio ${this.replayMessageCount}`;

    this.replaySubject.next(message);

    const msg = `📤 Emesso: "${message}"`;
    this.replayMessages.update(msgs => [...msgs, msg]);
  }

  addReplaySubscriber() {
    this.replaySubscriberCount++;
    const subscriberId = this.replaySubscriberCount;

    const msg = `📌 Subscriber ${subscriberId} si iscrive`;
    this.replayMessages.update(msgs => [...msgs, msg]);

    // Il nuovo subscriber riceverà gli ultimi N valori del buffer
    this.replaySubject.subscribe({
      next: (value) => {
        const subMsg = `  Subscriber ${subscriberId} riceve: "${value}"`;
        this.replayMessages.update(msgs => [...msgs, subMsg]);
      }
    });
  }

  resetReplaySubject() {
    this.replaySubject = new ReplaySubject<string>(this.replayBufferSize);
    this.replayMessages.set([]);
    this.replaySubscriberCount = 0;
    this.replayMessageCount = 0;
  }
}
