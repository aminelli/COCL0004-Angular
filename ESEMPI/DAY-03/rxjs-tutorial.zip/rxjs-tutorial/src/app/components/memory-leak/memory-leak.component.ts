import { Component, signal, OnDestroy, DestroyRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import {
  interval,
  Subject,
  Subscription,
  timer
} from 'rxjs';
import {
  takeUntil,
  take,
  takeWhile,
  tap
} from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Componente che dimostra come evitare memory leak nelle subscription:
 * - Problema: subscription non cancellate continuano ad emettere
 * - Soluzione 1: unsubscribe manuale
 * - Soluzione 2: takeUntil pattern
 * - Soluzione 3: takeUntilDestroyed (Angular 16+)
 * - Soluzione 4: async pipe (best practice)
 * - Altre strategie: take, takeWhile, first
 */
@Component({
  selector: 'app-memory-leak',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a routerLink="/">Home</a></li>
          <li class="breadcrumb-item active">Memory Leak Prevention</li>
        </ol>
      </nav>

      <h1 class="mb-4">🔒 Prevenzione Memory Leak</h1>

      <div class="alert alert-danger">
        <h5>⚠️ Perché i Memory Leak sono un problema?</h5>
        <p class="mb-0">
          Se non cancelli le subscription quando un componente viene distrutto,
          gli Observable continuano ad emettere valori e ad eseguire codice.
          Questo causa:
        </p>
        <ul class="mb-0">
          <li>Consumo crescente di memoria</li>
          <li>Performance degradate</li>
          <li>Comportamenti inaspettati (componenti "fantasma")</li>
          <li>Possibili crash dell'applicazione</li>
        </ul>
      </div>

      <!-- Sezione 1: Il Problema -->
      <div class="demo-section">
        <h3>1. ❌ Il Problema: Memory Leak</h3>
        <p>
          Esempio di codice che causa memory leak:
        </p>

        <div class="code-block">
          export class BadComponent implements OnInit {{'{'}}
          <br>&nbsp;&nbsp;ngOnInit() {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;// ❌ ERRORE: subscription non cancellata!
          <br>&nbsp;&nbsp;&nbsp;&nbsp;interval(1000).subscribe(value => {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;console.log('Tick:', value);
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;// Questo continuerà anche dopo che il componente è distrutto!
          <br>&nbsp;&nbsp;&nbsp;&nbsp;{{'}''}});
          <br>&nbsp;&nbsp;{{'}'}}
          <br>{{'}'}}
        </div>

        <div class="alert alert-warning">
          <strong>Problema:</strong> Quando navighiamo via dal componente, l'interval continua
          ad eseguire, consumando risorse e potenzialmente causando errori.
        </div>
      </div>

      <!-- Sezione 2: Soluzione 1 - unsubscribe manuale -->
      <div class="demo-section">
        <h3>2. ✅ Soluzione 1: Unsubscribe Manuale</h3>
        <p>
          Salva la subscription e cancellala in <code>ngOnDestroy</code>:
        </p>

        <div class="code-block">
          export class GoodComponent implements OnInit, OnDestroy {{'{'}}
          <br>&nbsp;&nbsp;private subscription!: Subscription;
          <br>
          <br>&nbsp;&nbsp;ngOnInit() {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;this.subscription = interval(1000).subscribe(/*...*/);
          <br>&nbsp;&nbsp;{{'}'}}
          <br>
          <br>&nbsp;&nbsp;ngOnDestroy() {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;this.subscription.unsubscribe(); // ✅ Cleanup!
          <br>&nbsp;&nbsp;{{'}'}}
          <br>{{'}'}}
        </div>

        <button
          class="btn btn-success me-2"
          (click)="startManualSubscription()"
          [disabled]="manualRunning()">
          ▶️ Avvia
        </button>
        <button
          class="btn btn-danger"
          (click)="stopManualSubscription()"
          [disabled]="!manualRunning()">
          ⏹️ Stop (simula ngOnDestroy)
        </button>

        <div class="result-box">
          <strong>Counter:</strong> {{ manualCounter() }}<br>
          <small class="text-muted">
            {{ manualRunning() ? '🟢 In esecuzione' : '🔴 Fermato (subscription cancellata)' }}
          </small>
        </div>

        <div class="alert alert-info mt-3">
          <strong>💡 Pro:</strong> Controllo esplicito<br>
          <strong>⚠️ Con:</strong> Codice verbose, facile dimenticarsene
        </div>
      </div>

      <!-- Sezione 3: Soluzione 2 - takeUntil -->
      <div class="demo-section">
        <h3>3. ✅ Soluzione 2: takeUntil Pattern</h3>
        <p>
          Usa un Subject che emette in <code>ngOnDestroy</code> per cancellare tutte le subscription:
        </p>

        <div class="code-block">
          export class BetterComponent implements OnDestroy {{'{'}}
          <br>&nbsp;&nbsp;private destroy$ = new Subject&lt;void&gt;();
          <br>
          <br>&nbsp;&nbsp;ngOnInit() {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;interval(1000).pipe(
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;takeUntil(this.destroy$) // ✅ Si cancella automaticamente
          <br>&nbsp;&nbsp;&nbsp;&nbsp;).subscribe(/*...*/);
          <br>
          <br>&nbsp;&nbsp;&nbsp;&nbsp;// Puoi avere multiple subscription tutte gestite da destroy$
          <br>&nbsp;&nbsp;&nbsp;&nbsp;otherObservable$.pipe(
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;takeUntil(this.destroy$)
          <br>&nbsp;&nbsp;&nbsp;&nbsp;).subscribe(/*...*/);
          <br>&nbsp;&nbsp;{{'}'}}
          <br>
          <br>&nbsp;&nbsp;ngOnDestroy() {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;this.destroy$.next(); // Emette per cancellare tutte
          <br>&nbsp;&nbsp;&nbsp;&nbsp;this.destroy$.complete();
          <br>&nbsp;&nbsp;{{'}'}}
          <br>{{'}'}}
        </div>

        <button
          class="btn btn-success me-2"
          (click)="startTakeUntilSubscription()"
          [disabled]="takeUntilRunning()">
          ▶️ Avvia
        </button>
        <button
          class="btn btn-danger"
          (click)="stopTakeUntilSubscription()"
          [disabled]="!takeUntilRunning()">
          ⏹️ Stop (emetti destroy$)
        </button>

        <div class="result-box">
          <strong>Counter:</strong> {{ takeUntilCounter() }}<br>
          <small class="text-muted">
            {{ takeUntilRunning() ? '🟢 In esecuzione' : '🔴 Fermato (destroy$ emesso)' }}
          </small>
        </div>

        <div class="alert alert-success mt-3">
          <strong>✅ Pro:</strong> Gestisce multiple subscription facilmente<br>
          <strong>✅ Best practice</strong> usata in molti progetti Angular
        </div>
      </div>

      <!-- Sezione 4: Soluzione 3 - takeUntilDestroyed -->
      <div class="demo-section">
        <h3>4. ✅ Soluzione 3: takeUntilDestroyed (Angular 16+)</h3>
        <p>
          Angular 16+ fornisce <code>takeUntilDestroyed()</code> che si cancella automaticamente
          quando il componente viene distrutto. Usa <code>DestroyRef</code> internamente.
        </p>

        <div class="code-block">
          export class ModernComponent {{'{'}}
          <br>&nbsp;&nbsp;private destroyRef = inject(DestroyRef);
          <br>
          <br>&nbsp;&nbsp;ngOnInit() {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;interval(1000).pipe(
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;takeUntilDestroyed(this.destroyRef) // ✅ Auto-cleanup!
          <br>&nbsp;&nbsp;&nbsp;&nbsp;).subscribe(/*...*/);
          <br>&nbsp;&nbsp;{{'}'}}
          <br>
          <br>&nbsp;&nbsp;// Non serve ngOnDestroy! 🎉
          <br>{{'}'}}
        </div>

        <button
          class="btn btn-success"
          (click)="startModernSubscription()">
          ▶️ Avvia (usa takeUntilDestroyed)
        </button>

        <div class="result-box">
          <strong>Counter:</strong> {{ modernCounter() }}<br>
          <small class="text-muted">
            🟢 Si cancellerà automaticamente quando il componente viene distrutto
          </small>
        </div>

        <div class="alert alert-success mt-3">
          <strong>🏆 Migliore soluzione per Angular 16+</strong><br>
          <strong>✅ Pro:</strong> Minimo boilerplate, type-safe, gestito dal framework<br>
          <strong>✅ Raccomandato</strong> per nuovi progetti Angular
        </div>
      </div>

      <!-- Sezione 5: async pipe -->
      <div class="demo-section">
        <h3>5. 🏆 Soluzione 4: async pipe (Template)</h3>
        <p>
          La soluzione più pulita: lascia che Angular gestisca la subscription!
        </p>

        <div class="code-block">
          <!-- Component --><br>
          export class BestComponent {{'{'}}
          <br>&nbsp;&nbsp;counter$ = interval(1000); // Observable, non subscribe!
          <br>{{'}'}}
          <br><br>
          &lt;!-- Template --&gt;<br>
          &lt;div&gt;Counter: {{'{{ counter$ | async }}'}} &lt;/div&gt;
          <br><br>
          &lt;!-- Angular fa automaticamente subscribe e unsubscribe! --&gt;
        </div>

        <div class="alert alert-success">
          <strong>🥇 BEST PRACTICE</strong><br>
          <strong>✅ Pro:</strong>
          <ul class="mb-0">
            <li>Zero boilerplate per unsubscribe</li>
            <li>Nessun rischio di memory leak</li>
            <li>Codice più pulito e dichiarativo</li>
            <li>Angular gestisce tutto automaticamente</li>
          </ul>
        </div>
      </div>

      <!-- Sezione 6: Altri operatori utili -->
      <div class="demo-section">
        <h3>6. ⚙️ Altri Operatori per Cancellazione Automatica</h3>

        <h5>take(n) - Prendi N valori e completa</h5>
        <div class="code-block mb-3">
          interval(1000).pipe(<br>
          &nbsp;&nbsp;take(5) // Solo 5 emissioni, poi completa automaticamente
          <br>).subscribe(/*...*/);
        </div>

        <h5>takeWhile(predicate) - Finché la condizione è vera</h5>
        <div class="code-block mb-3">
          counter$.pipe(<br>
          &nbsp;&nbsp;takeWhile(value => value &lt; 10) // Fino a che è minore di 10
          <br>).subscribe(/*...*/);
        </div>

        <h5>first() - Solo il primo valore, poi completa</h5>
        <div class="code-block">
          observable$.pipe(<br>
          &nbsp;&nbsp;first() // Prende solo il primo valore
          <br>).subscribe(/*...*/);
        </div>
      </div>

      <!-- Tabella di Confronto -->
      <div class="demo-section">
        <h3>7. 📊 Confronto Strategie</h3>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead class="table-light">
              <tr>
                <th>Strategia</th>
                <th>Boilerplate</th>
                <th>Rischio Leak</th>
                <th>Quando Usarla</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>unsubscribe manuale</strong></td>
                <td>⚠️ Alto</td>
                <td>⚠️ Alto</td>
                <td>Subscription singole e semplici</td>
              </tr>
              <tr>
                <td><strong>takeUntil + destroy$</strong></td>
                <td>⚠️ Medio</td>
                <td>✅ Basso</td>
                <td>Multiple subscription, Angular &lt;16</td>
              </tr>
              <tr>
                <td><strong>takeUntilDestroyed</strong></td>
                <td>✅ Basso</td>
                <td>✅ Basso</td>
                <td>Angular 16+, codice TypeScript</td>
              </tr>
              <tr class="table-success">
                <td><strong>async pipe</strong></td>
                <td>✅ Zero</td>
                <td>✅ Zero</td>
                <td>🏆 SEMPRE quando possibile!</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Best Practices -->
      <div class="alert alert-success">
        <h5>✅ Best Practices Generali</h5>
        <ol class="mb-0">
          <li><strong>Preferisci async pipe</strong> - Lascia Angular gestire la subscription</li>
          <li><strong>Usa takeUntilDestroyed</strong> in Angular 16+ quando async pipe non è possibile</li>
          <li><strong>Usa takeUntil</strong> per progetti Angular &lt;16</li>
          <li><strong>Observable che completano</strong> - HTTP requests, of(), from() si completano automaticamente</li>
          <li><strong>Tool di sviluppo</strong> - Usa Angular DevTools per monitorare memory leak</li>
          <li><strong>Code review</strong> - Controlla sempre che ogni subscribe abbia una strategia di cleanup</li>
        </ol>
      </div>

      <!-- Checklist -->
      <div class="alert alert-warning">
        <h5>🔍 Checklist: Quando Serve Unsubscribe?</h5>
        <ul class="mb-0">
          <li>✅ <strong>Serve:</strong> interval, fromEvent, Subject che non completano</li>
          <li>✅ <strong>Serve:</strong> Observable infinite (websocket, polling)</li>
          <li>❌ <strong>NON serve:</strong> HttpClient (completa automaticamente)</li>
          <li>❌ <strong>NON serve:</strong> of(), from() con array finiti</li>
          <li>❌ <strong>NON serve:</strong> Observable con take(n), first()</li>
          <li>❌ <strong>NON serve:</strong> async pipe (Angular gestisce)</li>
        </ul>
      </div>

      <div class="mt-4">
        <a routerLink="/error-handling" class="btn btn-secondary">← Gestione Errori</a>
        <a routerLink="/common-patterns" class="btn btn-primary ms-2">Pattern Comuni →</a>
      </div>
    </div>
  `,
  styles: []
})
export class MemoryLeakComponent implements OnDestroy {
  private destroyRef = inject(DestroyRef);

  // Soluzione 1: unsubscribe manuale
  manualCounter = signal<number>(0);
  manualRunning = signal<boolean>(false);
  private manualSubscription: Subscription | null = null;

  // Soluzione 2: takeUntil
  takeUntilCounter = signal<number>(0);
  takeUntilRunning = signal<boolean>(false);
  private destroy$ = new Subject<void>();

  // Soluzione 3: takeUntilDestroyed
  modernCounter = signal<number>(0);

  /**
   * Soluzione 1: Unsubscribe Manuale
   */
  startManualSubscription() {
    if (this.manualRunning()) return;

    this.manualCounter.set(0);
    this.manualRunning.set(true);

    // Salva la subscription per cancellarla dopo
    this.manualSubscription = interval(1000).subscribe(value => {
      this.manualCounter.set(value);
      console.log('Manual subscription tick:', value);
    });
  }

  stopManualSubscription() {
    if (this.manualSubscription) {
      // Cancella manualmente la subscription
      this.manualSubscription.unsubscribe();
      this.manualSubscription = null;
      this.manualRunning.set(false);
      console.log('✅ Manual subscription cancelled');
    }
  }

  /**
   * Soluzione 2: takeUntil Pattern
   */
  startTakeUntilSubscription() {
    if (this.takeUntilRunning()) return;

    this.takeUntilCounter.set(0);
    this.takeUntilRunning.set(true);

    // Crea un nuovo Subject per questo ciclo
    this.destroy$ = new Subject<void>();

    interval(1000)
      .pipe(
        takeUntil(this.destroy$), // Si cancella quando destroy$ emette
        tap(value => console.log('TakeUntil subscription tick:', value))
      )
      .subscribe(value => {
        this.takeUntilCounter.set(value);
      });
  }

  stopTakeUntilSubscription() {
    // Emetti sul Subject per cancellare tutte le subscription
    this.destroy$.next();
    this.destroy$.complete();
    this.takeUntilRunning.set(false);
    console.log('✅ TakeUntil subscriptions cancelled');
  }

  /**
   * Soluzione 3: takeUntilDestroyed (Angular 16+)
   * Questa è la soluzione più moderna e raccomandata
   */
  startModernSubscription() {
    this.modernCounter.set(0);

    interval(1000)
      .pipe(
        // Si cancella automaticamente quando il componente viene distrutto!
        takeUntilDestroyed(this.destroyRef),
        tap(value => console.log('Modern subscription tick:', value))
      )
      .subscribe(value => {
        this.modernCounter.set(value);
      });

    console.log('✅ Modern subscription started with auto-cleanup');
  }

  /**
   * ngOnDestroy viene chiamato quando il componente viene distrutto
   * Qui facciamo il cleanup di eventuali subscription manuali
   */
  ngOnDestroy() {
    console.log('🧹 Component destroying - cleanup...');

    // Cleanup manuale subscription (se esiste)
    if (this.manualSubscription) {
      this.manualSubscription.unsubscribe();
    }

    // Cleanup takeUntil pattern
    this.destroy$.next();
    this.destroy$.complete();

    // takeUntilDestroyed si gestisce automaticamente!
    console.log('✅ Cleanup completed');
  }
}
