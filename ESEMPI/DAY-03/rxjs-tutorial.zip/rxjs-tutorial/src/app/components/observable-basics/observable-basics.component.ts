import { Component, signal, OnInit, DestroyRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Observable, Observer, Subscription, interval, of, from } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Componente che dimostra i concetti base di RxJS:
 * - Observable: stream di dati che può emettere valori nel tempo
 * - Observer: oggetto che "osserva" l'Observable e reagisce ai suoi valori
 * - Subscription: rappresenta l'esecuzione di un Observable
 */
@Component({
  selector: 'app-observable-basics',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a routerLink="/">Home</a></li>
          <li class="breadcrumb-item active">Observable Basics</li>
        </ol>
      </nav>

      <h1 class="mb-4">🔵 Observable Basics</h1>

      <!-- Sezione 1: Cos'è un Observable -->
      <div class="demo-section">
        <h3>1. Cos'è un Observable?</h3>
        <p>
          Un <strong>Observable</strong> è come un "tubo" attraverso cui passano dati nel tempo.
          Può emettere zero o più valori, e può completarsi o generare un errore.
        </p>
        <div class="code-block">
          // Observable che emette valori da un array<br>
          const numbers$ = of(1, 2, 3, 4, 5);
        </div>
        <button class="btn btn-primary" (click)="demoSimpleObservable()">
          Esegui Observable Semplice
        </button>
        <div class="result-box">
          <strong>Risultato:</strong> {{ simpleResult() }}
        </div>
      </div>

      <!-- Sezione 2: Observer -->
      <div class="demo-section">
        <h3>2. Cos'è un Observer?</h3>
        <p>
          Un <strong>Observer</strong> è un oggetto con tre metodi callback:
        </p>
        <ul>
          <li><code>next(value)</code> - chiamato quando arriva un nuovo valore</li>
          <li><code>error(err)</code> - chiamato quando si verifica un errore</li>
          <li><code>complete()</code> - chiamato quando l'Observable si completa</li>
        </ul>
        <div class="code-block">
          const observer: Observer&lt;number&gt; = {{'{'}}
          <br>&nbsp;&nbsp;next: (value) => console.log('Valore ricevuto:', value),
          <br>&nbsp;&nbsp;error: (err) => console.error('Errore:', err),
          <br>&nbsp;&nbsp;complete: () => console.log('Completato!')
          <br>{{'}'}}
        </div>
        <button class="btn btn-primary" (click)="demoObserver()">
          Esegui con Observer Completo
        </button>
        <div class="result-box">
          <div *ngFor="let msg of observerMessages()">{{ msg }}</div>
        </div>
      </div>

      <!-- Sezione 3: Subscription -->
      <div class="demo-section">
        <h3>3. Cos'è una Subscription?</h3>
        <p>
          Una <strong>Subscription</strong> rappresenta l'esecuzione di un Observable.
          È importante chiamare <code>unsubscribe()</code> per evitare memory leak!
        </p>
        <div class="code-block">
          const subscription = observable$.subscribe(observer);<br>
          // Quando non serve più:<br>
          subscription.unsubscribe();
        </div>
        <button
          class="btn btn-success me-2"
          (click)="startInterval()"
          [disabled]="isIntervalRunning()">
          ▶️ Avvia Intervallo
        </button>
        <button
          class="btn btn-danger"
          (click)="stopInterval()"
          [disabled]="!isIntervalRunning()">
          ⏹️ Ferma Intervallo (unsubscribe)
        </button>
        <div class="result-box">
          <strong>Counter:</strong> {{ intervalValue() }}
          <br>
          <small class="text-muted">
            {{ isIntervalRunning() ? '🟢 In esecuzione' : '🔴 Fermato' }}
          </small>
        </div>
      </div>

      <!-- Sezione 4: Creare Observable da diverse sorgenti -->
      <div class="demo-section">
        <h3>4. Creare Observable da diverse sorgenti</h3>

        <h5>Da Array con <code>from()</code></h5>
        <button class="btn btn-outline-primary mb-3" (click)="demoFromArray()">
          Esegui from(array)
        </button>
        <div class="result-box mb-3">
          {{ fromArrayResult() }}
        </div>

        <h5>Da Valori con <code>of()</code></h5>
        <button class="btn btn-outline-primary mb-3" (click)="demoOf()">
          Esegui of(valori)
        </button>
        <div class="result-box mb-3">
          {{ ofResult() }}
        </div>

        <h5>Custom Observable</h5>
        <p>Puoi creare Observable personalizzati con <code>new Observable()</code></p>
        <button class="btn btn-outline-primary mb-3" (click)="demoCustomObservable()">
          Esegui Custom Observable
        </button>
        <div class="result-box">
          {{ customResult() }}
        </div>
      </div>

      <!-- Sezione 5: Best Practices -->
      <div class="alert alert-success">
        <h5>✅ Best Practices</h5>
        <ul class="mb-0">
          <li>Usa il suffisso <code>$</code> per le variabili Observable (es: <code>data$</code>)</li>
          <li>Ricordati sempre di fare unsubscribe per evitare memory leak</li>
          <li>In Angular 21, usa <code>takeUntilDestroyed()</code> per auto-unsubscribe</li>
          <li>Preferisci l'<code>async pipe</code> nei template quando possibile</li>
        </ul>
      </div>

      <div class="mt-4">
        <a routerLink="/" class="btn btn-secondary">← Torna alla Home</a>
        <a routerLink="/subjects" class="btn btn-primary ms-2">Subject Family →</a>
      </div>
    </div>
  `,
  styles: [`
    .code-block {
      overflow-x: auto;
    }
  `]
})
export class ObservableBasicsComponent implements OnInit {
  // Signals per gestire lo stato reattivo
  simpleResult = signal<string>('');
  observerMessages = signal<string[]>([]);
  intervalValue = signal<number>(0);
  isIntervalRunning = signal<boolean>(false);
  fromArrayResult = signal<string>('');
  ofResult = signal<string>('');
  customResult = signal<string>('');

  // Subscription per l'intervallo (da gestire manualmente)
  private intervalSubscription: Subscription | null = null;

  // DestroyRef per cleanup automatico (Angular 21 best practice)
  private destroyRef = inject(DestroyRef);

  ngOnInit() {
    console.log('ObservableBasicsComponent inizializzato');
  }

  /**
   * Demo 1: Observable semplice con of()
   * of() crea un Observable che emette valori in sequenza e poi completa
   */
  demoSimpleObservable() {
    // Crea un Observable che emette numeri
    const numbers$ = of(1, 2, 3, 4, 5);

    const values: number[] = [];

    // Subscribe all'Observable
    // Nota: of() completa automaticamente quindi non c'è bisogno di unsubscribe
    numbers$.subscribe({
      next: (value) => {
        values.push(value);
        console.log('Valore emesso:', value);
      },
      complete: () => {
        this.simpleResult.set(`Valori emessi: ${values.join(', ')}`);
        console.log('Observable completato');
      }
    });
  }

  /**
   * Demo 2: Observer con tutti i metodi (next, error, complete)
   */
  demoObserver() {
    this.observerMessages.set([]);

    // Observable che emette alcuni valori
    const example$ = of('Ciao', 'RxJS', 'in', 'Angular', '21');

    // Observer completo con tutti i tre metodi
    const observer: Observer<string> = {
      next: (value) => {
        const msg = `✅ next: ${value}`;
        this.observerMessages.update(messages => [...messages, msg]);
        console.log(msg);
      },
      error: (err) => {
        const msg = `❌ error: ${err}`;
        this.observerMessages.update(messages => [...messages, msg]);
        console.error(msg);
      },
      complete: () => {
        const msg = '🏁 complete: Stream terminato!';
        this.observerMessages.update(messages => [...messages, msg]);
        console.log(msg);
      }
    };

    // Subscribe con l'observer
    example$.subscribe(observer);
  }

  /**
   * Demo 3: Gestione Subscription con interval
   * Dimostra come fare subscribe e unsubscribe manualmente
   */
  startInterval() {
    if (this.isIntervalRunning()) return;

    this.intervalValue.set(0);
    this.isIntervalRunning.set(true);

    // interval() emette un numero incrementale ogni secondo
    const counter$ = interval(1000);

    // Salviamo la subscription per poterla cancellare dopo
    this.intervalSubscription = counter$.subscribe({
      next: (value) => {
        this.intervalValue.set(value);
        console.log('Tick:', value);
      }
    });
  }

  stopInterval() {
    if (this.intervalSubscription) {
      // Importante! Unsubscribe per fermare l'emissione e liberare risorse
      this.intervalSubscription.unsubscribe();
      this.intervalSubscription = null;
      this.isIntervalRunning.set(false);
      console.log('Subscription terminata');
    }
  }

  /**
   * Demo 4: Creare Observable da un array con from()
   */
  demoFromArray() {
    const fruits = ['🍎 Mela', '🍌 Banana', '🍊 Arancia', '🍇 Uva'];

    // from() converte un array (o Promise, Iterator) in Observable
    const fruits$ = from(fruits);

    const result: string[] = [];

    fruits$
      .pipe(
        // takeUntilDestroyed si occupa dell'unsubscribe automatico
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (fruit) => {
          result.push(fruit);
        },
        complete: () => {
          this.fromArrayResult.set(result.join(' → '));
        }
      });
  }

  /**
   * Demo 5: Creare Observable con of()
   */
  demoOf() {
    // of() emette i valori passati come argomenti
    const mixed$ = of(
      42,
      'testo',
      true,
      { name: 'oggetto' },
      [1, 2, 3]
    );

    const results: string[] = [];

    mixed$.subscribe({
      next: (value) => {
        results.push(`${typeof value}: ${JSON.stringify(value)}`);
      },
      complete: () => {
        this.ofResult.set(results.join(' | '));
      }
    });
  }

  /**
   * Demo 6: Custom Observable
   * Crea un Observable personalizzato che emette valori random
   */
  demoCustomObservable() {
    // Crea un Observable custom usando il costruttore
    const custom$ = new Observable<number>(subscriber => {
      console.log('Observable eseguito!');

      let count = 0;

      // Emetti 5 numeri random
      const intervalId = setInterval(() => {
        const randomNum = Math.floor(Math.random() * 100);
        subscriber.next(randomNum);

        count++;
        if (count === 5) {
          subscriber.complete(); // Completa dopo 5 emissioni
          clearInterval(intervalId);
        }
      }, 500);

      // Funzione di cleanup (chiamata quando si fa unsubscribe)
      return () => {
        console.log('Cleanup eseguito');
        clearInterval(intervalId);
      };
    });

    const numbers: number[] = [];

    custom$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (num) => {
          numbers.push(num);
          console.log('Numero random:', num);
        },
        complete: () => {
          this.customResult.set(`Numeri generati: ${numbers.join(', ')}`);
        }
      });
  }
}
