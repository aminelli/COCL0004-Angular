import { Component, signal, DestroyRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import {
  Observable,
  throwError,
  of,
  timer
} from 'rxjs';
import {
  catchError,
  retry,
  retryWhen,
  tap,
  delayWhen,
  take,
  map
} from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Componente che dimostra la gestione degli errori in RxJS:
 * - catchError: cattura e gestisce errori
 * - retry: riprova automaticamente in caso di errore
 * - retryWhen: logica custom per le retry
 * - Strategie di fallback
 * - Propagazione vs handling degli errori
 */
@Component({
  selector: 'app-error-handling',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a routerLink="/">Home</a></li>
          <li class="breadcrumb-item active">Gestione Errori</li>
        </ol>
      </nav>

      <h1 class="mb-4">⚠️ Gestione Errori in RxJS</h1>

      <div class="alert alert-info">
        <strong>💡 Perché gestire gli errori?</strong><br>
        Quando un Observable emette un errore, lo stream si interrompe e non emetterà più valori.
        È fondamentale gestire gli errori correttamente per creare applicazioni robuste.
      </div>

      <!-- Sezione 1: Errore non gestito -->
      <div class="demo-section">
        <h3>1. ❌ Errore Non Gestito</h3>
        <p>
          Quando un errore non viene gestito, l'Observable si interrompe e gli observer
          ricevono la callback <code>error</code>.
        </p>

        <div class="code-block">
          observable$.subscribe(&lbrace;
          <br>&nbsp;&nbsp;next: value => console.log(value),
          <br>&nbsp;&nbsp;error: err => console.error('Errore:', err), // ⚠️ Stream interrotto
          <br>&nbsp;&nbsp;complete: () => console.log('Completato') // ❌ Non sarà mai chiamato
          <br>&rbrace;);
        </div>

        <button class="btn btn-danger" (click)="demoUnhandledError()">
          Simula Errore Non Gestito
        </button>

        <div class="result-box">
          <div *ngFor="let log of unhandledLogs()" [class.text-danger]="log.includes('❌')">
            {{ log }}
          </div>
        </div>
      </div>

      <!-- Sezione 2: catchError -->
      <div class="demo-section">
        <h3>2. ✅ catchError - Cattura e Gestisci</h3>
        <p>
          <code>catchError</code> intercetta l'errore e permette di:
        </p>
        <ul>
          <li>Ritornare un valore di fallback</li>
          <li>Ritornare un Observable alternativo</li>
          <li>Propagare l'errore con throwError</li>
        </ul>

        <div class="code-block">
          http.get('/api/data').pipe(<br>
          &nbsp;&nbsp;catchError(error => &lbrace;<br>
          &nbsp;&nbsp;&nbsp;&nbsp;console.error('Errore API:', error);
          <br>&nbsp;&nbsp;&nbsp;&nbsp;return of([]); // Ritorna array vuoto come fallback
          <br>&nbsp;&nbsp;&rbrace;)<br>
          ).subscribe(data => display(data));
        </div>

        <button class="btn btn-success" (click)="demoCatchError()">
          Demo catchError con Fallback
        </button>

        <div class="result-box">
          <div *ngFor="let log of catchErrorLogs()">{{ log }}</div>
        </div>
      </div>

      <!-- Sezione 3: retry -->
      <div class="demo-section">
        <h3>3. 🔄 retry - Riprova Automaticamente</h3>
        <p>
          <code>retry(n)</code> riprova automaticamente l'Observable in caso di errore.
          Utile per errori di rete temporanei.
        </p>

        <div class="code-block">
          http.get('/api/data').pipe(<br>
          &nbsp;&nbsp;retry(3), // Riprova fino a 3 volte
          <br>&nbsp;&nbsp;catchError(error => of(&lbrace; error: 'Failed after 3 retries' &rbrace;))
          <br>).subscribe(data => display(data));
        </div>

        <button class="btn btn-primary" (click)="demoRetry()">
          Demo retry (3 tentativi)
        </button>

        <div class="result-box">
          <div *ngFor="let log of retryLogs()">{{ log }}</div>
        </div>
      </div>

      <!-- Sezione 4: retryWhen con strategia -->
      <div class="demo-section">
        <h3>4. ⚙️ retryWhen - Strategia Custom</h3>
        <p>
          <code>retryWhen</code> permette di implementare logiche di retry personalizzate
          come exponential backoff (attesa crescente tra tentativi).
        </p>

        <div class="code-block">
          http.get('/api/data').pipe(<br>
          &nbsp;&nbsp;retryWhen(errors => errors.pipe(<br>
          &nbsp;&nbsp;&nbsp;&nbsp;delayWhen((_, i) => timer(Math.pow(2, i) * 1000)) // 1s, 2s, 4s...<br>
          &nbsp;&nbsp;&nbsp;&nbsp;take(3) // Max 3 tentativi<br>
          &nbsp;&nbsp;))<br>
          ).subscribe(data => display(data));
        </div>

        <button class="btn btn-primary" (click)="demoRetryWhen()">
          Demo Exponential Backoff
        </button>

        <div class="result-box">
          <div *ngFor="let log of retryWhenLogs()">{{ log }}</div>
          <div *ngIf="retryWhenLogs().length === 0" class="text-muted">
            Click per vedere retry con attesa crescente
          </div>
        </div>
      </div>

      <!-- Sezione 5: Multiple catchError -->
      <div class="demo-section">
        <h3>5. 🎯 Gestione Errori Multi-livello</h3>
        <p>
          Puoi usare multipli <code>catchError</code> per gestire errori in punti diversi
          della pipeline con strategie diverse.
        </p>

        <div class="code-block">
          getUserData(userId).pipe(<br>
          &nbsp;&nbsp;switchMap(user => getOrders(user.id).pipe(<br>
          &nbsp;&nbsp;&nbsp;&nbsp;catchError(() => of([])) // Fallback locale<br>
          &nbsp;&nbsp;)),<br>
          &nbsp;&nbsp;catchError(error => &lbrace; // Gestione errore globale<br>
          &nbsp;&nbsp;&nbsp;&nbsp;showNotification('Errore caricamento dati');
          <br>&nbsp;&nbsp;&nbsp;&nbsp;return of(null);
          <br>&nbsp;&nbsp;&rbrace;)<br>
          ).subscribe();
        </div>

        <button class="btn btn-info" (click)="demoMultipleCatchError()">
          Demo Multiple catchError
        </button>

        <div class="result-box">
          <div *ngFor="let log of multipleCatchLogs()">{{ log }}</div>
        </div>
      </div>

      <!-- Sezione 6: Pattern comuni -->
      <div class="demo-section">
        <h3>6. 🎨 Pattern Comuni di Error Handling</h3>

        <h5>Pattern 1: Fallback a un valore di default</h5>
        <div class="code-block mb-3">
          getData$().pipe(<br>
          &nbsp;&nbsp;catchError(() => of(DEFAULT_VALUE))<br>
          )
        </div>

        <h5>Pattern 2: Fallback a Observable alternativo</h5>
        <div class="code-block mb-3">
          getPrimaryData$().pipe(<br>
          &nbsp;&nbsp;catchError(() => getBackupData$())<br>
          )
        </div>

        <h5>Pattern 3: Logging e propagazione</h5>
        <div class="code-block mb-3">
          getData$().pipe(<br>
          &nbsp;&nbsp;catchError(err => &lbrace;<br>
          &nbsp;&nbsp;&nbsp;&nbsp;logError(err);
          <br>&nbsp;&nbsp;&nbsp;&nbsp;return throwError(() => err); // Propaga l'errore
          <br>&nbsp;&nbsp;&rbrace;)<br>
          )
        </div>

        <h5>Pattern 4: Retry con backoff</h5>
        <div class="code-block">
          apiCall$().pipe(<br>
          &nbsp;&nbsp;retryWhen(errors => errors.pipe(<br>
          &nbsp;&nbsp;&nbsp;&nbsp;delayWhen((_, i) => timer(1000 * Math.pow(2, i))),<br>
          &nbsp;&nbsp;&nbsp;&nbsp;take(3)<br>
          &nbsp;&nbsp;)),<br>
          &nbsp;&nbsp;catchError(() => of(FALLBACK_DATA))<br>
          )
        </div>
      </div>

      <!-- Best Practices -->
      <div class="alert alert-success">
        <h5>✅ Best Practices per Error Handling</h5>
        <ul class="mb-0">
          <li>Usa sempre <code>catchError</code> per evitare che errori crashino l'app</li>
          <li>Gestisci errori il più vicino possibile alla loro origine</li>
          <li>Usa <code>retry</code> per errori di rete temporanei</li>
          <li>Implementa exponential backoff per retry di API</li>
          <li>Fornisci sempre un fallback o valore di default quando possibile</li>
          <li>Logga gli errori per debugging e monitoraggio</li>
          <li>Non nascondere errori critici: propagali quando necessario</li>
          <li>Mostra feedback utente appropriato per errori non recuperabili</li>
        </ul>
      </div>

      <!-- Warning Box -->
      <div class="alert alert-warning">
        <h5>⚠️ Attenzione!</h5>
        <ul class="mb-0">
          <li>
            <code>catchError</code> deve ritornare un Observable (usa <code>of()</code> o <code>throwError()</code>)
          </li>
          <li>
            Un errore non gestito interrompe completamente lo stream
          </li>
          <li>
            <code>retry</code> senza limite può creare loop infiniti
          </li>
          <li>
            In <code>switchMap</code>, gestisci errori sia nell'outer che nell'inner Observable
          </li>
        </ul>
      </div>

      <div class="mt-4">
        <a routerLink="/operators" class="btn btn-secondary">← Operatori RxJS</a>
        <a routerLink="/memory-leak" class="btn btn-primary ms-2">Memory Leak Prevention →</a>
      </div>
    </div>
  `,
  styles: []
})
export class ErrorHandlingComponent {
  private destroyRef = inject(DestroyRef);

  // Signals per i log
  unhandledLogs = signal<string[]>([]);
  catchErrorLogs = signal<string[]>([]);
  retryLogs = signal<string[]>([]);
  retryWhenLogs = signal<string[]>([]);
  multipleCatchLogs = signal<string[]>([]);

  /**
   * Demo 1: Errore non gestito
   * Dimostra cosa succede quando un errore non viene catturato
   */
  demoUnhandledError() {
    const logs: string[] = [];

    // Observable che fallisce
    const failing$ = new Observable<number>(subscriber => {
      logs.push('✅ Observable iniziato');
      this.unhandledLogs.set([...logs]);

      subscriber.next(1);
      logs.push('✅ Emesso: 1');
      this.unhandledLogs.set([...logs]);

      subscriber.next(2);
      logs.push('✅ Emesso: 2');
      this.unhandledLogs.set([...logs]);

      // Simula un errore
      subscriber.error(new Error('Qualcosa è andato storto!'));
      logs.push('❌ Errore emesso!');
      this.unhandledLogs.set([...logs]);

      // Questo non sarà mai eseguito
      subscriber.next(3);
      subscriber.complete();
    });

    failing$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (value) => {
          logs.push(`  📦 Ricevuto: ${value}`);
          this.unhandledLogs.set([...logs]);
        },
        error: (err) => {
          logs.push(`  ❌ Observer error: ${err.message}`);
          logs.push('');
          logs.push('💡 Lo stream è terminato. Non riceverà più valori.');
          this.unhandledLogs.set([...logs]);
        },
        complete: () => {
          logs.push('  ✅ Complete (non sarà mai chiamato)');
          this.unhandledLogs.set([...logs]);
        }
      });
  }

  /**
   * Demo 2: catchError con fallback
   * Gestisce l'errore e ritorna un valore di default
   */
  demoCatchError() {
    const logs: string[] = [];

    // Observable che potrebbe fallire
    const mayFail$ = this.simulateApiCall(false); // false = fallisce

    mayFail$
      .pipe(
        tap(() => {
          logs.push('📡 Richiesta API in corso...');
          this.catchErrorLogs.set([...logs]);
        }),
        catchError(error => {
          logs.push(`❌ Errore catturato: ${error.message}`);
          logs.push('🔄 Ritorno valore di fallback...');
          this.catchErrorLogs.set([...logs]);

          // Ritorna un Observable con dati di fallback
          return of({ data: 'Dati di fallback', fromCache: true });
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (result) => {
          logs.push(`✅ Dati ricevuti: ${JSON.stringify(result)}`);
          logs.push('');
          logs.push('💡 Lo stream continua grazie a catchError!');
          this.catchErrorLogs.set([...logs]);
        },
        complete: () => {
          logs.push('✅ Stream completato normalmente');
          this.catchErrorLogs.set([...logs]);
        }
      });
  }

  /**
   * Demo 3: retry
   * Riprova automaticamente in caso di errore
   */
  demoRetry() {
    const logs: string[] = [];
    let attemptCount = 0;

    // Observable che fallisce le prime 2 volte
    const unreliable$ = new Observable<string>(subscriber => {
      attemptCount++;
      logs.push(`🔄 Tentativo ${attemptCount}...`);
      this.retryLogs.set([...logs]);

      setTimeout(() => {
        if (attemptCount < 3) {
          logs.push(`  ❌ Tentativo ${attemptCount} fallito`);
          this.retryLogs.set([...logs]);
          subscriber.error(new Error('Errore temporaneo'));
        } else {
          logs.push(`  ✅ Tentativo ${attemptCount} riuscito!`);
          this.retryLogs.set([...logs]);
          subscriber.next('Dati ricevuti con successo');
          subscriber.complete();
        }
      }, 300);
    });

    unreliable$
      .pipe(
        retry(2), // Riprova fino a 2 volte (3 tentativi totali)
        catchError(error => {
          logs.push('');
          logs.push(`❌ Fallito dopo tutti i tentativi: ${error.message}`);
          this.retryLogs.set([...logs]);
          return of('Dati di fallback');
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (data) => {
          logs.push(`📦 Risultato finale: ${data}`);
          this.retryLogs.set([...logs]);
        }
      });
  }

  /**
   * Demo 4: retryWhen con exponential backoff
   * Riprova con attesa crescente tra i tentativi
   */
  demoRetryWhen() {
    const logs: string[] = [];
    let attemptCount = 0;
    const startTime = Date.now();

    const failing$ = new Observable<string>(subscriber => {
      attemptCount++;
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      logs.push(`🔄 Tentativo ${attemptCount} (dopo ${elapsed}s)`);
      this.retryWhenLogs.set([...logs]);

      // Fallisce sempre per mostrare il backoff
      setTimeout(() => {
        subscriber.error(new Error('Errore di rete'));
      }, 100);
    });

    failing$
      .pipe(
        retryWhen(errors =>
          errors.pipe(
            // Exponential backoff: 1s, 2s, 4s
            delayWhen((error, index) => {
              const delay = Math.pow(2, index) * 1000;
              logs.push(`  ⏱️ Attendo ${delay / 1000}s prima del prossimo tentativo...`);
              this.retryWhenLogs.set([...logs]);
              return timer(delay);
            }),
            take(3) // Massimo 3 retry
          )
        ),
        catchError(error => {
          logs.push('');
          logs.push('❌ Tutti i tentativi falliti');
          logs.push('💡 Backoff usato: 1s → 2s → 4s');
          this.retryWhenLogs.set([...logs]);
          return of('Fallback data');
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (data) => {
          logs.push(`✅ Dati ricevuti: ${data}`);
          this.retryWhenLogs.set([...logs]);
        }
      });
  }

  /**
   * Demo 5: Multiple catchError
   * Gestione errori a più livelli
   */
  demoMultipleCatchError() {
    const logs: string[] = [];

    // Simula recupero utente
    const getUser$ = of({ id: 1, name: 'Mario Rossi' }).pipe(
      tap(() => {
        logs.push('1️⃣ Recupero dati utente...');
        this.multipleCatchLogs.set([...logs]);
      })
    );

    // Simula recupero ordini (che fallisce)
    const getOrders$ = (userId: number) =>
      throwError(() => new Error('Database ordini non disponibile')).pipe(
        tap(() => {
          logs.push(`2️⃣ Recupero ordini per user ${userId}...`);
          this.multipleCatchLogs.set([...logs]);
        }),
        catchError(error => {
          logs.push(`  ⚠️ Errore ordini (gestito localmente): ${error.message}`);
          logs.push('  🔄 Ritorno array vuoto come fallback');
          this.multipleCatchLogs.set([...logs]);
          return of([]); // Fallback locale
        })
      );

    getUser$
      .pipe(
        tap(user => {
          logs.push(`  ✅ Utente trovato: ${user.name}`);
          this.multipleCatchLogs.set([...logs]);
        }),
        // switchMap agli ordini
        map(user => ({ user, orders: [] })),
        tap(() => {
          logs.push('');
          logs.push('✅ Operazione completata!');
          logs.push('💡 L\'errore negli ordini è stato gestito localmente');
          logs.push('   permettendo al flusso principale di continuare.');
          this.multipleCatchLogs.set([...logs]);
        }),
        // catchError globale (non sarà usato in questo caso)
        catchError(error => {
          logs.push(`❌ Errore globale: ${error.message}`);
          this.multipleCatchLogs.set([...logs]);
          return of(null);
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (result) => {
          logs.push(`📦 Risultato finale: ${JSON.stringify(result)}`);
          this.multipleCatchLogs.set([...logs]);
        }
      });
  }

  /**
   * Simula una chiamata API che può avere successo o fallire
   */
  private simulateApiCall(shouldSucceed: boolean): Observable<any> {
    return new Observable(subscriber => {
      setTimeout(() => {
        if (shouldSucceed) {
          subscriber.next({ data: 'Dati dall\'API', timestamp: Date.now() });
          subscriber.complete();
        } else {
          subscriber.error(new Error('Errore di rete: 500 Internal Server Error'));
        }
      }, 500);
    });
  }
}
