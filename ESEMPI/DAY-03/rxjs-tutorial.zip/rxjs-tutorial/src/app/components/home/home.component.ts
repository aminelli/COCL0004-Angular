import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

/**
 * Componente Home - Pagina principale con navigazione alle varie sezioni di apprendimento RxJS
 */
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container">
      <div class="text-center mb-5">
        <h1 class="display-4">📚 Tutorial RxJS con Angular 21</h1>
        <p class="lead">Impara RxJS e i suoi operatori principali con esempi pratici</p>
      </div>

      <div class="row g-4">
        <!-- Card 1: Observable Basics -->
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title">🔵 Observable Basics</h5>
              <p class="card-text">
                Scopri i concetti fondamentali: Observable, Observer e Subscription.
                Impara come creare e gestire stream di dati.
              </p>
              <a routerLink="/observable-basics" class="btn btn-primary">Inizia →</a>
            </div>
          </div>
        </div>

        <!-- Card 2: Subject Family -->
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title">🎯 Subject Family</h5>
              <p class="card-text">
                Esplora Subject, BehaviorSubject e ReplaySubject.
                Comprendi le differenze e quando usare ciascuno.
              </p>
              <a routerLink="/subjects" class="btn btn-primary">Inizia →</a>
            </div>
          </div>
        </div>

        <!-- Card 3: Operatori RxJS -->
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title">⚙️ Operatori RxJS</h5>
              <p class="card-text">
                Padroneggia gli operatori: map, filter, tap, switchMap, mergeMap,
                concatMap, debounceTime e combineLatest.
              </p>
              <a routerLink="/operators" class="btn btn-primary">Inizia →</a>
            </div>
          </div>
        </div>

        <!-- Card 4: Gestione Errori -->
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title">⚠️ Gestione Errori</h5>
              <p class="card-text">
                Impara a gestire gli errori in modo robusto con catchError,
                retry e altre strategie di error handling.
              </p>
              <a routerLink="/error-handling" class="btn btn-primary">Inizia →</a>
            </div>
          </div>
        </div>

        <!-- Card 5: Memory Leak Prevention -->
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title">🔒 Prevenzione Memory Leak</h5>
              <p class="card-text">
                Scopri come evitare memory leak nelle subscription con tecniche
                come takeUntil, async pipe e DestroyRef.
              </p>
              <a routerLink="/memory-leak" class="btn btn-primary">Inizia →</a>
            </div>
          </div>
        </div>

        <!-- Card 6: Pattern Comuni -->
        <div class="col-md-6 col-lg-4">
          <div class="card h-100">
            <div class="card-body">
              <h5 class="card-title">🎨 Pattern Comuni</h5>
              <p class="card-text">
                Esplora pattern comuni e best practices per usare RxJS
                in applicazioni Angular reali.
              </p>
              <a routerLink="/common-patterns" class="btn btn-primary">Inizia →</a>
            </div>
          </div>
        </div>
      </div>

      <div class="alert alert-info mt-5" role="alert">
        <h5 class="alert-heading">ℹ️ Informazioni</h5>
        <p>
          Questo progetto è stato creato con <strong>Angular 21</strong> seguendo le best practices:
        </p>
        <ul>
          <li>✅ Zoneless per migliori performance</li>
          <li>✅ Server-Side Rendering (SSR)</li>
          <li>✅ Standalone Components (nessun NgModule)</li>
          <li>✅ Signals per la gestione dello stato</li>
          <li>✅ Bootstrap 5 per UI responsive</li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.2s, box-shadow 0.2s;
      border: 1px solid #dee2e6;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .card-title {
      color: #212529;
      font-weight: 600;
    }

    .btn-primary {
      width: 100%;
    }
  `]
})
export class HomeComponent {}
