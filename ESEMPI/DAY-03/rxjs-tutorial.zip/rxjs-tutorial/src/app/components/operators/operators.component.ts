import { Component, signal, DestroyRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {
  of,
  from,
  interval,
  combineLatest,
  Subject,
  Observable
} from 'rxjs';
import {
  map,
  filter,
  tap,
  switchMap,
  mergeMap,
  concatMap,
  debounceTime,
  take
} from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Componente che dimostra gli operatori RxJS fondamentali:
 * - map: trasforma ogni valore emesso
 * - filter: filtra valori in base a una condizione
 * - tap: effetti collaterali senza modificare il valore
 * - switchMap: switching a nuovo Observable, cancella il precedente
 * - mergeMap: esegue Observable in parallelo
 * - concatMap: esegue Observable in sequenza
 * - debounceTime: emette dopo un periodo di silenzio
 * - combineLatest: combina ultimi valori di multipli Observable
 */
@Component({
  selector: 'app-operators',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="container">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a routerLink="/">Home</a></li>
          <li class="breadcrumb-item active">Operatori RxJS</li>
        </ol>
      </nav>

      <h1 class="mb-4">⚙️ Operatori RxJS</h1>

      <div class="alert alert-info">
        <strong>💡 Cosa sono gli Operatori?</strong><br>
        Gli operatori sono funzioni che trasformano, filtrano o combinano Observable.
        Si usano dentro il metodo <code>pipe()</code> per costruire pipeline di trasformazione dati.
      </div>

      <!-- Sezione 1: map -->
      <div class="demo-section">
        <h3>1. map - Trasformazione</h3>
        <p>
          <code>map</code> trasforma ogni valore emesso dall'Observable applicando una funzione.
          Simile a <code>Array.map()</code>.
        </p>

        <div class="code-block">
          of(1, 2, 3, 4, 5).pipe(<br>
          &nbsp;&nbsp;map(x => x * 10)<br>
          ).subscribe(value => console.log(value));<br>
          // Output: 10, 20, 30, 40, 50
        </div>

        <button class="btn btn-primary" (click)="demoMap()">
          Esegui map
        </button>

        <div class="result-box">
          <strong>Input:</strong> [1, 2, 3, 4, 5]<br>
          <strong>Trasformazione:</strong> x => x * 10<br>
          <strong>Output:</strong> {{ mapResult() || 'Click per vedere il risultato' }}
        </div>
      </div>

      <!-- Sezione 2: filter -->
      <div class="demo-section">
        <h3>2. filter - Filtro</h3>
        <p>
          <code>filter</code> emette solo i valori che soddisfano una condizione.
          Simile a <code>Array.filter()</code>.
        </p>

        <div class="code-block">
          of(1, 2, 3, 4, 5, 6).pipe(<br>
          &nbsp;&nbsp;filter(x => x % 2 === 0) // solo numeri pari<br>
          ).subscribe(value => console.log(value));<br>
          // Output: 2, 4, 6
        </div>

        <button class="btn btn-primary" (click)="demoFilter()">
          Esegui filter
        </button>

        <div class="result-box">
          <strong>Input:</strong> [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]<br>
          <strong>Condizione:</strong> x % 2 === 0 (solo pari)<br>
          <strong>Output:</strong> {{ filterResult() || 'Click per vedere il risultato' }}
        </div>
      </div>

      <!-- Sezione 3: tap -->
      <div class="demo-section">
        <h3>3. tap - Effetti Collaterali</h3>
        <p>
          <code>tap</code> esegue effetti collaterali (es: logging) senza modificare i valori.
          Utile per debugging e operazioni che non alterano lo stream.
        </p>

        <div class="code-block">
          of(1, 2, 3).pipe(<br>
          &nbsp;&nbsp;tap(x => console.log('Before:', x)),<br>
          &nbsp;&nbsp;map(x => x * 2),<br>
          &nbsp;&nbsp;tap(x => console.log('After:', x))<br>
          ).subscribe();
        </div>

        <button class="btn btn-primary" (click)="demoTap()">
          Esegui tap
        </button>

        <div class="result-box">
          <div *ngFor="let log of tapLogs()">{{ log }}</div>
        </div>
      </div>

      <!-- Sezione 4: debounceTime -->
      <div class="demo-section">
        <h3>4. debounceTime - Ritardo Emissione</h3>
        <p>
          <code>debounceTime</code> emette un valore solo dopo un periodo di "silenzio".
          Perfetto per search box e input utente.
        </p>

        <div class="code-block">
          searchInput$.pipe(<br>
          &nbsp;&nbsp;debounceTime(500) // attende 500ms di silenzio<br>
          ).subscribe(value => search(value));
        </div>

        <div class="mb-3">
          <label class="form-label">Scrivi qualcosa (debounce: 500ms):</label>
          <input
            type="text"
            class="form-control"
            [ngModel]="searchText()"
            (ngModelChange)="onSearchChange($event)"
            placeholder="Inizia a digitare...">
        </div>

        <div class="result-box">
          <strong>Ricerca eseguita per:</strong> {{ debouncedSearch() || 'Nessuna ricerca ancora' }}<br>
          <small class="text-muted">
            La ricerca parte solo dopo 500ms dall'ultimo carattere digitato
          </small>
        </div>
      </div>

      <!-- Sezione 5: switchMap -->
      <div class="demo-section">
        <h3>5. switchMap - Cambia Observable (Cancella precedente)</h3>
        <p>
          <code>switchMap</code> passa a un nuovo Observable <strong>cancellando</strong> quello precedente.
          Ideale per ricerche/autocomplete dove solo l'ultima richiesta conta.
        </p>

        <div class="code-block">
          searchInput$.pipe(<br>
          &nbsp;&nbsp;debounceTime(300),<br>
          &nbsp;&nbsp;switchMap(query => http.get('/api/search?q=' + query))<br>
          ).subscribe(results => display(results));
        </div>

        <button class="btn btn-primary" (click)="demoSwitchMap()">
          Simula Ricerca con switchMap
        </button>

        <div class="result-box">
          <div *ngFor="let log of switchMapLogs()">{{ log }}</div>
          <div *ngIf="switchMapLogs().length === 0" class="text-muted">
            Click per vedere come switchMap cancella richieste precedenti
          </div>
        </div>
      </div>

      <!-- Sezione 6: mergeMap -->
      <div class="demo-section">
        <h3>6. mergeMap - Esecuzione Parallela</h3>
        <p>
          <code>mergeMap</code> esegue Observable in <strong>parallelo</strong>.
          Non cancella Observable precedenti, tutti vengono completati.
        </p>

        <div class="code-block">
          of('file1', 'file2', 'file3').pipe(<br>
          &nbsp;&nbsp;mergeMap(file => http.get('/api/' + file)) // richieste parallele<br>
          ).subscribe(data => console.log(data));
        </div>

        <button class="btn btn-primary" (click)="demoMergeMap()">
          Simula Download Paralleli
        </button>

        <div class="result-box">
          <div *ngFor="let log of mergeMapLogs()">{{ log }}</div>
          <div *ngIf="mergeMapLogs().length === 0" class="text-muted">
            Click per vedere download in parallelo
          </div>
        </div>
      </div>

      <!-- Sezione 7: concatMap -->
      <div class="demo-section">
        <h3>7. concatMap - Esecuzione Sequenziale</h3>
        <p>
          <code>concatMap</code> esegue Observable in <strong>sequenza</strong>.
          Aspetta che il precedente completi prima di iniziare il prossimo.
        </p>

        <div class="code-block">
          of('task1', 'task2', 'task3').pipe(<br>
          &nbsp;&nbsp;concatMap(task => executeTask(task)) // uno alla volta<br>
          ).subscribe(result => console.log(result));
        </div>

        <button class="btn btn-primary" (click)="demoConcatMap()">
          Simula Task Sequenziali
        </button>

        <div class="result-box">
          <div *ngFor="let log of concatMapLogs()">{{ log }}</div>
          <div *ngIf="concatMapLogs().length === 0" class="text-muted">
            Click per vedere esecuzione sequenziale
          </div>
        </div>
      </div>

      <!-- Sezione 8: combineLatest -->
      <div class="demo-section">
        <h3>8. combineLatest - Combina Observable</h3>
        <p>
          <code>combineLatest</code> combina gli ultimi valori di più Observable.
          Emette quando <strong>qualsiasi</strong> Observable emette (dopo che tutti hanno emesso almeno una volta).
        </p>

        <div class="code-block">
          combineLatest([price$, quantity$]).pipe(<br>
          &nbsp;&nbsp;map(([price, qty]) => price * qty)<br>
          ).subscribe(total => console.log('Total:', total));
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <label class="form-label">Prezzo: €{{ price() }}</label>
            <input
              type="range"
              class="form-range"
              min="1"
              max="100"
              [value]="price()"
              (input)="updatePrice($event)">
          </div>
          <div class="col-md-6">
            <label class="form-label">Quantità: {{ quantity() }}</label>
            <input
              type="range"
              class="form-range"
              min="1"
              max="10"
              [value]="quantity()"
              (input)="updateQuantity($event)">
          </div>
        </div>

        <div class="result-box">
          <h4>Totale: €{{ total() }}</h4>
          <small class="text-muted">
            Il totale si aggiorna automaticamente quando cambi prezzo o quantità
          </small>
        </div>
      </div>

      <!-- Confronto switchMap vs mergeMap vs concatMap -->
      <div class="demo-section">
        <h3>9. 📊 Confronto: switchMap vs mergeMap vs concatMap</h3>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead class="table-light">
              <tr>
                <th>Operatore</th>
                <th>Comportamento</th>
                <th>Uso Comune</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>switchMap</strong></td>
                <td>Cancella Observable precedenti</td>
                <td>Search, autocomplete, navigazione</td>
              </tr>
              <tr>
                <td><strong>mergeMap</strong></td>
                <td>Esegue in parallelo, mantiene tutti</td>
                <td>Download multipli, operazioni indipendenti</td>
              </tr>
              <tr>
                <td><strong>concatMap</strong></td>
                <td>Esegue in sequenza, uno alla volta</td>
                <td>Operazioni ordinate, transazioni, upload</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Best Practices -->
      <div class="alert alert-success">
        <h5>✅ Best Practices</h5>
        <ul class="mb-0">
          <li>Usa <code>map</code> per trasformazioni semplici di valori</li>
          <li>Usa <code>filter</code> per escludere valori non necessari presto nella pipeline</li>
          <li>Usa <code>tap</code> per logging e debugging (non per trasformazioni)</li>
          <li>Usa <code>switchMap</code> per ricerche dove solo l'ultimo risultato conta</li>
          <li>Usa <code>mergeMap</code> quando vuoi eseguire richieste in parallelo</li>
          <li>Usa <code>concatMap</code> quando l'ordine di esecuzione è importante</li>
          <li>Usa <code>debounceTime</code> per input utente (search, autocomplete)</li>
          <li>Usa <code>combineLatest</code> per combinare multipli valori reattivi</li>
        </ul>
      </div>

      <div class="mt-4">
        <a routerLink="/subjects" class="btn btn-secondary">← Subject Family</a>
        <a routerLink="/error-handling" class="btn btn-primary ms-2">Gestione Errori →</a>
      </div>
    </div>
  `,
  styles: [`
    .form-range {
      cursor: pointer;
    }
  `]
})
export class OperatorsComponent {
  private destroyRef = inject(DestroyRef);

  // Signals per i risultati
  mapResult = signal<string>('');
  filterResult = signal<string>('');
  tapLogs = signal<string[]>([]);

  // debounceTime demo
  searchText = signal<string>('');
  debouncedSearch = signal<string>('');
  private searchSubject = new Subject<string>();

  // switchMap demo
  switchMapLogs = signal<string[]>([]);

  // mergeMap demo
  mergeMapLogs = signal<string[]>([]);

  // concatMap demo
  concatMapLogs = signal<string[]>([]);

  // combineLatest demo
  price = signal<number>(10);
  quantity = signal<number>(1);
  total = signal<number>(10);
  private priceSubject = new Subject<number>();
  private quantitySubject = new Subject<number>();

  constructor() {
    this.setupDebounceSearch();
    this.setupCombineLatest();
  }

  /**
   * OPERATORE 1: map
   * Trasforma ogni valore emesso dall'Observable
   */
  demoMap() {
    const numbers$ = of(1, 2, 3, 4, 5);

    const results: number[] = [];

    numbers$
      .pipe(
        map(x => x * 10), // Moltiplica ogni numero per 10
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (value) => {
          results.push(value);
        },
        complete: () => {
          this.mapResult.set(results.join(', '));
        }
      });
  }

  /**
   * OPERATORE 2: filter
   * Emette solo i valori che soddisfano la condizione
   */
  demoFilter() {
    const numbers$ = of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

    const results: number[] = [];

    numbers$
      .pipe(
        filter(x => x % 2 === 0), // Solo numeri pari
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (value) => {
          results.push(value);
        },
        complete: () => {
          this.filterResult.set(results.join(', '));
        }
      });
  }

  /**
   * OPERATORE 3: tap
   * Esegue effetti collaterali senza modificare i valori
   */
  demoTap() {
    const logs: string[] = [];

    of(1, 2, 3)
      .pipe(
        tap(x => {
          logs.push(`🔵 Before map: ${x}`);
          this.tapLogs.set([...logs]);
        }),
        map(x => x * 2),
        tap(x => {
          logs.push(`🟢 After map: ${x}`);
          this.tapLogs.set([...logs]);
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        complete: () => {
          logs.push('✅ Stream completato!');
          this.tapLogs.set([...logs]);
        }
      });
  }

  /**
   * OPERATORE 4: debounceTime
   * Configurazione per la ricerca con debounce
   */
  setupDebounceSearch() {
    this.searchSubject
      .pipe(
        debounceTime(500), // Aspetta 500ms di silenzio
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(searchTerm => {
        // Simula una ricerca
        this.debouncedSearch.set(searchTerm);
        console.log('🔍 Ricerca eseguita per:', searchTerm);
      });
  }

  onSearchChange(value: string) {
    this.searchText.set(value);
    // Emette il valore al Subject, che applicherà il debounce
    this.searchSubject.next(value);
  }

  /**
   * OPERATORE 5: switchMap
   * Simula ricerche API con switchMap che cancella richieste precedenti
   */
  demoSwitchMap() {
    const searches = ['A', 'AB', 'ABC'];
    const logs: string[] = [];

    from(searches)
      .pipe(
        tap(query => {
          logs.push(`🔵 Cerco: "${query}"`);
          this.switchMapLogs.set([...logs]);
        }),
        // switchMap cancella la ricerca precedente quando arriva una nuova
        switchMap(query => this.simulateApiCall(query)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (result) => {
          logs.push(`✅ Risultato ricevuto: ${result}`);
          this.switchMapLogs.set([...logs]);
        },
        complete: () => {
          logs.push('');
          logs.push('💡 Nota: Solo l\'ultima ricerca ("ABC") completa!');
          this.switchMapLogs.set([...logs]);
        }
      });
  }

  /**
   * OPERATORE 6: mergeMap
   * Esegue Observable in parallelo
   */
  demoMergeMap() {
    const files = ['file1.txt', 'file2.txt', 'file3.txt'];
    const logs: string[] = [];

    from(files)
      .pipe(
        tap(file => {
          logs.push(`📥 Inizio download: ${file}`);
          this.mergeMapLogs.set([...logs]);
        }),
        // mergeMap esegue tutti i download in parallelo
        mergeMap(file => this.simulateDownload(file)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (result) => {
          logs.push(`✅ Completato: ${result}`);
          this.mergeMapLogs.set([...logs]);
        },
        complete: () => {
          logs.push('');
          logs.push('💡 Tutti i download sono stati eseguiti in parallelo!');
          this.mergeMapLogs.set([...logs]);
        }
      });
  }

  /**
   * OPERATORE 7: concatMap
   * Esegue Observable in sequenza
   */
  demoConcatMap() {
    const tasks = ['Task 1', 'Task 2', 'Task 3'];
    const logs: string[] = [];

    from(tasks)
      .pipe(
        tap(task => {
          logs.push(`▶️ Inizio: ${task}`);
          this.concatMapLogs.set([...logs]);
        }),
        // concatMap aspetta che ogni task completi prima di iniziare il prossimo
        concatMap(task => this.simulateTask(task)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (result) => {
          logs.push(`✅ Completato: ${result}`);
          this.concatMapLogs.set([...logs]);
        },
        complete: () => {
          logs.push('');
          logs.push('💡 I task sono stati eseguiti uno alla volta in ordine!');
          this.concatMapLogs.set([...logs]);
        }
      });
  }

  /**
   * OPERATORE 8: combineLatest
   * Combina gli ultimi valori di più Observable
   */
  setupCombineLatest() {
    // Emetti valori iniziali
    this.priceSubject.next(this.price());
    this.quantitySubject.next(this.quantity());

    // Combina price e quantity per calcolare il totale
    combineLatest([
      this.priceSubject,
      this.quantitySubject
    ])
      .pipe(
        map(([price, qty]) => price * qty),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(total => {
        this.total.set(total);
        console.log(`💰 Totale aggiornato: €${total}`);
      });
  }

  updatePrice(event: Event) {
    const value = +(event.target as HTMLInputElement).value;
    this.price.set(value);
    this.priceSubject.next(value);
  }

  updateQuantity(event: Event) {
    const value = +(event.target as HTMLInputElement).value;
    this.quantity.set(value);
    this.quantitySubject.next(value);
  }

  // === Funzioni di utilità per simulare operazioni asincrone ===

  /**
   * Simula una chiamata API con delay random
   */
  private simulateApiCall(query: string): Observable<string> {
    const delay = Math.random() * 1000 + 500;
    return new Observable(subscriber => {
      const timeoutId = setTimeout(() => {
        subscriber.next(`Risultati per "${query}"`);
        subscriber.complete();
      }, delay);

      // Cleanup se viene cancellato (switchMap)
      return () => {
        clearTimeout(timeoutId);
        console.log(`❌ Ricerca "${query}" cancellata`);
      };
    });
  }

  /**
   * Simula download di un file
   */
  private simulateDownload(filename: string): Observable<string> {
    const delay = Math.random() * 1000 + 500;
    return new Observable(subscriber => {
      setTimeout(() => {
        subscriber.next(filename);
        subscriber.complete();
      }, delay);
    });
  }

  /**
   * Simula esecuzione di un task con delay
   */
  private simulateTask(taskName: string): Observable<string> {
    const delay = 800;
    return new Observable(subscriber => {
      setTimeout(() => {
        subscriber.next(taskName);
        subscriber.complete();
      }, delay);
    });
  }
}
