import { Component, signal, DestroyRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {
  Observable,
  BehaviorSubject,
  Subject,
  merge,
  combineLatest,
  race,
  forkJoin,
  of,
  timer,
  interval
} from 'rxjs';
import {
  shareReplay,
  distinctUntilChanged,
  debounceTime,
  switchMap,
  map,
  startWith,
  scan,
  withLatestFrom,
  exhaustMap,
  tap,
  take
} from 'rxjs/operators';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';

/**
 * Componente che dimostra pattern comuni di RxJS in Angular:
 * - State Management con BehaviorSubject
 * - Caching con shareReplay
 * - Auto-complete con debounceTime + switchMap
 * - Loading states
 * - Combinare multipli Observable
 * - toSignal (Observable -> Signal)
 * - Event Bus pattern
 * - Multi-cast con share
 */
@Component({
  selector: 'app-common-patterns',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="container">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a routerLink="/">Home</a></li>
          <li class="breadcrumb-item active">Pattern Comuni</li>
        </ol>
      </nav>

      <h1 class="mb-4">🎨 Pattern Comuni RxJS</h1>

      <div class="alert alert-info">
        <strong>💡 Pattern RxJS in Angular</strong><br>
        Questi sono pattern comuni che vedrai in applicazioni Angular reali.
        Impararli ti renderà molto più produttivo!
      </div>

      <!-- Pattern 1: State Management -->
      <div class="demo-section">
        <h3>1. 📦 State Management con BehaviorSubject</h3>
        <p>
          Pattern per gestire lo stato globale in un servizio.
          Simile a Redux ma più semplice per stati piccoli/medi.
        </p>

        <div class="code-block">
          // Service<br>
          @Injectable({{'{'}} providedIn: 'root' {{'}'}})<br>
          export class CounterService {{'{'}}
          <br>&nbsp;&nbsp;private state$ = new BehaviorSubject&lt;number&gt;(0);
          <br>&nbsp;&nbsp;counter$ = this.state$.asObservable();
          <br>
          <br>&nbsp;&nbsp;increment() {{'{'}} this.state$.next(this.state$.value + 1); {{'}'}}
          <br>&nbsp;&nbsp;decrement() {{'{'}} this.state$.next(this.state$.value - 1); {{'}'}}
          <br>&nbsp;&nbsp;reset() {{'{'}} this.state$.next(0); {{'}'}}
          <br>{{'}'}}
        </div>

        <div class="d-flex gap-2 mb-3">
          <button class="btn btn-success" (click)="increment()">➕ Increment</button>
          <button class="btn btn-danger" (click)="decrement()">➖ Decrement</button>
          <button class="btn btn-secondary" (click)="resetCounter()">🔄 Reset</button>
        </div>

        <div class="result-box">
          <h4>Counter: {{ counter$ | async }}</h4>
          <small class="text-muted">Gestito tramite BehaviorSubject + async pipe</small>
        </div>
      </div>

      <!-- Pattern 2: Caching con shareReplay -->
      <div class="demo-section">
        <h3>2. 💾 Caching con shareReplay</h3>
        <p>
          <code>shareReplay</code> esegue la richiesta una sola volta e condivide il risultato
          con tutti i subscriber. Perfetto per cachare chiamate HTTP.
        </p>

        <div class="code-block">
          private usersCache$ = this.http.get('/api/users').pipe(<br>
          &nbsp;&nbsp;shareReplay(1) // Cache l'ultimo risultato
          <br>);
          <br><br>
          // Multipli subscriber ricevono lo stesso dato senza nuove richieste
        </div>

        <button class="btn btn-primary" (click)="loadCachedData()">
          📡 Carica Dati (solo la prima volta fa richiesta)
        </button>

        <div class="result-box">
          <div><strong>Richieste fatte:</strong> {{ requestCount() }}</div>
          <div><strong>Subscriber:</strong> {{ subscriberCount() }}</div>
          <div *ngIf="cachedData().length > 0">
            <strong>Dati:</strong> {{ cachedData().join(', ') }}
          </div>
          <small class="text-muted">
            Anche con multipli subscriber, la "richiesta" viene fatta solo una volta
          </small>
        </div>
      </div>

      <!-- Pattern 3: Search/Autocomplete -->
      <div class="demo-section">
        <h3>3. 🔍 Search / Autocomplete Pattern</h3>
        <p>
          Combinazione di <code>debounceTime</code> + <code>distinctUntilChanged</code> +
          <code>switchMap</code> per ricerche efficienti.
        </p>

        <div class="code-block">
          searchTerm$.pipe(<br>
          &nbsp;&nbsp;debounceTime(300), // Aspetta 300ms di silenzio
          <br>&nbsp;&nbsp;distinctUntilChanged(), // Solo se il valore cambia
          <br>&nbsp;&nbsp;switchMap(term => this.searchAPI(term)) // Nuova ricerca
          <br>).subscribe(results => this.displayResults(results));
        </div>

        <div class="mb-3">
          <input
            type="text"
            class="form-control"
            placeholder="Cerca frutta..."
            [ngModel]="searchTerm()"
            (ngModelChange)="onSearchTermChange($event)">
        </div>

        <div class="result-box">
          <div *ngIf="searching()">
            <div class="spinner-border spinner-border-sm me-2"></div>
            Cercando...
          </div>
          <div *ngIf="!searching() && searchResults().length > 0">
            <strong>Risultati:</strong>
            <ul class="mb-0">
              <li *ngFor="let result of searchResults()">{{ result }}</li>
            </ul>
          </div>
          <div *ngIf="!searching() && searchResults().length === 0 && searchTerm()">
            Nessun risultato
          </div>
        </div>
      </div>

      <!-- Pattern 4: Loading States -->
      <div class="demo-section">
        <h3>4. ⏳ Loading States Pattern</h3>
        <p>
          Gestire stati di loading, success ed error in modo pulito.
        </p>

        <div class="code-block">
          interface LoadingState&lt;T&gt; {{'{'}}
          <br>&nbsp;&nbsp;loading: boolean;
          <br>&nbsp;&nbsp;data: T | null;
          <br>&nbsp;&nbsp;error: string | null;
          <br>{{'}'}}
        </div>

        <button class="btn btn-primary" (click)="loadData()" [disabled]="loadingState().loading">
          {{ loadingState().loading ? '⏳ Caricamento...' : '📥 Carica Dati' }}
        </button>

        <div class="result-box">
          <div *ngIf="loadingState().loading">
            <div class="spinner-border spinner-border-sm me-2"></div>
            Loading...
          </div>
          <div *ngIf="loadingState().error" class="text-danger">
            ❌ Errore: {{ loadingState().error }}
          </div>
          <div *ngIf="loadingState().data">
            ✅ Dati: {{ loadingState().data }}
          </div>
        </div>
      </div>

      <!-- Pattern 5: Observable -> Signal -->
      <div class="demo-section">
        <h3>5. 🔄 toSignal - Da Observable a Signal</h3>
        <p>
          Angular 21 permette di convertire Observable in Signal usando <code>toSignal()</code>.
          Combina il meglio di RxJS e Signals!
        </p>

        <div class="code-block">
          // Da Observable a Signal<br>
          timer$ = interval(1000);<br>
          timerSignal = toSignal(this.timer$, {{'{'}} initialValue: 0 {{'}'}});
          <br><br>
          // Usa nel template come un signal<br>
          &lt;div&gt;Timer: {{'{{ timerSignal() }}'}} &lt;/div&gt;
        </div>

        <button class="btn btn-info" (click)="startTimer()">
          ▶️ Avvia Timer (Observable → Signal)
        </button>

        <div class="result-box">
          <strong>Timer Value (da Signal):</strong> {{ timerSignal() }}
        </div>

        <div class="alert alert-success mt-3">
          <strong>✅ Vantaggi toSignal:</strong>
          <ul class="mb-0">
            <li>No async pipe necessaria</li>
            <li>Auto-unsubscribe quando il componente è distrutto</li>
            <li>Integrazione perfetta con il sistema di signals</li>
            <li>Computed signals possono derivare da toSignal</li>
          </ul>
        </div>
      </div>

      <!-- Pattern 6: Combining Observables -->
      <div class="demo-section">
        <h3>6. 🔀 Combinare Multiple Observable</h3>

        <h5>combineLatest - Tutti i valori più recenti</h5>
        <div class="code-block mb-3">
          combineLatest([price$, quantity$, discount$]).pipe(<br>
          &nbsp;&nbsp;map(([p, q, d]) => p * q * (1 - d))<br>
          )
        </div>

        <h5>forkJoin - Aspetta che tutti completino</h5>
        <div class="code-block mb-3">
          forkJoin({{'{'}}
          <br>&nbsp;&nbsp;user: http.get('/user/1'),
          <br>&nbsp;&nbsp;posts: http.get('/posts'),
          <br>&nbsp;&nbsp;comments: http.get('/comments')
          <br>{{'}''}}).subscribe(({{'{'}}user, posts, comments{{'}'}}) => /*...*/ );
        </div>

        <h5>merge - Unisce stream multipli</h5>
        <div class="code-block mb-3">
          merge(clicks$, touches$, keyPress$).subscribe(event => /*...*/)
        </div>

        <h5>race - Primo che emette vince</h5>
        <div class="code-block">
          race([server1$, server2$, server3$]) // Usa il server più veloce
        </div>

        <button class="btn btn-primary" (click)="demoForkJoin()">
          Demo forkJoin (Parallel Requests)
        </button>

        <div class="result-box">
          <div *ngFor="let log of forkJoinLogs()">{{ log }}</div>
        </div>
      </div>

      <!-- Pattern 7: Event Bus -->
      <div class="demo-section">
        <h3>7. 📡 Event Bus Pattern</h3>
        <p>
          Subject come event bus per comunicazione tra componenti non correlati.
        </p>

        <div class="code-block">
          @Injectable({{'{'}} providedIn: 'root' {{'}'}})<br>
          export class EventBusService {{'{'}}
          <br>&nbsp;&nbsp;private events$ = new Subject&lt;AppEvent&gt;();
          <br>
          <br>&nbsp;&nbsp;emit(event: AppEvent) {{'{'}} this.events$.next(event); {{'}'}}
          <br>&nbsp;&nbsp;on(eventType: string) {{'{'}}
          <br>&nbsp;&nbsp;&nbsp;&nbsp;return this.events$.pipe(filter(e => e.type === eventType));
          <br>&nbsp;&nbsp;{{'}'}}
          <br>{{'}'}}
        </div>

        <div class="d-flex gap-2 mb-3">
          <button class="btn btn-primary" (click)="emitEvent('USER_LOGIN')">
            Emit: USER_LOGIN
          </button>
          <button class="btn btn-success" (click)="emitEvent('DATA_SAVED')">
            Emit: DATA_SAVED
          </button>
          <button class="btn btn-warning" (click)="emitEvent('NOTIFICATION')">
            Emit: NOTIFICATION
          </button>
        </div>

        <div class="result-box">
          <strong>Eventi ricevuti:</strong>
          <div *ngFor="let event of eventBusLogs()">{{ event }}</div>
        </div>
      </div>

      <!-- Pattern 8: withLatestFrom -->
      <div class="demo-section">
        <h3>8. 🎯 withLatestFrom - Combina con Ultimo Valore</h3>
        <p>
          Utile quando vuoi combinare un evento con lo stato corrente.
        </p>

        <div class="code-block">
          // Quando utente salva, prendi anche lo stato corrente<br>
          saveButton$.pipe(<br>
          &nbsp;&nbsp;withLatestFrom(currentFormData$, userPreferences$),
          <br>&nbsp;&nbsp;map(([click, formData, prefs]) => ({{'{'}} formData, prefs {{'}'}}))<br>
          ).subscribe(data => saveToServer(data));
        </div>

        <div class="alert alert-info">
          <strong>Differenza con combineLatest:</strong><br>
          <code>withLatestFrom</code> emette solo quando l'Observable principale emette,
          mentre <code>combineLatest</code> emette quando qualsiasi Observable emette.
        </div>
      </div>

      <!-- Pattern 9: exhaustMap -->
      <div class="demo-section">
        <h3>9. 🛡️ exhaustMap - Ignora Click Multipli</h3>
        <p>
          Perfetto per prevenire submit multipli di form o doppi click.
        </p>

        <div class="code-block">
          saveButton$.pipe(<br>
          &nbsp;&nbsp;exhaustMap(() => http.post('/api/save', data))<br>
          ).subscribe();
          <br><br>
          // Click successivi mentre la richiesta è in corso vengono ignorati
        </div>

        <button class="btn btn-primary" (click)="demoExhaustMap()">
          💾 Salva (ignora click multipli)
        </button>

        <div class="result-box">
          <div *ngFor="let log of exhaustMapLogs()">{{ log }}</div>
        </div>
      </div>

      <!-- Best Practices Summary -->
      <div class="alert alert-success">
        <h5>✅ Best Practices Riassunto</h5>
        <ul class="mb-0">
          <li><strong>State Management:</strong> BehaviorSubject in servizi + async pipe</li>
          <li><strong>HTTP Caching:</strong> shareReplay per evitare richieste duplicate</li>
          <li><strong>Search:</strong> debounceTime + distinctUntilChanged + switchMap</li>
          <li><strong>Loading States:</strong> Oggetto stato con loading/data/error</li>
          <li><strong>Observable → Signal:</strong> toSignal() per integrazione Angular 21</li>
          <li><strong>Parallel Requests:</strong> forkJoin quando aspetti che tutti completino</li>
          <li><strong>Event Bus:</strong> Subject per comunicazione cross-component</li>
          <li><strong>Prevent Multiple Clicks:</strong> exhaustMap per operazioni async</li>
        </ul>
      </div>

      <div class="mt-4">
        <a routerLink="/memory-leak" class="btn btn-secondary">← Memory Leak Prevention</a>
        <a routerLink="/" class="btn btn-primary ms-2">🏠 Torna alla Home</a>
      </div>
    </div>
  `,
  styles: []
})
export class CommonPatternsComponent {
  private destroyRef = inject(DestroyRef);

  // Pattern 1: State Management
  private counterState$ = new BehaviorSubject<number>(0);
  counter$ = this.counterState$.asObservable();

  // Pattern 2: Caching
  private cachedDataSource$ = this.createCachedObservable();
  requestCount = signal<number>(0);
  subscriberCount = signal<number>(0);
  cachedData = signal<string[]>([]);

  // Pattern 3: Search
  private searchSubject = new Subject<string>();
  searchTerm = signal<string>('');
  searchResults = signal<string[]>([]);
  searching = signal<boolean>(false);

  // Pattern 4: Loading States
  loadingState = signal<{loading: boolean, data: string | null, error: string | null}>({
    loading: false,
    data: null,
    error: null
  });

  // Pattern 5: toSignal
  private timerObservable$ = new Subject<number>();
  timerSignal = toSignal(this.timerObservable$, { initialValue: 0 });

  // Pattern 6: forkJoin
  forkJoinLogs = signal<string[]>([]);

  // Pattern 7: Event Bus
  private eventBus$ = new Subject<{type: string, data?: any}>();
  eventBusLogs = signal<string[]>([]);

  // Pattern 9: exhaustMap
  private saveSubject = new Subject<void>();
  exhaustMapLogs = signal<string[]>([]);

  constructor() {
    this.setupSearchPattern();
    this.setupEventBus();
    this.setupExhaustMap();
  }

  // === Pattern 1: State Management ===

  increment() {
    this.counterState$.next(this.counterState$.value + 1);
  }

  decrement() {
    this.counterState$.next(this.counterState$.value - 1);
  }

  resetCounter() {
    this.counterState$.next(0);
  }

  // === Pattern 2: Caching con shareReplay ===

  private createCachedObservable(): Observable<string[]> {
    return new Observable<string[]>(subscriber => {
      // Simula una richiesta HTTP
      this.requestCount.update(count => count + 1);
      console.log('🌐 Richiesta HTTP eseguita!');

      setTimeout(() => {
        subscriber.next(['Item 1', 'Item 2', 'Item 3']);
        subscriber.complete();
      }, 500);
    }).pipe(
      shareReplay(1) // Cache l'ultimo risultato
    );
  }

  loadCachedData() {
    this.subscriberCount.update(count => count + 1);

    this.cachedDataSource$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(data => {
        this.cachedData.set(data);
        console.log('📦 Dati ricevuti da cache/request');
      });
  }

  // === Pattern 3: Search/Autocomplete ===

  private setupSearchPattern() {
    this.searchSubject
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        tap(() => this.searching.set(true)),
        switchMap(term => this.performSearch(term)),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe(results => {
        this.searchResults.set(results);
        this.searching.set(false);
      });
  }

  onSearchTermChange(term: string) {
    this.searchTerm.set(term);
    this.searchSubject.next(term);
  }

  private performSearch(term: string): Observable<string[]> {
    const fruits = [
      '🍎 Mela', '🍌 Banana', '🍊 Arancia', '🍇 Uva',
      '🍓 Fragola', '🍑 Pesca', '🍍 Ananas', '🥝 Kiwi'
    ];

    return timer(500).pipe(
      map(() => {
        if (!term) return [];
        return fruits.filter(f =>
          f.toLowerCase().includes(term.toLowerCase())
        );
      })
    );
  }

  // === Pattern 4: Loading States ===

  loadData() {
    // Reset state
    this.loadingState.set({ loading: true, data: null, error: null });

    // Simula richiesta che può fallire
    const shouldFail = Math.random() > 0.5;

    timer(1500)
      .pipe(
        switchMap(() => {
          if (shouldFail) {
            throw new Error('Connessione fallita');
          }
          return of('Dati caricati con successo! 🎉');
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe({
        next: (data) => {
          this.loadingState.set({ loading: false, data, error: null });
        },
        error: (error) => {
          this.loadingState.set({ loading: false, data: null, error: error.message });
        }
      });
  }

  // === Pattern 5: toSignal ===

  startTimer() {
    let count = 0;
    interval(1000)
      .pipe(
        take(10),
        tap(val => {
          this.timerObservable$.next(val);
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe();
  }

  // === Pattern 6: Combining Observables ===

  demoForkJoin() {
    const logs: string[] = [];
    logs.push('🚀 Avvio richieste parallele...');
    this.forkJoinLogs.set([...logs]);

    // Simula 3 richieste HTTP parallele
    const request1$ = timer(1000).pipe(map(() => 'User Data'));
    const request2$ = timer(800).pipe(map(() => 'Posts Data'));
    const request3$ = timer(1200).pipe(map(() => 'Comments Data'));

    forkJoin({
      user: request1$,
      posts: request2$,
      comments: request3$
    })
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(result => {
        logs.push(`✅ User: ${result.user}`);
        logs.push(`✅ Posts: ${result.posts}`);
        logs.push(`✅ Comments: ${result.comments}`);
        logs.push('');
        logs.push('🎉 Tutte le richieste completate!');
        this.forkJoinLogs.set([...logs]);
      });
  }

  // === Pattern 7: Event Bus ===

  private setupEventBus() {
    this.eventBus$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(event => {
        const timestamp = new Date().toLocaleTimeString();
        const log = `[${timestamp}] 📡 Event: ${event.type}`;
        this.eventBusLogs.update(logs => [...logs, log]);
      });
  }

  emitEvent(type: string) {
    this.eventBus$.next({ type });
  }

  // === Pattern 9: exhaustMap ===

  private setupExhaustMap() {
    this.saveSubject
      .pipe(
        exhaustMap(() => {
          const logs = this.exhaustMapLogs();
          logs.push('💾 Salvataggio in corso...');
          this.exhaustMapLogs.set([...logs]);

          // Simula operazione di salvataggio
          return timer(2000).pipe(
            tap(() => {
              const newLogs = this.exhaustMapLogs();
              newLogs.push('✅ Salvato!');
              this.exhaustMapLogs.set([...newLogs]);
            })
          );
        }),
        takeUntilDestroyed(this.destroyRef)
      )
      .subscribe();
  }

  demoExhaustMap() {
    const logs = this.exhaustMapLogs();
    logs.push(`🖱️ Click registrato (${new Date().toLocaleTimeString()})`);
    this.exhaustMapLogs.set([...logs]);
    this.saveSubject.next();
  }
}
