import { expect, test } from '@playwright/test';

test.describe('Bookstore smoke E2E', () => {
  test('mostra homepage catalogo con brand e titolo pagina', async ({ page }) => {
    await page.goto('/');

    await expect(page.locator('.navbar-brand')).toHaveText('BookVerse');
    await expect(page.getByRole('heading', { name: 'Catalogo Libri' })).toBeVisible();
  });

  test('naviga alla pagina login dal menu', async ({ page }) => {
    await page.goto('/');

    await page.getByRole('link', { name: 'Login' }).click();

    await expect(page).toHaveURL(/\/login$/);
    await expect(page.getByRole('heading', { name: 'Accedi al tuo account' })).toBeVisible();
  });

  test('segue il flusso catalogo dettaglio e aggiunge al carrello', async ({ page }) => {
    await page.goto('/catalog');

    const firstBookCard = page.locator('article').first();
    await expect(firstBookCard).toBeVisible();

    const selectedTitle = (await firstBookCard.locator('.card-title').innerText()).trim();

    await firstBookCard.getByRole('link', { name: 'Dettaglio' }).click();

    await expect(page).toHaveURL(/\/books\/\d+$/);
    await expect(page.getByRole('button', { name: 'Aggiungi al carrello' })).toBeVisible();

    await page.getByRole('button', { name: 'Aggiungi al carrello' }).click();
    await page.getByRole('link', { name: /Carrello/ }).click();

    await expect(page).toHaveURL(/\/cart$/);
    await expect(page.locator('tbody tr').first()).toBeVisible();
    await expect(page.locator('tbody tr strong').first()).toContainText(selectedTitle);
  });

  test('completa acquisto dopo login con checkout valido', async ({ page }) => {
    await page.goto('/login');

    await page.getByLabel('Email').fill('mario.rossi@mail.com');
    await page.getByLabel('Password').fill('Password123');
    await page.getByRole('button', { name: 'Login' }).click();

    await expect(page).toHaveURL(/\/catalog$/);

    const firstBookCard = page.locator('article').first();
    await expect(firstBookCard).toBeVisible();
    await firstBookCard.getByRole('button', { name: 'Aggiungi' }).click();

    await page.getByRole('link', { name: /Carrello/ }).click();
    await expect(page).toHaveURL(/\/cart$/);

    await page.getByRole('link', { name: 'Procedi al checkout' }).click();
    await expect(page).toHaveURL(/\/checkout$/);

    await page.getByLabel('Indirizzo di spedizione').fill('Via Roma 10, 20100 Milano');
    await page.getByLabel('Intestatario carta').fill('Mario Rossi');
    await page.getByLabel('Numero carta').fill('4242 4242 4242 4242');
    await page.getByLabel('Scadenza').fill('12/99');
    await page.getByLabel('CVV').fill('123');

    await page.getByRole('button', { name: 'Conferma acquisto' }).click();

    await expect(page.locator('.toast-body', { hasText: 'Acquisto completato con successo' })).toBeVisible();
  });
});
