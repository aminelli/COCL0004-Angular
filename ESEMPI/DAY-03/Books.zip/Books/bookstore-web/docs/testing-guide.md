# Guida test - Bookstore workspace

Questa guida descrive come eseguire, mantenere e ampliare i test attualmente previsti nel workspace `app-comm`.

## Copertura attuale

- `bookstore-web`: test unitari (componenti/servizi) in file `*.spec.ts`.
- `bookstore-web`: test end-to-end (E2E) con Playwright in `e2e/*.spec.ts`.
- `bookstore-api`: **nessun test configurato** al momento (solo mock API con `json-server`).

## Stato validato

| Voce                         | Valore                                       |
| ---------------------------- | -------------------------------------------- |
| Ultima esecuzione verificata | 2026-02-19                                   |
| Comando eseguito             | `npm --prefix bookstore-web run test:ci`     |
| Esito                        | 11 suite passate, 35 test passati, 0 falliti |
| Ultima esecuzione E2E        | `npm --prefix bookstore-web run e2e`         |
| Esito E2E                    | 4 test passati, 0 falliti                    |

## Configurazione tool test (dettaglio)

| Ambito                              | Cosa usa il progetto               | Dove è configurato                                               | Nota operativa                                            |
| ----------------------------------- | ---------------------------------- | ---------------------------------------------------------------- | --------------------------------------------------------- |
| Pattern test frontend               | `*.spec.ts`                        | `bookstore-web/tsconfig.spec.json` (`include`)                   | Le suite vengono caricate da `src/**/*.spec.ts`.          |
| Framework test (assertions/globals) | **Vitest**                         | `bookstore-web/tsconfig.spec.json` (`types: ["vitest/globals"]`) | Sono disponibili le API globali di test.                  |
| Runner comando test                 | `ng test`                          | `bookstore-web/package.json` (script `test`)                     | È il comando standard da terminale.                       |
| Builder Angular per unit test       | `@angular/build:unit-test`         | `bookstore-web/angular.json` (`architect.test.builder`)          | È il backend di esecuzione richiamato da `ng test`.       |
| Stile test nei file spec            | Angular `TestBed` + matcher Vitest | Esempi in `src/app/**/*.spec.ts`                                 | Approccio unit/integration leggero su componenti/servizi. |
| Framework E2E                       | **Playwright**                     | `bookstore-web/playwright.config.ts`                             | Esegue scenari browser reali su frontend + mock API.      |
| Backend mock API                    | Nessun runner di test              | `bookstore-api/package.json` (assenza script `test`)             | Al momento non sono previsti test automatici backend.     |

## Matrice comandi test

| Scenario                   | Comando dalla root `app-comm`                                          | Output atteso                                 |
| -------------------------- | ---------------------------------------------------------------------- | --------------------------------------------- |
| Esecuzione locale standard | `npm --prefix bookstore-web test`                                      | Runner test avviato (watch mode).             |
| Esecuzione CI/singola run  | `npm --prefix bookstore-web run test:ci`                               | Processo termina con codice 0 se tutto verde. |
| Esecuzione con coverage    | `npm --prefix bookstore-web run test -- --watch=false --code-coverage` | Report coverage in `bookstore-web/coverage/`. |
| Esecuzione E2E headless    | `npm --prefix bookstore-web run e2e`                                   | Avvia API + frontend e lancia test browser.   |
| Esecuzione E2E UI mode     | `npm --prefix bookstore-web run e2e:ui`                                | Runner Playwright interattivo.                |
| Esecuzione E2E headed      | `npm --prefix bookstore-web run e2e:headed`                            | Browser visibile durante i test.              |

## Strategia di test adottata

| Livello                  | Obiettivo                                                              | Strumento                | Frequenza consigliata         |
| ------------------------ | ---------------------------------------------------------------------- | ------------------------ | ----------------------------- |
| Unit/Integration leggera | Validare logica di componenti, servizi, guard, interceptor, validatori | Angular TestBed + Vitest | A ogni commit locale          |
| End-to-End               | Validare flussi utente completi su browser reale                       | Playwright               | Prima di aprire/aggiornare PR |

Ordine di esecuzione consigliato:

1. `test:ci` (feedback rapido su regressioni logiche)
2. `e2e` (validazione flussi critici utente)
3. coverage (solo quando richiesto da release/audit)

## Prerequisiti

1. Node.js installato (consigliato versione LTS).
2. Dipendenze installate in entrambe le cartelle:

```bash
npm --prefix bookstore-web install
npm --prefix bookstore-api install
```

## Dove sono i test frontend

Suite attualmente presenti in `bookstore-web/src/app`:

- `app.spec.ts`
- `guards/auth/auth.guard.spec.ts`
- `interceptors/http-error/http-error.interceptor.spec.ts`
- `pages/login-page/login-page.component.spec.ts`
- `pages/checkout-page/checkout-page.component.spec.ts`
- `services/auth-api/auth-api.service.spec.ts`
- `services/books-api/books-api.service.spec.ts`
- `services/cart-store/cart.store.spec.ts`
- `services/orders-api/orders-api.service.spec.ts`
- `services/toast/toast.service.spec.ts`
- `shared/validators/form-validators.spec.ts`

## Mappa copertura per area

| Area applicativa                           | File test                                                | Stato   |
| ------------------------------------------ | -------------------------------------------------------- | ------- |
| App shell e routing base                   | `app.spec.ts`                                            | Coperta |
| Guard autenticazione                       | `guards/auth/auth.guard.spec.ts`                         | Coperta |
| Interceptor errori HTTP                    | `interceptors/http-error/http-error.interceptor.spec.ts` | Coperta |
| Login page                                 | `pages/login-page/login-page.component.spec.ts`          | Coperta |
| Checkout page                              | `pages/checkout-page/checkout-page.component.spec.ts`    | Coperta |
| Auth API service                           | `services/auth-api/auth-api.service.spec.ts`             | Coperta |
| Books API service                          | `services/books-api/books-api.service.spec.ts`           | Coperta |
| Cart state store                           | `services/cart-store/cart.store.spec.ts`                 | Coperta |
| Orders API service                         | `services/orders-api/orders-api.service.spec.ts`         | Coperta |
| Toast service                              | `services/toast/toast.service.spec.ts`                   | Coperta |
| Validatori form condivisi                  | `shared/validators/form-validators.spec.ts`              | Coperta |
| Smoke E2E navigazione, carrello e checkout | `e2e/smoke.spec.ts`                                      | Coperta |

## Tracciabilità requisito -> test

| Requisito funzionale/tecnico           | Unit test principali                                                                                                                                | E2E correlati                                      |
| -------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------- |
| Sessione utente (login/logout/restore) | `services/auth-api/auth-api.service.spec.ts`, `pages/login-page/login-page.component.spec.ts`                                                       | `e2e/smoke.spec.ts` (login + checkout)             |
| Protezione route checkout              | `guards/auth/auth.guard.spec.ts`                                                                                                                    | `e2e/smoke.spec.ts`                                |
| Catalogo e dettaglio libro             | `services/books-api/books-api.service.spec.ts`, `app.spec.ts`                                                                                       | `e2e/smoke.spec.ts` (catalogo -> dettaglio)        |
| Gestione carrello                      | `services/cart-store/cart.store.spec.ts`                                                                                                            | `e2e/smoke.spec.ts` (aggiunta e verifica carrello) |
| Creazione ordine e checkout            | `services/orders-api/orders-api.service.spec.ts`, `pages/checkout-page/checkout-page.component.spec.ts`                                             | `e2e/smoke.spec.ts` (checkout completo)            |
| Gestione errori HTTP globali           | `interceptors/http-error/http-error.interceptor.spec.ts`                                                                                            | copertura indiretta via flussi E2E                 |
| Validazione input form                 | `shared/validators/form-validators.spec.ts`, `pages/login-page/login-page.component.spec.ts`, `pages/checkout-page/checkout-page.component.spec.ts` | copertura indiretta in scenari E2E                 |

Uso suggerito in PR/review:

- se tocchi un requisito, verifica che almeno una riga della tabella abbia test aggiornati;
- se aggiungi un nuovo requisito, estendi la tabella con mapping unit/E2E;
- se cambi comportamento cross-cutting (es. error handling), includi sia test unit che scenario E2E pertinente.

## Copertura HTTP API (dettaglio)

| Area HTTP                                                 | Casi coperti                                                                                                                                                  |
| --------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Auth API (`auth-api.service.spec.ts`)                     | login successo, login credenziali invalide, login errore backend 500, register successo, register email già esistente (blocco POST), restore sessione, logout |
| Books API (`books-api.service.spec.ts`)                   | GET books, GET book by id, GET categories, propagazione errore backend                                                                                        |
| Orders API (`orders-api.service.spec.ts`)                 | POST order successo con context `SKIP_GLOBAL_ERROR_TOAST`, propagazione errore backend 503                                                                    |
| HTTP Error Interceptor (`http-error.interceptor.spec.ts`) | mapping messaggi 404, skip toast via context, mapping errore rete status 0                                                                                    |

Note operative su test HTTP:

- I servizi usano `HttpTestingController` + `provideHttpClientTesting`.
- Ogni suite valida endpoint/metodo e, dove rilevante, `context` HTTP.
- I test negativi verificano propagazione errore e side effects (es. stato auth invariato).

## Esecuzione test frontend (comando standard)

Dalla root del workspace (`app-comm`):

```bash
npm --prefix bookstore-web test
```

Questo comando esegue lo script `test` del frontend (`ng test`).

## Esecuzione in modalità CI (singola run)

Per evitare modalità watch continua:

```bash
npm --prefix bookstore-web run test:ci
```

Opzionale con coverage:

```bash
npm --prefix bookstore-web run test -- --watch=false --code-coverage
```

Esecuzione singolo file spec (utile in debug locale):

```bash
npm --prefix bookstore-web run test -- --watch=false --include src/app/services/auth-api/auth-api.service.spec.ts
```

## Eseguire da cartella frontend

In alternativa, entra in `bookstore-web` e lancia:

```bash
npm install
npm test
```

Versione CI:

```bash
npm run test:ci
```

E2E Playwright:

```bash
npm run e2e
```

Esecuzione singolo file E2E:

```bash
npm run e2e -- e2e/smoke.spec.ts
```

Esecuzione scenario E2E filtrato per titolo:

```bash
npm run e2e -- --grep "checkout"
```

Modalità interattiva:

```bash
npm run e2e:ui
```

## Verifica rapida dei risultati

- Esito positivo: processo termina senza errori.
- Esito negativo: il terminale mostra la suite `*.spec.ts` fallita e relativo stack.
- Con coverage: report generato in `bookstore-web/coverage/`.
- E2E Playwright: report HTML in `bookstore-web/playwright-report/`.

## Configurazione Playwright (E2E)

- File config: `bookstore-web/playwright.config.ts`.
- Directory test: `bookstore-web/e2e/`.
- Browser configurato: Chromium.
- Startup automatico per E2E:
	- `npm --prefix ../bookstore-api start` (API mock su `:3001`)
	- `npm run start -- --port 4200` (frontend Angular su `:4200`)

Dettagli operativi:

- `reuseExistingServer: !process.env.CI` evita riavvii locali se i servizi sono già attivi.
- `trace: on-first-retry` abilita trace Playwright solo al primo retry (diagnostica mirata).
- Output diagnostico:
  - risultati raw: `bookstore-web/test-results/`
  - report HTML: `bookstore-web/playwright-report/`

Aprire report Playwright locale:

```bash
npx --prefix bookstore-web playwright show-report
```

## Come aggiungere nuovi test TestBed

1. Crea il file `*.spec.ts` vicino al file sorgente (stessa cartella funzionale).
2. Inizializza il test con `TestBed.configureTestingModule(...)`.
3. Mocka dipendenze esterne (`HttpClient`, router, servizi) con provider `useValue` o `HttpTestingController`.
4. Verifica almeno:
	 - scenario felice,
	 - scenario errore,
	 - effetti collaterali (stato, toast, navigation, localStorage).
5. Esegui `npm --prefix bookstore-web run test:ci` prima della PR.

Nota su deprecazioni router test:

- Non usare `RouterTestingModule` nei nuovi spec.
- Usare `provideRouter([])`.
- Solo se necessario per mock location, usare esplicitamente `provideLocationMocks`.

Snippet base:

```ts
import { TestBed } from '@angular/core/testing';

describe('MyFeature', () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: []
		});
	});

	it('esegue comportamento atteso', () => {
		expect(true).toBe(true);
	});
});
```

## Policy qualità test (PR)

Runbook CI dettagliato:

- [docs/testing-ci-runbook.md](docs/testing-ci-runbook.md)

### Gate minimi obbligatori

| Gate         | Regola                                                                                                              |
| ------------ | ------------------------------------------------------------------------------------------------------------------- |
| Build test   | `npm --prefix bookstore-web run test:ci` deve terminare con exit code `0`.                                          |
| Build E2E    | `npm --prefix bookstore-web run e2e` deve terminare con exit code `0`.                                              |
| Regressioni  | Nessun test esistente deve essere disabilitato o rimosso senza motivazione tecnica in PR.                           |
| Nuovo codice | Ogni nuova logica (servizio/guard/interceptor/validator/componente con comportamento) deve includere almeno 1 test. |
| Fix bug      | Ogni bugfix deve includere almeno 1 test che riproduce il bug e valida la correzione.                               |

### Pipeline CI consigliata (ordine stage)

1. Install dipendenze (`npm ci` frontend + api)
2. Unit test (`npm --prefix bookstore-web run test:ci`)
3. E2E (`npm --prefix bookstore-web run e2e`)
4. Archiviazione artefatti (`coverage/`, `playwright-report/`, `test-results/`)

Esempio minimo (GitHub Actions):

```yaml
- name: Install frontend deps
	run: npm --prefix bookstore-web ci

- name: Install api deps
	run: npm --prefix bookstore-api ci

- name: Install Playwright browser
	run: npx --prefix bookstore-web playwright install chromium

- name: Unit tests
	run: npm --prefix bookstore-web run test:ci

- name: E2E tests
	run: npm --prefix bookstore-web run e2e
```

### Copertura minima consigliata per nuova feature

- 1 test scenario felice.
- 1 test scenario errore/edge case.
- 1 test effetti collaterali (es. stato, toast, redirect, localStorage, chiamata HTTP).

### Checklist review test (da usare in PR)

- [ ] I test sono eseguibili in locale con `test:ci`.
- [ ] Gli scenari E2E coinvolti dalla modifica passano con `e2e`.
- [ ] I nomi dei test descrivono chiaramente comportamento e risultato atteso.
- [ ] I mock verificano interazioni rilevanti (payload HTTP, context token, navigation, side effects).
- [ ] I test non dipendono dall'ordine di esecuzione e non condividono stato sporco.
- [ ] È stato evitato l'uso di timeout non necessari o attese flakey.

### Regole pratiche per stabilità

- Preferire `HttpTestingController` per servizi HTTP.
- Preferire `TestBed.runInInjectionContext(...)` per testare `CanActivateFn` e interceptor function-based.
- Usare fixture e dati minimi necessari per mantenere i test veloci e leggibili.
- Pulire sempre side effects (`localStorage`, mock call history) in `beforeEach`/`afterEach`.

## Note su `bookstore-api`

Nel package `bookstore-api` non è presente uno script `test`, quindi **non ci sono test eseguibili** in questa parte del progetto.

## Troubleshooting rapido

- Errori di dipendenze mancanti: riesegui `npm --prefix bookstore-web install`.
- Processo che non termina: verifica di aver usato `--watch=false`.
- Porta frontend occupata (solo se avvii app): i test non richiedono `ng serve`, quindi puoi fermare il server prima di lanciare i test.

## Troubleshooting avanzato

| Problema                                  | Causa probabile                                | Azione consigliata                                                                      |
| ----------------------------------------- | ---------------------------------------------- | --------------------------------------------------------------------------------------- |
| E2E falliscono con timeout su `page.goto` | frontend/API non pronti o porte occupate       | chiudi processi duplicati su `4200/3001`, rilancia `npm --prefix bookstore-web run e2e` |
| Browser Playwright non trovato in CI      | browser binaries non installati                | esegui `npx --prefix bookstore-web playwright install chromium`                         |
| Errori intermittenti su selettori toast   | più toast visibili contemporaneamente          | usa locator con `hasText` specifico del messaggio atteso                                |
| Unit test dipendono da stato precedente   | side effects non puliti (`localStorage`, mock) | aggiungi cleanup in `beforeEach`/`afterEach`                                            |
| Warning su deprecazione routing test      | uso legacy `RouterTestingModule`               | sostituisci con `provideRouter([])`                                                     |