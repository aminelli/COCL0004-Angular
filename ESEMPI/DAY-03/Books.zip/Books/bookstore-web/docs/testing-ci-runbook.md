# Runbook CI Test - Bookstore Web

Questa guida descrive un flusso CI affidabile per eseguire test unitari ed end-to-end su `bookstore-web`.

## Obiettivo

- Eseguire in pipeline i test unitari (`test:ci`) e Playwright E2E (`e2e`).
- Pubblicare artefatti utili al debug (`coverage`, `playwright-report`, `test-results`).
- Fallire velocemente su regressioni.

## Baseline corrente validata

| Suite            | Stato                                |
| ---------------- | ------------------------------------ |
| Unit (`test:ci`) | 11 suite, 35 test passati, 0 falliti |
| E2E (`e2e`)      | 4 test passati, 0 falliti            |

## Prerequisiti runner

- Node.js LTS disponibile nel runner CI.
- Accesso alla rete per install dipendenze npm e browser Playwright.
- Workspace completo con:
  - `bookstore-web`
  - `bookstore-api`

## Sequenza consigliata stage CI

1. Checkout repository.
2. Install dipendenze frontend/API con `npm ci`.
3. Install browser Playwright (`chromium`).
4. Esegui unit test (`test:ci`).
5. Esegui E2E (`e2e`).
6. Pubblica artefatti test/report.

## Comandi riferimento (da root `app-comm`)

```bash
npm --prefix bookstore-web ci
npm --prefix bookstore-api ci
npx --prefix bookstore-web playwright install chromium
npm --prefix bookstore-web run test:ci
npm --prefix bookstore-web run e2e
```

## Artefatti da conservare

| Artefatto                | Path                               | Quando utile                      |
| ------------------------ | ---------------------------------- | --------------------------------- |
| Coverage unit test       | `bookstore-web/coverage/`          | Audit copertura e trend qualità   |
| Report Playwright        | `bookstore-web/playwright-report/` | Analisi failure E2E               |
| Risultati Playwright raw | `bookstore-web/test-results/`      | Debug avanzato (trace/screenshot) |

## Esempio GitHub Actions (minimo)

```yaml
name: bookstore-web-tests

on:
  pull_request:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm

      - name: Install frontend deps
        run: npm --prefix bookstore-web ci

      - name: Install api deps
        run: npm --prefix bookstore-api ci

      - name: Install Playwright browser
        run: npx --prefix bookstore-web playwright install chromium

      - name: Run unit tests
        run: npm --prefix bookstore-web run test:ci

      - name: Run e2e tests
        run: npm --prefix bookstore-web run e2e

      - name: Upload test artifacts
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: test-artifacts
          path: |
            bookstore-web/coverage/
            bookstore-web/playwright-report/
            bookstore-web/test-results/
```

## Policy di esito pipeline

- La pipeline è **verde** solo se passano sia unit test che E2E.
- In caso di failure E2E:
  - aprire `playwright-report`
  - analizzare `test-results` per trace/screenshot
- Non accettare merge con stage test fallito.

## Quality gate per requisito

Usa questa matrice durante la review PR per verificare che ogni requisito toccato abbia almeno un test aggiornato.

| Requisito                              | Unit test di riferimento                                                                                                | E2E di riferimento                 |
| -------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| Sessione utente (login/logout/restore) | `src/app/services/auth-api/auth-api.service.spec.ts`, `src/app/pages/login-page/login-page.component.spec.ts`           | `e2e/smoke.spec.ts`                |
| Routing protetto checkout              | `src/app/guards/auth/auth.guard.spec.ts`                                                                                | `e2e/smoke.spec.ts`                |
| Catalogo e dettaglio libro             | `src/app/services/books-api/books-api.service.spec.ts`                                                                  | `e2e/smoke.spec.ts`                |
| Carrello                               | `src/app/services/cart-store/cart.store.spec.ts`                                                                        | `e2e/smoke.spec.ts`                |
| Checkout e creazione ordine            | `src/app/services/orders-api/orders-api.service.spec.ts`, `src/app/pages/checkout-page/checkout-page.component.spec.ts` | `e2e/smoke.spec.ts`                |
| Gestione errori HTTP                   | `src/app/interceptors/http-error/http-error.interceptor.spec.ts`                                                        | Copertura indiretta nei flussi E2E |

Checklist gate requisito (da applicare in PR):

- [ ] Ogni requisito modificato ha almeno un test aggiornato o aggiunto.
- [ ] Per modifiche cross-cutting (auth/routing/http), sono coperti sia livello unit sia E2E.
- [ ] Se un requisito nuovo non è in tabella, la matrice è stata estesa nella PR.
- [ ] Nessun test esistente è stato rimosso senza motivazione tecnica esplicita.

## Troubleshooting CI

| Sintomo                     | Causa probabile              | Azione                                                                      |
| --------------------------- | ---------------------------- | --------------------------------------------------------------------------- |
| Timeout su E2E              | server app/API non pronti    | verificare startup automatico in `playwright.config.ts` e timeout webServer |
| Browser Playwright mancante | step install browser assente | aggiungere `playwright install chromium`                                    |
| Test flaky su UI            | selettori troppo generici    | usare locator più specifici (es. `hasText`)                                 |
| Errori npm lock             | lockfile non allineato       | aggiornare lockfile localmente e rieseguire `npm ci`                        |

## Checklist prima del merge

- [ ] `npm --prefix bookstore-web run test:ci` verde
- [ ] `npm --prefix bookstore-web run e2e` verde
- [ ] Artefatti test disponibili in CI
- [ ] Nessuna suite disabilitata senza motivazione
