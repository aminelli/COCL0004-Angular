# Checklist WCAG 2.2 AA - Bookstore Web

Questa checklist serve come verifica pratica e ripetibile della conformità WCAG 2.2 AA dell'app.

## Come usarla

- Stato possibili: PASS, PARZIALE, FAIL, DA VERIFICARE
- Aggiorna lo stato dopo ogni modifica UI/form/navigation
- Esegui sia test automatici (Lighthouse/axe) sia test manuali da tastiera e screen reader

## Stato sintetico corrente

- Esito generale: PARZIALE (buona base accessibilità, audit formale non completato)
- Ultimo aggiornamento: 2026-02-18

## A. Perceivable

- [PASS] 1.1.1 Contenuti non testuali (alt text immagini rilevanti)
  - Evidenza: immagini libro con alt descrittivo in pages catalogo/dettaglio.
- [PASS] 1.3.1 Info e relazioni (struttura semantica, label/input)
  - Evidenza: label associate nei form login/register/checkout.
- [DA VERIFICARE] 1.4.3 Contrasto minimo (4.5:1)
  - Azione: verifica con strumenti contrast checker su varianti toast/info/warning e badge.
- [PASS] 1.4.10 Reflow (fino a 320 CSS px)
  - Evidenza: layout responsive con griglie Bootstrap e container fluidi.

## B. Operable

- [PASS] 2.1.1 Tastiera
  - Evidenza: azioni primarie disponibili tramite link/button nativi.
- [PASS] 2.4.1 Bypass blocks
  - Evidenza: skip-link all'inizio pagina in [src/app/app.html](../src/app/app.html).
- [PASS] 2.4.3 Ordine focus
  - Evidenza: ordine tab coerente nelle pagine principali; focus trap in checkout.
- [PASS] 2.4.7 Focus visibile
  - Evidenza: focus ring browser + stile skip-link in [src/app/app.scss](../src/app/app.scss).
- [PARZIALE] 2.4.11 Focus Not Obscured (WCAG 2.2)
  - Azione: verifica con zoom 200% e header sticky su tutte le route.
- [DA VERIFICARE] 2.5.8 Target Size Minimum (WCAG 2.2)
  - Azione: misurare target interattivi minimi (24x24 CSS px) in mobile.

## C. Understandable

- [PASS] 3.1.1 Lingua della pagina
  - Evidenza: `lang="it"` in [src/index.html](../src/index.html).
- [PASS] 3.2.2 On Input
  - Evidenza: nessun cambio contesto inatteso al solo input campo.
- [PASS] 3.3.1 Error Identification
  - Evidenza: errori validazione mostrati via toast e stato campo invalid.
- [PARZIALE] 3.3.3 Error Suggestion
  - Azione: estendere suggerimenti inline per tutti i campi oltre ai toast globali.

## D. Robust

- [PASS] 4.1.2 Name, Role, Value
  - Evidenza: uso di controlli HTML nativi e attributi aria pertinenti.
- [PASS] 4.1.3 Status Messages
  - Evidenza: LiveAnnouncer + area toast `aria-live` in [src/app/components/toast-host/toast-host.component.html](../src/app/components/toast-host/toast-host.component.html) e [src/app/services/toast/toast.service.ts](../src/app/services/toast/toast.service.ts).

## Checklist per pagina

### Globale (layout/app shell)

- [PASS] Skip-link raggiungibile da tastiera e visibile al focus.
- [PASS] Landmark principale (`main`) presente.
- [PASS] Navigazione con etichette comprensibili.

### Login

- [PASS] Label associate ai campi.
- [PASS] `aria-invalid` su campi invalidi.
- [PASS] Submit disabilitato durante invio.
- [PARZIALE] Messaggi errore inline persistenti per singolo campo (oggi principalmente via toast).

### Registrazione

- [PASS] Validazione robusta password + conferma.
- [PASS] `aria-describedby` per hint password.
- [PARZIALE] Aggiungere blocco error summary ancorato al form.

### Checkout

- [PASS] Focus trap nell'area pagamento.
- [PASS] Validazione carta/scadenza/cvv con feedback utente.
- [DA VERIFICARE] Test completo con screen reader su riepilogo ordine dinamico.

### Catalogo/Dettaglio/Carrello

- [PASS] Pulsanti azione con testo esplicito.
- [PASS] Controlli quantità con aria-label.
- [DA VERIFICARE] Contrasto visivo di badge/secondary text in tutte le varianti tema/display.

## Procedura di test consigliata

1. Tastiera-only: Tab/Shift+Tab/Enter/Space su tutte le route.
2. Zoom: 200% e 400% su viewport mobile desktop.
3. Screen reader: NVDA (Windows) o VoiceOver (macOS), verifica annunci toast e titoli sezioni.
4. Automatico:
   - Lighthouse Accessibility (target >= 95)
   - axe DevTools (zero violazioni critiche)
5. Contrasto: controllo su palette effettiva di pulsanti, badge, toast, testo secondario.

## Criteri di uscita (Definition of Done A11y)

- Nessun FAIL aperto
- Tutti i PARZIALE chiusi o accettati con deroga documentata
- Report Lighthouse e axe allegati alla PR/release
- Test manuali tastiera + screen reader completati con evidenze
