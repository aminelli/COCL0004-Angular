export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:3001'
};