import { FormControl, FormGroup } from '@angular/forms';
import {
  STRONG_PASSWORD_PATTERN,
  cardNumberValidator,
  expiryValidator,
  passwordsMatchValidator,
  trimValidator
} from './form-validators';

describe('form validators', () => {
  it('trimValidator segnala spazi iniziali/finali', () => {
    const validControl = new FormControl('Mario Rossi', { nonNullable: true });
    const invalidControl = new FormControl(' Mario Rossi ', { nonNullable: true });

    expect(trimValidator(validControl)).toBeNull();
    expect(trimValidator(invalidControl)).toEqual({ trim: true });
  });

  it('cardNumberValidator accetta 16 cifre anche con spazi', () => {
    const control = new FormControl('4242 4242 4242 4242', { nonNullable: true });

    expect(cardNumberValidator(control)).toBeNull();
  });

  it('cardNumberValidator rifiuta formati non validi', () => {
    const control = new FormControl('1234 5678', { nonNullable: true });

    expect(cardNumberValidator(control)).toEqual({ cardNumberInvalid: true });
  });

  it('expiryValidator rifiuta formato non MM/YY', () => {
    const control = new FormControl('2028-12', { nonNullable: true });

    expect(expiryValidator(control)).toEqual({ expiryFormat: true });
  });

  it('expiryValidator rifiuta date scadute', () => {
    const control = new FormControl('01/20', { nonNullable: true });

    expect(expiryValidator(control)).toEqual({ expiryPast: true });
  });

  it('expiryValidator accetta date future', () => {
    const nextYear = (new Date().getFullYear() + 1).toString().slice(-2);
    const control = new FormControl(`12/${nextYear}`, { nonNullable: true });

    expect(expiryValidator(control)).toBeNull();
  });

  it('passwordsMatchValidator segnala mismatch', () => {
    const form = new FormGroup(
      {
        password: new FormControl('Password1!', { nonNullable: true }),
        confirmPassword: new FormControl('Password2!', { nonNullable: true })
      },
      {
        validators: passwordsMatchValidator()
      }
    );

    expect(form.errors).toEqual({ passwordMismatch: true });
  });

  it('STRONG_PASSWORD_PATTERN valida password robuste', () => {
    expect(STRONG_PASSWORD_PATTERN.test('Password1!')).toBe(true);
    expect(STRONG_PASSWORD_PATTERN.test('weakpass')).toBe(false);
  });
});
