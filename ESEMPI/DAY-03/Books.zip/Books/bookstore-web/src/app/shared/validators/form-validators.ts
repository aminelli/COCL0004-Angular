import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const STRONG_PASSWORD_PATTERN =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,64}$/;

export function trimValidator(control: AbstractControl<string>): ValidationErrors | null {
  const value = control.value;
  if (!value) {
    return null;
  }

  return value.trim() === value ? null : { trim: true };
}

export function cardNumberValidator(control: AbstractControl<string>): ValidationErrors | null {
  const value = (control.value ?? '').replace(/\s+/g, '');

  if (!value) {
    return null;
  }

  return /^\d{16}$/.test(value) ? null : { cardNumberInvalid: true };
}

export function expiryValidator(control: AbstractControl<string>): ValidationErrors | null {
  const value = control.value ?? '';
  if (!value) {
    return null;
  }

  const match = value.match(/^(0[1-9]|1[0-2])\/(\d{2})$/);
  if (!match) {
    return { expiryFormat: true };
  }

  const month = Number(match[1]);
  const year = Number(`20${match[2]}`);
  const expiryDate = new Date(year, month, 0, 23, 59, 59, 999);
  const now = new Date();

  return expiryDate >= now ? null : { expiryPast: true };
}

export function passwordsMatchValidator(
  passwordControlName = 'password',
  confirmPasswordControlName = 'confirmPassword'
): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const password = control.get(passwordControlName)?.value as string | undefined;
    const confirmPassword = control.get(confirmPasswordControlName)?.value as string | undefined;

    if (!password || !confirmPassword) {
      return null;
    }

    return password === confirmPassword ? null : { passwordMismatch: true };
  };
}