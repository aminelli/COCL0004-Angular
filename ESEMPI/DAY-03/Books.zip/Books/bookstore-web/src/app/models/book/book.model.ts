export interface Book {
  id: number;
  categoryId: number;
  title: string;
  author: string;
  description: string;
  imageUrl: string;
  price: number;
  rating: number;
  stock: number;
}