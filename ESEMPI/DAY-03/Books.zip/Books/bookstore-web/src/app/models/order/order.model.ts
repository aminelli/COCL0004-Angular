export interface OrderItem {
  bookId: number;
  title: string;
  quantity: number;
  unitPrice: number;
}

export interface Order {
  id?: number;
  userId: number;
  createdAt: string;
  total: number;
  shippingAddress: string;
  paymentLast4: string;
  items: OrderItem[];
}