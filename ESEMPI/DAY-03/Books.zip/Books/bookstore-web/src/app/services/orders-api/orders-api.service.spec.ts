import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { OrdersApiService } from './orders-api.service';
import { SKIP_GLOBAL_ERROR_TOAST } from '../../interceptors/http-error';

describe('OrdersApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
  });

  afterEach(() => {
    TestBed.inject(HttpTestingController).verify();
  });

  it('createOrder invia POST a /orders con SKIP_GLOBAL_ERROR_TOAST', () => {
    const service = TestBed.inject(OrdersApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const nextSpy = vi.fn();

    const orderPayload = {
      userId: 1,
      createdAt: '2026-02-19T10:00:00.000Z',
      total: 20,
      shippingAddress: 'Via Roma 1, Milano',
      paymentLast4: '4242',
      items: [{ bookId: 2, title: 'Angular Basics', quantity: 1, unitPrice: 20 }]
    };

    service.createOrder(orderPayload).subscribe(nextSpy);

    const request = httpTesting.expectOne('http://localhost:3001/orders');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(orderPayload);
    expect(request.request.context.get(SKIP_GLOBAL_ERROR_TOAST)).toBe(true);

    request.flush({ id: 55, ...orderPayload });

    expect(nextSpy).toHaveBeenCalledWith({ id: 55, ...orderPayload });
  });

  it('createOrder propaga errore HTTP backend', () => {
    const service = TestBed.inject(OrdersApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const errorSpy = vi.fn();

    const orderPayload = {
      userId: 1,
      createdAt: '2026-02-19T10:00:00.000Z',
      total: 20,
      shippingAddress: 'Via Roma 1, Milano',
      paymentLast4: '4242',
      items: [{ bookId: 2, title: 'Angular Basics', quantity: 1, unitPrice: 20 }]
    };

    service.createOrder(orderPayload).subscribe({ error: errorSpy });

    const request = httpTesting.expectOne('http://localhost:3001/orders');
    expect(request.request.context.get(SKIP_GLOBAL_ERROR_TOAST)).toBe(true);
    request.flush({ message: 'Service unavailable' }, { status: 503, statusText: 'Service Unavailable' });

    expect(errorSpy).toHaveBeenCalledOnce();
  });
});
