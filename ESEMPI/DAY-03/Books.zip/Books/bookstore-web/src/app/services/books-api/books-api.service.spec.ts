import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { BooksApiService } from './books-api.service';

describe('BooksApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
  });

  afterEach(() => {
    TestBed.inject(HttpTestingController).verify();
  });

  it('getBooks richiama endpoint /books', () => {
    const service = TestBed.inject(BooksApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const nextSpy = vi.fn();

    service.getBooks().subscribe(nextSpy);

    const request = httpTesting.expectOne('http://localhost:3001/books');
    expect(request.request.method).toBe('GET');
    request.flush([{ id: 1, title: 'Book A' }]);

    expect(nextSpy).toHaveBeenCalledWith([{ id: 1, title: 'Book A' }]);
  });

  it('getBookById richiama endpoint /books/:id', () => {
    const service = TestBed.inject(BooksApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const nextSpy = vi.fn();

    service.getBookById(9).subscribe(nextSpy);

    const request = httpTesting.expectOne('http://localhost:3001/books/9');
    expect(request.request.method).toBe('GET');
    request.flush({ id: 9, title: 'Book B' });

    expect(nextSpy).toHaveBeenCalledWith({ id: 9, title: 'Book B' });
  });

  it('getCategories richiama endpoint /categories', () => {
    const service = TestBed.inject(BooksApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const nextSpy = vi.fn();

    service.getCategories().subscribe(nextSpy);

    const request = httpTesting.expectOne('http://localhost:3001/categories');
    expect(request.request.method).toBe('GET');
    request.flush([{ id: 1, name: 'Tech' }]);

    expect(nextSpy).toHaveBeenCalledWith([{ id: 1, name: 'Tech' }]);
  });

  it('getBooks propaga errore HTTP in caso di failure backend', () => {
    const service = TestBed.inject(BooksApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const errorSpy = vi.fn();

    service.getBooks().subscribe({ error: errorSpy });

    const request = httpTesting.expectOne('http://localhost:3001/books');
    request.flush({ message: 'Server error' }, { status: 500, statusText: 'Server Error' });

    expect(errorSpy).toHaveBeenCalledOnce();
  });
});
