import { HttpClient, HttpContext, HttpParams } from '@angular/common/http';
import { computed, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Observable, map, switchMap, tap, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuthResponse, LoginPayload, RegisterPayload, User } from '../../models/user';
import { SKIP_GLOBAL_ERROR_TOAST } from '../../interceptors/http-error';

@Injectable({
  providedIn: 'root'
})
export class AuthApiService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly apiBaseUrl = environment.apiBaseUrl;

  private readonly currentUserSignal = signal<User | null>(null);
  private readonly tokenSignal = signal<string | null>(null);

  readonly currentUser = this.currentUserSignal.asReadonly();
  readonly token = this.tokenSignal.asReadonly();
  readonly isAuthenticated = computed(() => !!this.currentUserSignal() && !!this.tokenSignal());

  constructor() {
    this.restoreSession();
  }

  login(payload: LoginPayload): Observable<AuthResponse> {
    // Flusso reattivo login su json-server: query utenti e trasformazione in sessione applicativa.
    const params = new HttpParams().set('email', payload.email.toLowerCase().trim());

    return this.http
      .get<(User & { password: string })[]>(`${this.apiBaseUrl}/users`, {
        params,
        context: new HttpContext().set(SKIP_GLOBAL_ERROR_TOAST, true)
      })
      .pipe(
        map((users) => users.find((user) => user.password === payload.password) ?? null),
        switchMap((user) => {
          if (!user) {
            return throwError(() => ({ error: { message: 'Credenziali non valide.' } }));
          }

          const response: AuthResponse = {
            token: this.createToken(user.id),
            user: {
              id: user.id,
              firstName: user.firstName,
              lastName: user.lastName,
              email: user.email
            }
          };

          return [response];
        }),
        tap((response) => this.persistSession(response))
      );
  }

  register(payload: RegisterPayload): Observable<AuthResponse> {
    const normalizedEmail = payload.email.toLowerCase().trim();
    const params = new HttpParams().set('email', normalizedEmail);

    return this.http
      .get<Array<User & { password: string }>>(`${this.apiBaseUrl}/users`, {
        params,
        context: new HttpContext().set(SKIP_GLOBAL_ERROR_TOAST, true)
      })
      .pipe(
        switchMap((users) => {
          if (users.length > 0) {
            return throwError(() => ({ error: { message: 'Email già registrata.' } }));
          }

          return this.http.post<User & { password: string }>(
            `${this.apiBaseUrl}/users`,
            {
              firstName: payload.firstName,
              lastName: payload.lastName,
              email: normalizedEmail,
              password: payload.password
            },
            {
              context: new HttpContext().set(SKIP_GLOBAL_ERROR_TOAST, true)
            }
          );
        }),
        map((user) => ({
          token: this.createToken(user.id),
          user: {
            id: user.id,
            firstName: user.firstName,
            lastName: user.lastName,
            email: user.email
          }
        })),
        tap((response) => this.persistSession(response))
      );
  }

  logout(): void {
    this.currentUserSignal.set(null);
    this.tokenSignal.set(null);

    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('bookstore_user');
      localStorage.removeItem('bookstore_token');
    }
  }

  private persistSession(response: AuthResponse): void {
    this.currentUserSignal.set(response.user);
    this.tokenSignal.set(response.token);

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('bookstore_user', JSON.stringify(response.user));
      localStorage.setItem('bookstore_token', response.token);
    }
  }

  private restoreSession(): void {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    const storedUser = localStorage.getItem('bookstore_user');
    const storedToken = localStorage.getItem('bookstore_token');

    if (storedUser && storedToken) {
      this.currentUserSignal.set(JSON.parse(storedUser));
      this.tokenSignal.set(storedToken);
    }
  }

  private createToken(userId: number): string {
    return `mock-token-${userId}-${Date.now()}`;
  }
}