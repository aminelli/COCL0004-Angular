import { LiveAnnouncer } from '@angular/cdk/a11y';
import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ToastService } from './toast.service';

describe('ToastService', () => {
  const liveAnnouncerMock = {
    announce: vi.fn().mockResolvedValue(undefined)
  };

  beforeEach(() => {
    vi.clearAllMocks();

    TestBed.configureTestingModule({
      providers: [
        ToastService,
        { provide: LiveAnnouncer, useValue: liveAnnouncerMock },
        { provide: PLATFORM_ID, useValue: 'server' }
      ]
    });
  });

  it('mostra al massimo 3 toast visibili', () => {
    const service = TestBed.inject(ToastService);

    service.info('Info 1');
    service.success('Success 2');
    service.warning('Warning 3');
    service.error('Error 4');

    expect(service.toasts().length).toBe(3);
    expect(service.toasts().map((toast) => toast.text)).toEqual(['Info 1', 'Success 2', 'Warning 3']);
  });

  it('promuove dalla coda rispettando priorità quando si libera uno slot', () => {
    const service = TestBed.inject(ToastService);

    service.info('Info A');
    service.success('Success B');
    service.info('Info C');
    service.warning('Warning queued');
    service.error('Error queued');

    const firstVisibleId = service.toasts()[0]?.id;
    expect(firstVisibleId).toBeDefined();

    service.remove(firstVisibleId as number);

    expect(service.toasts().length).toBe(3);
    expect(service.toasts().some((toast) => toast.text === 'Error queued')).toBe(true);
  });

  it('annuncia con politeness assertive su toast error', () => {
    const service = TestBed.inject(ToastService);

    service.error('Errore grave');

    expect(liveAnnouncerMock.announce).toHaveBeenCalledWith('Errore grave', 'assertive');
  });
});
