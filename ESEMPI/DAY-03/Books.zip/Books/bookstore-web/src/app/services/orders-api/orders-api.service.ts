import { HttpClient, HttpContext } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Order } from '../../models/order';
import { SKIP_GLOBAL_ERROR_TOAST } from '../../interceptors/http-error';

@Injectable({
  providedIn: 'root'
})
export class OrdersApiService {
  private readonly http = inject(HttpClient);
  private readonly apiBaseUrl = environment.apiBaseUrl;

  createOrder(order: Order): Observable<Order> {
    return this.http.post<Order>(`${this.apiBaseUrl}/orders`, order, {
      context: new HttpContext().set(SKIP_GLOBAL_ERROR_TOAST, true)
    });
  }
}