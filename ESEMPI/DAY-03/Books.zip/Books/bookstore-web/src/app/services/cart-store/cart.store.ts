import { computed, effect, inject, Injectable, PLATFORM_ID, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Book } from '../../models/book';
import { CartItem } from '../../models/cart-item';

@Injectable({
  providedIn: 'root'
})
export class CartStore {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly itemsSignal = signal<CartItem[]>(this.readInitialState());

  readonly items = this.itemsSignal.asReadonly();
  readonly totalItems = computed(() =>
    this.itemsSignal().reduce((accumulator, item) => accumulator + item.quantity, 0)
  );
  readonly totalAmount = computed(() =>
    this.itemsSignal().reduce((accumulator, item) => accumulator + item.book.price * item.quantity, 0)
  );

  constructor() {
    // Persistenza automatica lato browser: ogni variazione del signal aggiorna localStorage.
    effect(() => {
      if (!isPlatformBrowser(this.platformId)) {
        return;
      }

      localStorage.setItem('bookstore_cart', JSON.stringify(this.itemsSignal()));
    });
  }

  add(book: Book): void {
    this.itemsSignal.update((items) => {
      const existingItem = items.find((item) => item.book.id === book.id);

      if (existingItem) {
        return items.map((item) =>
          item.book.id === book.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }

      return [...items, { book, quantity: 1 }];
    });
  }

  updateQuantity(bookId: number, quantity: number): void {
    if (quantity <= 0) {
      this.remove(bookId);
      return;
    }

    this.itemsSignal.update((items) =>
      items.map((item) => (item.book.id === bookId ? { ...item, quantity } : item))
    );
  }

  remove(bookId: number): void {
    this.itemsSignal.update((items) => items.filter((item) => item.book.id !== bookId));
  }

  clear(): void {
    this.itemsSignal.set([]);
  }

  private readInitialState(): CartItem[] {
    if (!isPlatformBrowser(this.platformId)) {
      return [];
    }

    const rawCart = localStorage.getItem('bookstore_cart');
    return rawCart ? (JSON.parse(rawCart) as CartItem[]) : [];
  }
}