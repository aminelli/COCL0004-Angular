import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { AuthApiService } from './auth-api.service';
import { SKIP_GLOBAL_ERROR_TOAST } from '../../interceptors/http-error';

describe('AuthApiService', () => {
  beforeEach(() => {
    localStorage.clear();

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: PLATFORM_ID, useValue: 'browser' }
      ]
    });
  });

  afterEach(() => {
    const httpTesting = TestBed.inject(HttpTestingController);
    httpTesting.verify();
    localStorage.clear();
  });

  it('login normalizza email e persiste sessione su successo', () => {
    const service = TestBed.inject(AuthApiService);
    const httpTesting = TestBed.inject(HttpTestingController);

    const nextSpy = vi.fn();
    service.login({ email: ' MARIO@EXAMPLE.COM ', password: 'Password1!' }).subscribe(nextSpy);

    const usersRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    expect(usersRequest.request.params.get('email')).toBe('mario@example.com');
    expect(usersRequest.request.context.get(SKIP_GLOBAL_ERROR_TOAST)).toBe(true);

    usersRequest.flush([
      {
        id: 7,
        firstName: 'Mario',
        lastName: 'Rossi',
        email: 'mario@example.com',
        password: 'Password1!'
      }
    ]);

    expect(nextSpy).toHaveBeenCalledOnce();
    expect(service.isAuthenticated()).toBe(true);
    expect(localStorage.getItem('bookstore_user')).toContain('mario@example.com');
    expect(localStorage.getItem('bookstore_token')).toContain('mock-token-7-');
  });

  it('login restituisce errore su credenziali non valide', () => {
    const service = TestBed.inject(AuthApiService);
    const httpTesting = TestBed.inject(HttpTestingController);

    const errorSpy = vi.fn();
    service.login({ email: 'mario@example.com', password: 'Wrong' }).subscribe({ error: errorSpy });

    const usersRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    usersRequest.flush([]);

    expect(errorSpy).toHaveBeenCalledOnce();
    expect(service.isAuthenticated()).toBe(false);
  });

  it('login propaga errore HTTP backend e non autentica utente', () => {
    const service = TestBed.inject(AuthApiService);
    const httpTesting = TestBed.inject(HttpTestingController);

    const errorSpy = vi.fn();
    service.login({ email: 'mario@example.com', password: 'Password1!' }).subscribe({ error: errorSpy });

    const usersRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    usersRequest.flush({ message: 'Server error' }, { status: 500, statusText: 'Server Error' });

    expect(errorSpy).toHaveBeenCalledOnce();
    expect(service.isAuthenticated()).toBe(false);
  });

  it('register crea utente e salva sessione quando email non esiste', () => {
    const service = TestBed.inject(AuthApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const nextSpy = vi.fn();

    service
      .register({
        firstName: 'Luca',
        lastName: 'Bianchi',
        email: 'LUCA@EXAMPLE.COM',
        password: 'Password1!'
      })
      .subscribe(nextSpy);

    const checkRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    expect(checkRequest.request.params.get('email')).toBe('luca@example.com');
    expect(checkRequest.request.context.get(SKIP_GLOBAL_ERROR_TOAST)).toBe(true);
    checkRequest.flush([]);

    const createRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    expect(createRequest.request.method).toBe('POST');
    expect(createRequest.request.context.get(SKIP_GLOBAL_ERROR_TOAST)).toBe(true);

    createRequest.flush({
      id: 15,
      firstName: 'Luca',
      lastName: 'Bianchi',
      email: 'luca@example.com',
      password: 'Password1!'
    });

    expect(nextSpy).toHaveBeenCalledOnce();
    expect(service.currentUser()?.email).toBe('luca@example.com');
    expect(service.isAuthenticated()).toBe(true);
  });

  it('register restituisce errore se email già registrata e non invia POST', () => {
    const service = TestBed.inject(AuthApiService);
    const httpTesting = TestBed.inject(HttpTestingController);
    const errorSpy = vi.fn();

    service
      .register({
        firstName: 'Mario',
        lastName: 'Rossi',
        email: 'mario@example.com',
        password: 'Password1!'
      })
      .subscribe({ error: errorSpy });

    const checkRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    checkRequest.flush([
      {
        id: 1,
        firstName: 'Mario',
        lastName: 'Rossi',
        email: 'mario@example.com',
        password: 'Password1!'
      }
    ]);

    httpTesting.expectNone((request) => request.method === 'POST' && request.url.endsWith('/users'));
    expect(errorSpy).toHaveBeenCalledOnce();
    expect(service.isAuthenticated()).toBe(false);
  });

  it('ripristina sessione da localStorage nel costruttore', () => {
    localStorage.setItem(
      'bookstore_user',
      JSON.stringify({ id: 99, firstName: 'Ada', lastName: 'Lovelace', email: 'ada@example.com' })
    );
    localStorage.setItem('bookstore_token', 'mock-token-99-1234');

    const service = TestBed.inject(AuthApiService);

    expect(service.currentUser()?.email).toBe('ada@example.com');
    expect(service.token()).toBe('mock-token-99-1234');
    expect(service.isAuthenticated()).toBe(true);
  });

  it('logout pulisce stato e localStorage', () => {
    const service = TestBed.inject(AuthApiService);
    const httpTesting = TestBed.inject(HttpTestingController);

    service.login({ email: 'mario@example.com', password: 'Password1!' }).subscribe();
    const usersRequest = httpTesting.expectOne((request) => request.url.endsWith('/users'));
    usersRequest.flush([
      {
        id: 1,
        firstName: 'Mario',
        lastName: 'Rossi',
        email: 'mario@example.com',
        password: 'Password1!'
      }
    ]);

    service.logout();

    expect(service.currentUser()).toBeNull();
    expect(service.token()).toBeNull();
    expect(localStorage.getItem('bookstore_user')).toBeNull();
    expect(localStorage.getItem('bookstore_token')).toBeNull();
  });
});
