import { PLATFORM_ID } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { Book } from '../../models/book';
import { CartStore } from './cart.store';

describe('CartStore', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: PLATFORM_ID, useValue: 'browser' }, CartStore]
    });
  });

  it('incrementa quantità sullo stesso libro e aggiorna i totali', () => {
    const store = TestBed.inject(CartStore);
    store.clear();

    const book: Book = {
      id: 101,
      categoryId: 2,
      title: 'Angular Avanzato',
      author: 'A. Dev',
      description: 'Libro di test',
      imageUrl: 'https://example.com/angular.jpg',
      price: 25,
      rating: 4.8,
      stock: 7
    };

    store.add(book);
    store.add(book);

    expect(store.items().length).toBe(1);
    expect(store.items()[0]?.quantity).toBe(2);
    expect(store.totalItems()).toBe(2);
    expect(store.totalAmount()).toBe(50);
  });
});