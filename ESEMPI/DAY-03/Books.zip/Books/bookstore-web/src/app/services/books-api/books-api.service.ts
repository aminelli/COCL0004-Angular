import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Book } from '../../models/book';
import { Category } from '../../models/category';

@Injectable({
  providedIn: 'root'
})
export class BooksApiService {
  private readonly http = inject(HttpClient);
  private readonly apiBaseUrl = environment.apiBaseUrl;

  getBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(`${this.apiBaseUrl}/books`);
  }

  getBookById(bookId: number): Observable<Book | null> {
    return this.http.get<Book>(`${this.apiBaseUrl}/books/${bookId}`).pipe(map((book) => book ?? null));
  }

  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${this.apiBaseUrl}/categories`);
  }
}