import { isPlatformBrowser } from '@angular/common';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { inject, Injectable, PLATFORM_ID, signal } from '@angular/core';

export type ToastVariant = 'success' | 'error' | 'info' | 'warning';

export interface ToastMessage {
  id: number;
  text: string;
  variant: ToastVariant;
  durationMs: number;
}

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  private static readonly MAX_VISIBLE_TOASTS = 3;

  private readonly liveAnnouncer = inject(LiveAnnouncer);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly toastsSignal = signal<ToastMessage[]>([]);
  private readonly pendingQueue: ToastMessage[] = [];
  private nextToastId = 1;

  readonly toasts = this.toastsSignal.asReadonly();

  success(text: string, durationMs = 3500): void {
    this.show({ text, variant: 'success', durationMs });
  }

  error(text: string, durationMs = 5000): void {
    this.show({ text, variant: 'error', durationMs });
  }

  info(text: string, durationMs = 3500): void {
    this.show({ text, variant: 'info', durationMs });
  }

  warning(text: string, durationMs = 4500): void {
    this.show({ text, variant: 'warning', durationMs });
  }

  remove(id: number): void {
    const pendingIndex = this.pendingQueue.findIndex((toast) => toast.id === id);
    if (pendingIndex >= 0) {
      this.pendingQueue.splice(pendingIndex, 1);
      return;
    }

    const previousLength = this.toastsSignal().length;
    this.toastsSignal.update((items) => items.filter((item) => item.id !== id));

    if (this.toastsSignal().length < previousLength) {
      this.promoteFromQueue();
    }
  }

  private show(input: Omit<ToastMessage, 'id'>): void {
    const toast: ToastMessage = {
      ...input,
      id: this.nextToastId++
    };

    // Evitiamo overflow visivo: al massimo 3 toast sullo schermo, gli altri in coda.
    if (this.toastsSignal().length < ToastService.MAX_VISIBLE_TOASTS) {
      this.pushVisibleToast(toast);
      return;
    }

    this.enqueueByPriority(toast);
  }

  private enqueueByPriority(toast: ToastMessage): void {
    const newPriority = this.getPriority(toast.variant);

    // Inserimento stabile per priorità: error/warning hanno precedenza, ma tra pari
    // manteniamo l'ordine di arrivo (FIFO) per non creare salti inattesi.
    const insertAt = this.pendingQueue.findIndex(
      (queuedToast) => this.getPriority(queuedToast.variant) < newPriority
    );

    if (insertAt === -1) {
      this.pendingQueue.push(toast);
      return;
    }

    this.pendingQueue.splice(insertAt, 0, toast);
  }

  private getPriority(variant: ToastVariant): number {
    switch (variant) {
      case 'error':
        return 4;
      case 'warning':
        return 3;
      case 'success':
        return 2;
      case 'info':
      default:
        return 1;
    }
  }

  private pushVisibleToast(toast: ToastMessage): void {
    this.toastsSignal.update((items) => [...items, toast]);

    // Accessibilità WCAG: annuncio solo quando il toast diventa visibile.
    const politeness = toast.variant === 'error' || toast.variant === 'warning' ? 'assertive' : 'polite';
    void this.liveAnnouncer.announce(toast.text, politeness);

    if (isPlatformBrowser(this.platformId)) {
      setTimeout(() => this.remove(toast.id), toast.durationMs);
    }
  }

  private promoteFromQueue(): void {
    if (this.pendingQueue.length === 0) {
      return;
    }

    if (this.toastsSignal().length >= ToastService.MAX_VISIBLE_TOASTS) {
      return;
    }

    const nextToast = this.pendingQueue.shift();
    if (!nextToast) {
      return;
    }

    this.pushVisibleToast(nextToast);
  }
}