import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { CheckoutPageComponent } from './checkout-page.component';
import { CartStore } from '../../services/cart-store';
import { AuthApiService } from '../../services/auth-api';
import { OrdersApiService } from '../../services/orders-api';
import { ToastService } from '../../services/toast';

describe('CheckoutPageComponent', () => {
  const cartStoreMock = {
    items: vi.fn(() => [
      {
        book: {
          id: 1,
          categoryId: 1,
          title: 'Libro Test',
          author: 'Autore Test',
          description: 'Descrizione',
          imageUrl: 'https://example.com/cover.jpg',
          price: 20,
          rating: 4.5,
          stock: 10
        },
        quantity: 1
      }
    ]),
    totalAmount: vi.fn(() => 20),
    clear: vi.fn()
  };

  const authServiceMock = {
    currentUser: vi.fn(() => ({ id: 1, firstName: 'Mario', lastName: 'Rossi', email: 'mario@example.com' }))
  };

  const ordersApiServiceMock = {
    createOrder: vi.fn()
  };

  const toastServiceMock = {
    success: vi.fn(),
    warning: vi.fn(),
    error: vi.fn(),
    info: vi.fn()
  };

  beforeEach(async () => {
    vi.clearAllMocks();

    await TestBed.configureTestingModule({
      imports: [CheckoutPageComponent],
      providers: [
        provideRouter([]),
        { provide: CartStore, useValue: cartStoreMock },
        { provide: AuthApiService, useValue: authServiceMock },
        { provide: OrdersApiService, useValue: ordersApiServiceMock },
        { provide: ToastService, useValue: toastServiceMock }
      ]
    }).compileComponents();
  });

  it('blocca submit e mostra warning quando la carta è scaduta', () => {
    const fixture = TestBed.createComponent(CheckoutPageComponent);
    const component = fixture.componentInstance;

    component.checkoutForm.setValue({
      shippingAddress: 'Via Roma 1, Milano',
      cardHolder: 'Mario Rossi',
      cardNumber: '4242 4242 4242 4242',
      expiry: '01/20',
      cvv: '123'
    });

    component.onSubmit();

    expect(toastServiceMock.warning).toHaveBeenCalledWith(
      'La carta risulta scaduta. Controlla la data di scadenza.'
    );
    expect(ordersApiServiceMock.createOrder).not.toHaveBeenCalled();
  });
});