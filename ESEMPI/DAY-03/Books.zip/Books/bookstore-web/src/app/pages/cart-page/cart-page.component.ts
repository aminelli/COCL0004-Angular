import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartStore } from '../../services/cart-store';
import { ToastService } from '../../services/toast';

@Component({
  selector: 'app-cart-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './cart-page.component.html',
  styleUrl: './cart-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CartPageComponent {
  readonly cartStore = inject(CartStore);
  private readonly toastService = inject(ToastService);

  constructor() {
    if (this.cartStore.items().length === 0) {
      this.toastService.info('Il carrello è vuoto. Aggiungi un libro per continuare.');
    }
  }

  increase(bookId: number, quantity: number): void {
    this.cartStore.updateQuantity(bookId, quantity + 1);
  }

  decrease(bookId: number, quantity: number): void {
    this.cartStore.updateQuantity(bookId, quantity - 1);
  }

  remove(bookId: number): void {
    const removedItem = this.cartStore.items().find((item) => item.book.id === bookId);
    this.cartStore.remove(bookId);
    if (removedItem) {
      this.toastService.info(`${removedItem.book.title} rimosso dal carrello.`);
    }
  }
}