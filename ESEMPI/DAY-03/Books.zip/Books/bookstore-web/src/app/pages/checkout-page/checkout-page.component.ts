import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { A11yModule } from '@angular/cdk/a11y';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { CartStore } from '../../services/cart-store';
import { AuthApiService } from '../../services/auth-api';
import { OrdersApiService } from '../../services/orders-api';
import { Order } from '../../models/order';
import { ToastService } from '../../services/toast';
import { cardNumberValidator, expiryValidator, trimValidator } from '../../shared/validators';

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, A11yModule],
  templateUrl: './checkout-page.component.html',
  styleUrl: './checkout-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CheckoutPageComponent {
  private readonly formBuilder = inject(FormBuilder);
  readonly cartStore = inject(CartStore);
  private readonly authService = inject(AuthApiService);
  private readonly ordersApiService = inject(OrdersApiService);
  private readonly router = inject(Router);
  private readonly toastService = inject(ToastService);

  readonly isSubmitting = signal(false);
  readonly totalAmount = computed(() => this.cartStore.totalAmount());

  readonly checkoutForm = this.formBuilder.nonNullable.group({
    shippingAddress: [
      '',
      [Validators.required, Validators.minLength(10), Validators.maxLength(200), trimValidator]
    ],
    cardHolder: [
      '',
      [Validators.required, Validators.minLength(3), Validators.maxLength(80), trimValidator]
    ],
    cardNumber: ['', [Validators.required, cardNumberValidator]],
    expiry: ['', [Validators.required, expiryValidator]],
    cvv: ['', [Validators.required, Validators.pattern(/^\d{3,4}$/), trimValidator]]
  });

  isControlInvalid(controlName: keyof typeof this.checkoutForm.controls): boolean {
    const control = this.checkoutForm.controls[controlName];
    return control.invalid && (control.touched || control.dirty);
  }

  constructor() {
    if (this.cartStore.items().length === 0) {
      this.toastService.warning('Carrello vuoto: aggiungi almeno un prodotto prima del checkout.');
    }
  }

  onSubmit(): void {
    if (this.isSubmitting()) {
      return;
    }

    // Form reattivo con validatori: riduce errori di input prima della simulazione pagamento.
    if (this.checkoutForm.invalid) {
      this.checkoutForm.markAllAsTouched();
      this.toastService.warning(this.buildValidationMessage());
      return;
    }

    const user = this.authService.currentUser();

    if (!user) {
      this.toastService.info('Per completare l\'acquisto devi effettuare il login.');
      void this.router.navigateByUrl('/login');
      return;
    }

    const formValue = this.checkoutForm.getRawValue();
    const normalizedCard = formValue.cardNumber.replace(/\s+/g, '');
    const paymentLast4 = normalizedCard.slice(-4);

    const order: Order = {
      userId: user.id,
      createdAt: new Date().toISOString(),
      total: this.cartStore.totalAmount(),
      shippingAddress: formValue.shippingAddress.trim(),
      paymentLast4,
      items: this.cartStore.items().map((item) => ({
        bookId: item.book.id,
        title: item.book.title,
        quantity: item.quantity,
        unitPrice: item.book.price
      }))
    };

    this.isSubmitting.set(true);

    // Simulazione acquisto: inviamo l'ordine al backend mock e svuotiamo il carrello.
    this.ordersApiService
      .createOrder(order)
      .pipe(finalize(() => this.isSubmitting.set(false)))
      .subscribe({
        next: (createdOrder) => {
          this.cartStore.clear();
          this.checkoutForm.reset();
          this.toastService.success(
            `Acquisto completato con successo. Numero ordine: #${createdOrder.id ?? 'N/D'}`
          );
        },
        error: () => {
          const message = 'Pagamento non riuscito. Riprova tra qualche secondo.';
          this.toastService.error(message);
        }
      });
  }

  private buildValidationMessage(): string {
    const { shippingAddress, cardHolder, cardNumber, expiry, cvv } = this.checkoutForm.controls;

    if (shippingAddress.hasError('required') || shippingAddress.hasError('minlength')) {
      return 'Inserisci un indirizzo di spedizione completo.';
    }

    if (shippingAddress.hasError('trim')) {
      return 'L\'indirizzo non deve avere spazi iniziali o finali.';
    }

    if (cardHolder.hasError('required') || cardHolder.hasError('minlength')) {
      return 'Inserisci il nome dell\'intestatario della carta.';
    }

    if (cardHolder.hasError('trim')) {
      return 'Il nome intestatario non deve avere spazi iniziali o finali.';
    }

    if (cardNumber.hasError('required') || cardNumber.hasError('cardNumberInvalid')) {
      return 'Inserisci un numero carta valido di 16 cifre.';
    }

    if (expiry.hasError('required') || expiry.hasError('expiryFormat')) {
      return 'Inserisci una scadenza valida nel formato MM/AA.';
    }

    if (expiry.hasError('expiryPast')) {
      return 'La carta risulta scaduta. Controlla la data di scadenza.';
    }

    if (cvv.hasError('required') || cvv.hasError('pattern')) {
      return 'Inserisci un CVV valido (3 o 4 cifre).';
    }

    if (cvv.hasError('trim')) {
      return 'Il CVV non deve avere spazi iniziali o finali.';
    }

    return 'Compila correttamente tutti i campi di pagamento.';
  }
}