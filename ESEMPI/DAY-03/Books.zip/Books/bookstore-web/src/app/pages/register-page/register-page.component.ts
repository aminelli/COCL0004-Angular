import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { AuthApiService } from '../../services/auth-api';
import { ToastService } from '../../services/toast';
import {
  passwordsMatchValidator,
  STRONG_PASSWORD_PATTERN,
  trimValidator
} from '../../shared/validators';

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register-page.component.html',
  styleUrl: './register-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisterPageComponent {
  private readonly formBuilder = inject(FormBuilder);
  private readonly authService = inject(AuthApiService);
  private readonly router = inject(Router);
  private readonly toastService = inject(ToastService);

  readonly isSubmitting = signal(false);

  readonly registerForm = this.formBuilder.nonNullable.group({
    firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50), trimValidator]],
    lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50), trimValidator]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(120), trimValidator]],
    password: [
      '',
      [
        Validators.required,
        Validators.pattern(STRONG_PASSWORD_PATTERN)
      ]
    ],
    confirmPassword: ['', [Validators.required, trimValidator]]
  }, { validators: [passwordsMatchValidator()] });

  isControlInvalid(controlName: keyof typeof this.registerForm.controls): boolean {
    const control = this.registerForm.controls[controlName];
    const hasMismatch = controlName === 'confirmPassword' && this.registerForm.hasError('passwordMismatch');

    return (control.invalid || hasMismatch) && (control.touched || control.dirty);
  }

  onSubmit(): void {
    if (this.isSubmitting()) {
      return;
    }

    // Pattern consigliato: validazione rapida del form prima di entrare nel flusso asincrono.
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      this.toastService.warning(this.buildValidationMessage());
      return;
    }

    const payload = this.registerForm.getRawValue();

    this.isSubmitting.set(true);

    this.authService
      .register({
        // Normalizziamo i dati prima di inviarli all'API per migliorare consistenza e qualità.
        firstName: payload.firstName.trim(),
        lastName: payload.lastName.trim(),
        email: payload.email.trim().toLowerCase(),
        password: payload.password
      })
      .pipe(finalize(() => this.isSubmitting.set(false)))
      .subscribe({
        next: () => {
          this.toastService.success('Registrazione completata con successo.');
          this.registerForm.reset();
          void this.router.navigateByUrl('/catalog');
        },
        error: (error: { error?: { message?: string } }) => {
          const message = error.error?.message ?? 'Registrazione non riuscita. Riprova.';
          this.toastService.error(message);
        }
      });
  }

  private buildValidationMessage(): string {
    const { firstName, lastName, email, password, confirmPassword } = this.registerForm.controls;

    if (firstName.hasError('required') || lastName.hasError('required')) {
      return 'Nome e cognome sono obbligatori.';
    }

    if (firstName.hasError('trim') || lastName.hasError('trim')) {
      return 'Nome e cognome non devono avere spazi iniziali o finali.';
    }

    if (email.hasError('required') || email.hasError('email')) {
      return 'Inserisci un indirizzo email valido.';
    }

    if (email.hasError('trim')) {
      return 'L\'email non deve avere spazi iniziali o finali.';
    }

    if (password.hasError('required') || password.hasError('pattern')) {
      return 'La password deve avere almeno 8 caratteri, una maiuscola, una minuscola, un numero e un simbolo.';
    }

    if (confirmPassword.hasError('required')) {
      return 'Conferma la password per continuare.';
    }

    if (confirmPassword.hasError('trim')) {
      return 'La conferma password non deve avere spazi iniziali o finali.';
    }

    if (this.registerForm.hasError('passwordMismatch')) {
      return 'Password e conferma password non coincidono.';
    }

    return 'Compila tutti i campi obbligatori in modo corretto.';
  }
}