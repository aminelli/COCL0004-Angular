import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { toSignal } from '@angular/core/rxjs-interop';
import { map, switchMap, tap } from 'rxjs';
import { BooksApiService } from '../../services/books-api';
import { CartStore } from '../../services/cart-store';
import { ToastService } from '../../services/toast';

@Component({
  selector: 'app-book-detail-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './book-detail-page.component.html',
  styleUrl: './book-detail-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BookDetailPageComponent {
  private readonly route = inject(ActivatedRoute);
  private readonly booksApiService = inject(BooksApiService);
  private readonly cartStore = inject(CartStore);
  private readonly toastService = inject(ToastService);
  private readonly notFoundToastShown = signal(false);

  readonly book = toSignal(
    this.route.paramMap.pipe(
      map((params) => Number(params.get('id'))),
      tap(() => this.notFoundToastShown.set(false)),
      switchMap((bookId) => this.booksApiService.getBookById(bookId)),
      tap((book) => {
        if (!book && !this.notFoundToastShown()) {
          this.toastService.error('Libro non trovato.');
          this.notFoundToastShown.set(true);
        }
      })
    ),
    { initialValue: null }
  );

  addToCart(): void {
    const currentBook = this.book();

    if (!currentBook) {
      return;
    }

    this.cartStore.add(currentBook);
    this.toastService.success(`${currentBook.title} aggiunto al carrello.`);
  }
}