import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { CommonModule } from '@angular/common';
import { AuthApiService } from '../../services/auth-api';
import { ToastService } from '../../services/toast';
import { trimValidator } from '../../shared/validators';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login-page.component.html',
  styleUrl: './login-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginPageComponent {
  private readonly formBuilder = inject(FormBuilder);
  private readonly authService = inject(AuthApiService);
  private readonly router = inject(Router);
  private readonly toastService = inject(ToastService);

  readonly isSubmitting = signal(false);

  readonly loginForm = this.formBuilder.nonNullable.group({
    email: ['', [Validators.required, Validators.email, Validators.maxLength(120), trimValidator]],
    password: ['', [Validators.required, Validators.minLength(8), trimValidator]]
  });

  isControlInvalid(controlName: keyof typeof this.loginForm.controls): boolean {
    const control = this.loginForm.controls[controlName];
    return control.invalid && (control.touched || control.dirty);
  }

  onSubmit(): void {
    if (this.isSubmitting()) {
      return;
    }

    // Validazione sincrona lato client: evita chiamate HTTP inutili e migliora UX.
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      this.toastService.warning(this.buildValidationMessage());
      return;
    }

    const payload = this.loginForm.getRawValue();

    this.isSubmitting.set(true);

    // Programmazione reattiva: ci agganciamo allo stream HTTP e gestiamo stato/successo/errore.
    this.authService
      .login({
        email: payload.email.trim().toLowerCase(),
        password: payload.password
      })
      .pipe(finalize(() => this.isSubmitting.set(false)))
      .subscribe({
        next: () => {
          this.toastService.success('Login eseguito con successo.');
          void this.router.navigateByUrl('/catalog');
        },
        error: (error: { error?: { message?: string } }) => {
          const message = error.error?.message ?? 'Credenziali non valide. Riprova.';
          this.toastService.error(message);
        }
      });
  }

  private buildValidationMessage(): string {
    const { email, password } = this.loginForm.controls;

    if (email.hasError('required') || email.hasError('email')) {
      return 'Inserisci un indirizzo email valido.';
    }

    if (email.hasError('trim')) {
      return 'L\'email non deve avere spazi iniziali o finali.';
    }

    if (password.hasError('required') || password.hasError('minlength')) {
      return 'La password è obbligatoria e deve contenere almeno 8 caratteri.';
    }

    if (password.hasError('trim')) {
      return 'La password non deve avere spazi iniziali o finali.';
    }

    return 'Inserisci credenziali valide prima di continuare.';
  }
}