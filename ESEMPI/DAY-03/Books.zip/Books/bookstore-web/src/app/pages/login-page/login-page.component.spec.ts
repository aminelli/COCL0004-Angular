import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { LoginPageComponent } from './login-page.component';
import { AuthApiService } from '../../services/auth-api';
import { ToastService } from '../../services/toast';
import { provideRouter, Router } from '@angular/router';

describe('LoginPageComponent', () => {
  const authServiceMock = {
    login: vi.fn()
  };

  const toastServiceMock = {
    success: vi.fn(),
    warning: vi.fn(),
    error: vi.fn(),
    info: vi.fn()
  };

  beforeEach(async () => {
    vi.clearAllMocks();

    await TestBed.configureTestingModule({
      imports: [LoginPageComponent],
      providers: [
        provideRouter([]),
        { provide: AuthApiService, useValue: authServiceMock },
        { provide: ToastService, useValue: toastServiceMock }
      ]
    }).compileComponents();
  });

  it('mostra warning e non invia login se il form è invalido', () => {
    const fixture = TestBed.createComponent(LoginPageComponent);
    const component = fixture.componentInstance;

    component.loginForm.setValue({ email: 'email-non-valida', password: '123' });
    component.onSubmit();

    expect(toastServiceMock.warning).toHaveBeenCalledOnce();
    expect(authServiceMock.login).not.toHaveBeenCalled();
  });

  it('invia login con email normalizzata e naviga al catalogo su successo', () => {
    const router = TestBed.inject(Router);
    const navigateByUrlSpy = vi.spyOn(router, 'navigateByUrl').mockResolvedValue(true);

    authServiceMock.login.mockReturnValue(
      of({
        token: 'mock-token',
        user: { id: 1, firstName: 'Mario', lastName: 'Rossi', email: 'mario@example.com' }
      })
    );

    const fixture = TestBed.createComponent(LoginPageComponent);
    const component = fixture.componentInstance;

    component.loginForm.setValue({ email: 'MARIO@EXAMPLE.COM', password: 'Password1!' });
    component.onSubmit();

    expect(authServiceMock.login).toHaveBeenCalledWith({
      email: 'mario@example.com',
      password: 'Password1!'
    });
    expect(toastServiceMock.success).toHaveBeenCalledOnce();
    expect(navigateByUrlSpy).toHaveBeenCalledWith('/catalog');
  });
});