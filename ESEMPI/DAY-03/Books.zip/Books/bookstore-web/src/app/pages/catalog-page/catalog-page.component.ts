import { ChangeDetectionStrategy, Component, effect, inject, signal } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { toSignal, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  BehaviorSubject,
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  map,
  startWith
} from 'rxjs';
import { Book } from '../../models/book';
import { Category } from '../../models/category';
import { BooksApiService } from '../../services/books-api';
import { CartStore } from '../../services/cart-store';
import { ToastService } from '../../services/toast';

interface CatalogViewModel {
  categories: Category[];
  filteredBooks: Book[];
  selectedCategoryId: number | null;
  searchTerm: string;
}

@Component({
  selector: 'app-catalog-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './catalog-page.component.html',
  styleUrl: './catalog-page.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CatalogPageComponent {
  private readonly booksApiService = inject(BooksApiService);
  private readonly cartStore = inject(CartStore);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly toastService = inject(ToastService);
  private readonly emptyResultToastShown = signal(false);

  readonly searchControl = new FormControl('', { nonNullable: true });

  private readonly selectedCategoryId$ = new BehaviorSubject<number | null>(null);
  private readonly searchTerm$ = this.searchControl.valueChanges.pipe(
    startWith(this.searchControl.value),
    debounceTime(250),
    map((value) => value.trim().toLowerCase()),
    distinctUntilChanged()
  );

  private readonly viewModel$ = combineLatest([
    this.booksApiService.getBooks(),
    this.booksApiService.getCategories(),
    this.selectedCategoryId$,
    this.searchTerm$
  ]).pipe(
    // ViewModel reattivo: ogni cambiamento in books/categorie/categoria selezionata/termine
    // ricalcola automaticamente la vista senza side-effect manuali nei componenti.
    map(([books, categories, selectedCategoryId, searchTerm]) => {
      const filteredByCategory = selectedCategoryId
        ? books.filter((book) => book.categoryId === selectedCategoryId)
        : books;

      const filteredBooks = filteredByCategory.filter(
        (book) =>
          book.title.toLowerCase().includes(searchTerm) ||
          book.author.toLowerCase().includes(searchTerm)
      );

      return {
        categories,
        filteredBooks,
        selectedCategoryId,
        searchTerm
      } satisfies CatalogViewModel;
    })
  );

  readonly vm = toSignal(this.viewModel$, {
    initialValue: {
      categories: [],
      filteredBooks: [],
      selectedCategoryId: null,
      searchTerm: ''
    }
  });

  constructor() {
    // Allineiamo il filtro categoria con i query param per avere URL condivisibili.
    this.route.queryParamMap
      .pipe(
        map((params) => {
          const rawCategory = params.get('category');
          return rawCategory ? Number(rawCategory) : null;
        }),
        takeUntilDestroyed()
      )
      .subscribe((categoryId) => this.selectedCategoryId$.next(categoryId));

    // Toast automatico di stato: quando i risultati diventano vuoti dopo il caricamento dati.
    effect(() => {
      const currentVm = this.vm();
      const hasLoadedCategories = currentVm.categories.length > 0;
      const hasNoResults = currentVm.filteredBooks.length === 0;

      if (hasLoadedCategories && hasNoResults && !this.emptyResultToastShown()) {
        this.toastService.info('Nessun libro trovato con i filtri selezionati.');
        this.emptyResultToastShown.set(true);
      }

      if (!hasNoResults && this.emptyResultToastShown()) {
        this.emptyResultToastShown.set(false);
      }
    });
  }

  onCategoryChange(rawCategoryId: string): void {
    // Strategia consigliata: lo stato filtro viene riflesso nell'URL (source of truth navigabile).
    const selectedCategoryId = rawCategoryId ? Number(rawCategoryId) : null;

    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { category: selectedCategoryId ?? null },
      queryParamsHandling: 'merge'
    });
  }

  addToCart(book: Book): void {
    // Feedback accessibile non visuale: annuncio live per screen reader.
    this.cartStore.add(book);
    this.toastService.success(`${book.title} aggiunto al carrello.`);
  }
}