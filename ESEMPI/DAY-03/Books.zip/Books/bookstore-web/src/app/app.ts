import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthApiService } from './services/auth-api';
import { CartStore } from './services/cart-store';
import { ToastService } from './services/toast';
import { ToastHostComponent } from './components/toast-host';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ToastHostComponent],
  templateUrl: './app.html',
  styleUrl: './app.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class App {
  protected readonly authService = inject(AuthApiService);
  protected readonly cartStore = inject(CartStore);
  private readonly toastService = inject(ToastService);

  protected readonly cartItemsCount = computed(() =>
    this.cartStore.items().reduce((acc, item) => acc + item.quantity, 0)
  );

  protected logout(): void {
    this.authService.logout();
    this.toastService.info('Logout effettuato con successo.');
  }
}
