import { HttpClient, HttpContext, provideHttpClient, withInterceptors } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { httpErrorInterceptor, SKIP_GLOBAL_ERROR_TOAST } from './http-error.interceptor';
import { ToastService } from '../../services/toast';

describe('httpErrorInterceptor', () => {
  const toastServiceMock = {
    error: vi.fn()
  };

  beforeEach(() => {
    vi.clearAllMocks();

    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(withInterceptors([httpErrorInterceptor])),
        provideHttpClientTesting(),
        {
          provide: ToastService,
          useValue: toastServiceMock
        }
      ]
    });
  });

  it('mostra toast globale con messaggio mappato su errore 404', () => {
    const httpClient = TestBed.inject(HttpClient);
    const httpTesting = TestBed.inject(HttpTestingController);

    httpClient.post('/resource', {}).subscribe({ error: () => undefined });

    const request = httpTesting.expectOne('/resource');
    request.flush({ message: 'Not found' }, { status: 404, statusText: 'Not Found' });

    expect(toastServiceMock.error).toHaveBeenCalledWith('Risorsa non trovata.');
    httpTesting.verify();
  });

  it('non mostra toast se SKIP_GLOBAL_ERROR_TOAST è true', () => {
    const httpClient = TestBed.inject(HttpClient);
    const httpTesting = TestBed.inject(HttpTestingController);

    httpClient
      .post('/secure', {}, {
        context: new HttpContext().set(SKIP_GLOBAL_ERROR_TOAST, true)
      })
      .subscribe({ error: () => undefined });

    const request = httpTesting.expectOne('/secure');
    request.flush({ message: 'Unauthorized' }, { status: 401, statusText: 'Unauthorized' });

    expect(toastServiceMock.error).not.toHaveBeenCalled();
    httpTesting.verify();
  });

  it('mostra messaggio rete quando status HTTP è 0', () => {
    const httpClient = TestBed.inject(HttpClient);
    const httpTesting = TestBed.inject(HttpTestingController);

    httpClient.post('/offline', {}).subscribe({ error: () => undefined });

    const request = httpTesting.expectOne('/offline');
    request.error(new ProgressEvent('error'));

    expect(toastServiceMock.error).toHaveBeenCalledWith(
      'Connessione al server non disponibile. Verifica rete o API locale.'
    );
    httpTesting.verify();
  });
});
