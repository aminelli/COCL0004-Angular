import { HttpContextToken, HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, retry, throwError } from 'rxjs';
import { ToastService } from '../../services/toast';

export const SKIP_GLOBAL_ERROR_TOAST = new HttpContextToken<boolean>(() => false);

export const httpErrorInterceptor: HttpInterceptorFn = (request, next) => {
  const toastService = inject(ToastService);
  const shouldSkipToast = request.context.get(SKIP_GLOBAL_ERROR_TOAST);
  const shouldRetry = ['GET', 'HEAD', 'OPTIONS'].includes(request.method.toUpperCase());

  const stream$ = shouldRetry ? next(request).pipe(retry({ count: 1, delay: 250 })) : next(request);

  return stream$.pipe(
    catchError((error: HttpErrorResponse) => {
      if (!shouldSkipToast) {
        toastService.error(resolveHttpErrorMessage(error));
      }

      return throwError(() => error);
    })
  );
};

function resolveHttpErrorMessage(error: HttpErrorResponse): string {
  if (error.status === 0) {
    return 'Connessione al server non disponibile. Verifica rete o API locale.';
  }

  switch (error.status) {
    case 400:
      return 'Richiesta non valida. Controlla i dati inseriti.';
    case 401:
      return 'Sessione non valida. Effettua nuovamente il login.';
    case 403:
      return 'Operazione non consentita per l’utente corrente.';
    case 404:
      return 'Risorsa non trovata.';
    case 409:
      return 'Conflitto dati rilevato. Aggiorna la pagina e riprova.';
    case 422:
      return 'Dati non validi. Correggi i campi evidenziati.';
    case 500:
    case 502:
    case 503:
    case 504:
      return 'Errore temporaneo del server. Riprova tra qualche secondo.';
    default:
      return 'Si è verificato un errore inatteso. Riprova.';
  }
}