import { UrlTree, Router } from '@angular/router';
import { TestBed } from '@angular/core/testing';
import { authGuard } from './auth.guard';
import { AuthApiService } from '../../services/auth-api';

describe('authGuard', () => {
  it('consente accesso quando utente autenticato', () => {
    const parseUrlSpy = vi.fn();

    TestBed.configureTestingModule({
      providers: [
        {
          provide: AuthApiService,
          useValue: {
            isAuthenticated: vi.fn(() => true)
          }
        },
        {
          provide: Router,
          useValue: {
            parseUrl: parseUrlSpy
          }
        }
      ]
    });

    const result = TestBed.runInInjectionContext(() => authGuard({} as never, {} as never));

    expect(result).toBe(true);
    expect(parseUrlSpy).not.toHaveBeenCalled();
  });

  it('redireziona a /login quando utente non autenticato', () => {
    const loginTree = {} as UrlTree;
    const parseUrlSpy = vi.fn(() => loginTree);

    TestBed.configureTestingModule({
      providers: [
        {
          provide: AuthApiService,
          useValue: {
            isAuthenticated: vi.fn(() => false)
          }
        },
        {
          provide: Router,
          useValue: {
            parseUrl: parseUrlSpy
          }
        }
      ]
    });

    const result = TestBed.runInInjectionContext(() => authGuard({} as never, {} as never));

    expect(parseUrlSpy).toHaveBeenCalledWith('/login');
    expect(result).toBe(loginTree);
  });
});
