import { Routes } from '@angular/router';
import { authGuard } from './guards/auth';

export const routes: Routes = [
	{
		path: '',
		pathMatch: 'full',
		redirectTo: 'catalog'
	},
	{
		path: 'catalog',
		loadComponent: () =>
			import('./pages/catalog-page/catalog-page.component').then((m) => m.CatalogPageComponent)
	},
	{
		path: 'books/:id',
		loadComponent: () =>
			import('./pages/book-detail-page/book-detail-page.component').then(
				(m) => m.BookDetailPageComponent
			)
	},
	{
		path: 'login',
		loadComponent: () =>
			import('./pages/login-page/login-page.component').then((m) => m.LoginPageComponent)
	},
	{
		path: 'register',
		loadComponent: () =>
			import('./pages/register-page/register-page.component').then((m) => m.RegisterPageComponent)
	},
	{
		path: 'cart',
		loadComponent: () =>
			import('./pages/cart-page/cart-page.component').then((m) => m.CartPageComponent)
	},
	{
		path: 'checkout',
		canActivate: [authGuard],
		loadComponent: () =>
			import('./pages/checkout-page/checkout-page.component').then((m) => m.CheckoutPageComponent)
	},
	{
		path: '**',
		loadComponent: () =>
			import('./pages/not-found-page/not-found-page.component').then((m) => m.NotFoundPageComponent)
	}
];
