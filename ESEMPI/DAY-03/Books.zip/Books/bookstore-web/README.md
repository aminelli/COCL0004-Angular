# Bookstore Web Demo (Angular 21)

Demo e-commerce libri sviluppata con Angular 21 seguendo pattern moderni:

- Standalone Components (senza NgModule)
- Signals per stato locale e globale
- Programmazione Reattiva con RxJS
- SSR abilitato
- SCSS + Bootstrap 5 (caricato via CDN) per UI responsive
- Angular CDK A11y per accessibilità WCAG 2.x

## Struttura workspace

- Frontend Angular: `bookstore-web`
- API mock json-server: `bookstore-api`

## Avvio rapido

Apri due terminali separati nella root `app-comm`.

### 1) Avvio API mock

```bash
npm --prefix bookstore-api start
```

API disponibili su `http://localhost:3001`:

- `/books`
- `/categories`
- `/users`
- `/orders`

### 2) Avvio frontend Angular

```bash
npm --prefix bookstore-web start
```

Applicazione su `http://localhost:4200`.

Nota: Bootstrap viene caricato da CDN (`jsdelivr`) in `src/index.html`; è quindi necessaria connettività internet per lo stile completo.

## Build produzione

```bash
npm --prefix bookstore-web run build
```

## Test

Per istruzioni dettagliate su esecuzione test e modalità CI:

- [docs/testing-guide.md](docs/testing-guide.md)
- [docs/testing-ci-runbook.md](docs/testing-ci-runbook.md)

Comandi rapidi dalla root `app-comm`:

```bash
npm --prefix bookstore-web test
npm --prefix bookstore-web run test:ci
npm --prefix bookstore-web run test --watch=false --code-coverage
npm --prefix bookstore-web run e2e
npm --prefix bookstore-web run e2e:ui
```

## Percorso didattico consigliato

### 1. Programmazione Reattiva + RxJS

Osserva in particolare:

- `CatalogPageComponent`: combinazione stream (`combineLatest`) per filtri reattivi.
- `AuthApiService`: pipeline `map/switchMap/tap` per login/registrazione.
- `CheckoutPageComponent`: gestione stream HTTP con `finalize`.

### 2. Stato applicativo con Signals

Osserva:

- `CartStore`: `signal`, `computed`, `effect` per stato carrello e persistenza.
- `AuthApiService`: segnali readonly per sessione utente.

### 3. Accessibilità (Angular CDK A11y + WCAG 2.x)

Osserva:

- `LiveAnnouncer` per feedback vocalizzabili su azioni critiche.
- `cdkTrapFocus` nel checkout per gestione focus.
- Skip-link e uso corretto di label/aria nei form.

### 4. Responsive UI

La UI usa griglie e utility Bootstrap (`row`, `col-*`, `table-responsive`, `navbar`, `card`) per adattarsi a mobile/tablet/desktop.

## Flusso funzionale implementato

1. Registrazione utente
2. Login
3. Navigazione catalogo per categoria
4. Dettaglio prodotto
5. Gestione carrello (add/update/remove)
6. Checkout con simulazione carta di credito
7. Creazione ordine su API JSON

## Note tecniche Angular 21

- Nessun pattern deprecato intenzionalmente introdotto.
- App configurata con `provideHttpClient(withFetch())`.
- SSR mantenuto in `RenderMode.Server` per supportare route dinamiche.

## Accessibilità: checklist operativa

Per audit e miglioramento continuo WCAG 2.2 AA, usa la checklist in:

- [docs/WCAG-2.2-AA-checklist.md](docs/WCAG-2.2-AA-checklist.md)
