import { Routes } from '@angular/router';
import { BackpressurePlayground } from './components/backpressure-playground/backpressure-playground';

export const routes: Routes = [
	{
		path: '',
		component: BackpressurePlayground,
	},
	{
		path: '**',
		redirectTo: '',
	},
];
