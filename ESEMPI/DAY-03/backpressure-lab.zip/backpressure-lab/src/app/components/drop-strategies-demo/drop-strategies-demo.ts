import { Component, OnDestroy, signal } from '@angular/core';

type DropStrategy = 'drop-newest' | 'drop-oldest' | 'drop-random' | 'fail-fast';

@Component({
  selector: 'app-drop-strategies-demo',
  imports: [],
  templateUrl: './drop-strategies-demo.html',
  styleUrl: './drop-strategies-demo.scss',
})
export class DropStrategiesDemo implements OnDestroy {
  readonly running = signal(false);
  readonly produced = signal(0);
  readonly processed = signal(0);
  readonly dropped = signal(0);
  readonly queueSize = signal(0);
  readonly strategy = signal<DropStrategy>('drop-newest');
  readonly pressureTripped = signal(false);

  private readonly maxQueue = 12;
  private sequence = 0;
  private queue: number[] = [];
  private producerTimer?: ReturnType<typeof setInterval>;
  private consumerTimer?: ReturnType<typeof setInterval>;

  // Simula un producer più veloce del consumer: quando la coda è piena
  // applichiamo una strategia di drop diversa per osservare i trade-off.
  start(): void {
    this.stop();
    this.reset();
    this.running.set(true);

    this.producerTimer = setInterval(() => {
      const value = ++this.sequence;
      this.produced.update((count) => count + 1);

      if (this.queue.length < this.maxQueue) {
        this.queue.push(value);
        this.queueSize.set(this.queue.length);
        return;
      }

      this.applyDropStrategy(value);
      this.queueSize.set(this.queue.length);
    }, 70);

    this.consumerTimer = setInterval(() => {
      const next = this.queue.shift();
      if (next !== undefined) {
        this.processed.update((count) => count + 1);
      }
      this.queueSize.set(this.queue.length);
    }, 250);
  }

  stop(): void {
    if (this.producerTimer) {
      clearInterval(this.producerTimer);
      this.producerTimer = undefined;
    }
    if (this.consumerTimer) {
      clearInterval(this.consumerTimer);
      this.consumerTimer = undefined;
    }
    this.running.set(false);
  }

  setStrategy(value: string): void {
    if (value === 'drop-newest' || value === 'drop-oldest' || value === 'drop-random' || value === 'fail-fast') {
      this.strategy.set(value);
    }
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private applyDropStrategy(newValue: number): void {
    switch (this.strategy()) {
      case 'drop-newest':
        // Scarta l'evento appena arrivato per preservare la coda storica.
        this.dropped.update((count) => count + 1);
        break;
      case 'drop-oldest':
        // Elimina il più vecchio e mantiene i dati più recenti.
        this.queue.shift();
        this.queue.push(newValue);
        this.dropped.update((count) => count + 1);
        break;
      case 'drop-random': {
        // Rimuove un elemento casuale per distribuire la perdita su tutto il buffer.
        const index = Math.floor(Math.random() * this.queue.length);
        this.queue.splice(index, 1);
        this.queue.push(newValue);
        this.dropped.update((count) => count + 1);
        break;
      }
      case 'fail-fast':
        // In condizioni critiche interrompe subito il producer.
        this.pressureTripped.set(true);
        this.dropped.update((count) => count + 1);
        this.stop();
        break;
    }
  }

  private reset(): void {
    this.sequence = 0;
    this.queue = [];
    this.produced.set(0);
    this.processed.set(0);
    this.dropped.set(0);
    this.queueSize.set(0);
    this.pressureTripped.set(false);
  }

}
