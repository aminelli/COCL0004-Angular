import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DropStrategiesDemo } from './drop-strategies-demo';

describe('DropStrategiesDemo', () => {
  let component: DropStrategiesDemo;
  let fixture: ComponentFixture<DropStrategiesDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DropStrategiesDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DropStrategiesDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
