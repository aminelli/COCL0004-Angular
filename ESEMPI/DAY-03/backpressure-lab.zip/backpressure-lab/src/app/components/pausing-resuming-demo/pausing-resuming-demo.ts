import { Component, OnDestroy, signal } from '@angular/core';

@Component({
  selector: 'app-pausing-resuming-demo',
  imports: [],
  templateUrl: './pausing-resuming-demo.html',
  styleUrl: './pausing-resuming-demo.scss',
})
export class PausingResumingDemo implements OnDestroy {
  readonly running = signal(false);
  readonly paused = signal(false);
  readonly produced = signal(0);
  readonly consumed = signal(0);
  readonly buffered = signal(0);
  readonly dropped = signal(0);

  private readonly maxBuffer = 30;
  private sequence = 0;
  private queue: number[] = [];
  private producerTimer?: ReturnType<typeof setInterval>;
  private consumerTimer?: ReturnType<typeof setInterval>;

  // Producer e consumer sono disaccoppiati: quando il consumer è in pausa,
  // il producer continua e la pressione si accumula nel buffer.
  start(): void {
    this.stop();
    this.reset();
    this.running.set(true);

    this.producerTimer = setInterval(() => {
      const eventId = ++this.sequence;
      this.produced.update((count) => count + 1);

      if (this.queue.length >= this.maxBuffer) {
        // Per proteggere la memoria scartiamo il più vecchio in overflow prolungato.
        this.queue.shift();
        this.dropped.update((count) => count + 1);
      }

      this.queue.push(eventId);
      this.buffered.set(this.queue.length);
    }, 90);

    this.consumerTimer = setInterval(() => {
      if (this.paused()) {
        return;
      }

      const next = this.queue.shift();
      if (next !== undefined) {
        this.consumed.update((count) => count + 1);
      }
      this.buffered.set(this.queue.length);
    }, 180);
  }

  stop(): void {
    if (this.producerTimer) {
      clearInterval(this.producerTimer);
      this.producerTimer = undefined;
    }
    if (this.consumerTimer) {
      clearInterval(this.consumerTimer);
      this.consumerTimer = undefined;
    }
    this.running.set(false);
    this.paused.set(false);
  }

  pause(): void {
    this.paused.set(true);
  }

  resume(): void {
    this.paused.set(false);
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private reset(): void {
    this.sequence = 0;
    this.queue = [];
    this.produced.set(0);
    this.consumed.set(0);
    this.buffered.set(0);
    this.dropped.set(0);
  }

}
