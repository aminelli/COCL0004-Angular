import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WindowingDemo } from './windowing-demo';

describe('WindowingDemo', () => {
  let component: WindowingDemo;
  let fixture: ComponentFixture<WindowingDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WindowingDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WindowingDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
