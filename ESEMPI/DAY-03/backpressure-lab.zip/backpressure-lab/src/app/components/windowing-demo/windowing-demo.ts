import { Component, OnDestroy, signal } from '@angular/core';
import { bufferCount, interval, map, Subscription, tap } from 'rxjs';

@Component({
  selector: 'app-windowing-demo',
  imports: [],
  templateUrl: './windowing-demo.html',
  styleUrl: './windowing-demo.scss',
})
export class WindowingDemo implements OnDestroy {
  readonly running = signal(false);
  readonly chunkSize = signal(10);
  readonly produced = signal(0);
  readonly processed = signal(0);
  readonly windows = signal(0);
  readonly recentWindows = signal<string[]>([]);

  private sequence = 0;
  private streamSubscription?: Subscription;

  // Suddivide il flusso in finestre omogenee: utile per elaborazioni batch,
  // serializzazione e invii bulk verso servizi esterni.
  start(): void {
    this.stop();
    this.resetStats();
    this.running.set(true);

    this.streamSubscription = interval(70)
      .pipe(
        map(() => ++this.sequence),
        tap(() => this.produced.update((count) => count + 1)),
        bufferCount(this.chunkSize()),
      )
      .subscribe((chunk) => {
        this.windows.update((count) => count + 1);
        this.processed.update((count) => count + chunk.length);

        const row = `Finestra #${this.windows()} => ${chunk.length} eventi (start ${chunk[0]}, end ${chunk[chunk.length - 1]})`;
        this.recentWindows.update((items) => [row, ...items].slice(0, 5));
      });
  }

  stop(): void {
    this.streamSubscription?.unsubscribe();
    this.streamSubscription = undefined;
    this.running.set(false);
  }

  setChunkSize(value: number): void {
    this.chunkSize.set(Math.max(2, Math.min(100, value || 10)));
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private resetStats(): void {
    this.sequence = 0;
    this.produced.set(0);
    this.processed.set(0);
    this.windows.set(0);
    this.recentWindows.set([]);
  }

}
