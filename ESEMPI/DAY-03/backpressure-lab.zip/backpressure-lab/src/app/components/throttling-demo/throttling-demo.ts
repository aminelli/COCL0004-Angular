import { Component, OnDestroy, signal } from '@angular/core';
import { interval, map, Subscription, tap, throttleTime } from 'rxjs';

@Component({
  selector: 'app-throttling-demo',
  imports: [],
  templateUrl: './throttling-demo.html',
  styleUrl: './throttling-demo.scss',
})
export class ThrottlingDemo implements OnDestroy {
  readonly running = signal(false);
  readonly throttleMs = signal(500);
  readonly produced = signal(0);
  readonly forwarded = signal(0);
  readonly dropped = signal(0);
  readonly latestForwarded = signal<number | null>(null);

  private sequence = 0;
  private streamSubscription?: Subscription;

  // Permette il passaggio di un evento al massimo ogni X millisecondi,
  // scartando (o comprimendo) quelli intermedi per ridurre la pressione.
  start(): void {
    this.stop();
    this.resetStats();
    this.running.set(true);

    this.streamSubscription = interval(80)
      .pipe(
        map(() => ++this.sequence),
        tap(() => this.produced.update((value) => value + 1)),
        throttleTime(this.throttleMs(), undefined, { leading: true, trailing: true }),
      )
      .subscribe((value) => {
        this.forwarded.update((count) => count + 1);
        this.latestForwarded.set(value);
        this.dropped.set(this.produced() - this.forwarded());
      });
  }

  stop(): void {
    this.streamSubscription?.unsubscribe();
    this.streamSubscription = undefined;
    this.running.set(false);
  }

  setThrottleMs(value: number): void {
    const sanitized = Math.max(100, Math.min(3000, value || 500));
    this.throttleMs.set(sanitized);
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private resetStats(): void {
    this.sequence = 0;
    this.produced.set(0);
    this.forwarded.set(0);
    this.dropped.set(0);
    this.latestForwarded.set(null);
  }

}
