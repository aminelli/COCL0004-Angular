import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThrottlingDemo } from './throttling-demo';

describe('ThrottlingDemo', () => {
  let component: ThrottlingDemo;
  let fixture: ComponentFixture<ThrottlingDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ThrottlingDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ThrottlingDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
