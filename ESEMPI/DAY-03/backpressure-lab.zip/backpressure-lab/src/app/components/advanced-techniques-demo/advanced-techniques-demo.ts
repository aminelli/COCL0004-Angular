import { Component, OnDestroy, signal } from '@angular/core';
import { auditTime, bufferTime, filter, interval, map, sampleTime, Subscription, tap } from 'rxjs';

@Component({
  selector: 'app-advanced-techniques-demo',
  imports: [],
  templateUrl: './advanced-techniques-demo.html',
  styleUrl: './advanced-techniques-demo.scss',
})
export class AdvancedTechniquesDemo implements OnDestroy {
  readonly running = signal(false);
  readonly produced = signal(0);
  readonly sampledCount = signal(0);
  readonly auditedCount = signal(0);
  readonly conflatedCount = signal(0);
  readonly latestSampled = signal<number | null>(null);
  readonly latestAudited = signal<number | null>(null);
  readonly latestConflated = signal<number | null>(null);

  private sequence = 0;
  private subscriptions = new Subscription();

  // Tecniche extra utili in sistemi reali quando la pressione è variabile:
  // - sampling: osservazione periodica,
  // - auditing: emissione in coda alla finestra,
  // - conflation: compressione su ultimo valore del batch.
  start(): void {
    this.stop();
    this.reset();
    this.running.set(true);
    this.subscriptions = new Subscription();

    const source$ = interval(60).pipe(
      map(() => ++this.sequence),
      tap(() => this.produced.update((count) => count + 1)),
    );

    this.subscriptions.add(
      source$.pipe(sampleTime(500)).subscribe((value) => {
        this.sampledCount.update((count) => count + 1);
        this.latestSampled.set(value);
      }),
    );

    this.subscriptions.add(
      source$.pipe(auditTime(500)).subscribe((value) => {
        this.auditedCount.update((count) => count + 1);
        this.latestAudited.set(value);
      }),
    );

    this.subscriptions.add(
      source$
        .pipe(
          bufferTime(400),
          filter((batch) => batch.length > 0),
          map((batch) => batch[batch.length - 1]),
        )
        .subscribe((value) => {
          this.conflatedCount.update((count) => count + 1);
          this.latestConflated.set(value);
        }),
    );
  }

  stop(): void {
    this.subscriptions.unsubscribe();
    this.running.set(false);
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private reset(): void {
    this.sequence = 0;
    this.produced.set(0);
    this.sampledCount.set(0);
    this.auditedCount.set(0);
    this.conflatedCount.set(0);
    this.latestSampled.set(null);
    this.latestAudited.set(null);
    this.latestConflated.set(null);
  }

}
