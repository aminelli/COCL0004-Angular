import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedTechniquesDemo } from './advanced-techniques-demo';

describe('AdvancedTechniquesDemo', () => {
  let component: AdvancedTechniquesDemo;
  let fixture: ComponentFixture<AdvancedTechniquesDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdvancedTechniquesDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvancedTechniquesDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
