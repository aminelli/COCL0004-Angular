import { Component, OnDestroy, signal } from '@angular/core';
import { filter, interval, map, scan, Subscription, tap } from 'rxjs';

type BucketState = {
  tokens: number;
  lastRefillTs: number;
  allowed: boolean;
  value: number;
};

@Component({
  selector: 'app-rate-limiting-demo',
  imports: [],
  templateUrl: './rate-limiting-demo.html',
  styleUrl: './rate-limiting-demo.scss',
})
export class RateLimitingDemo implements OnDestroy {
  readonly running = signal(false);
  readonly maxTokens = signal(5);
  readonly refillPerSecond = signal(5);
  readonly produced = signal(0);
  readonly allowed = signal(0);
  readonly dropped = signal(0);
  readonly latestAllowedId = signal<number | null>(null);

  private sequence = 0;
  private streamSubscription?: Subscription;

  // Applica un rate limit con Token Bucket: i token si ricaricano nel tempo,
  // ogni richiesta consuma un token; senza token la richiesta viene scartata.
  start(): void {
    this.stop();
    this.resetStats();
    this.running.set(true);

    this.streamSubscription = interval(120)
      .pipe(
        map(() => ++this.sequence),
        tap(() => this.produced.update((count) => count + 1)),
        scan<number, BucketState>(
          (state, value) => {
            const now = Date.now();
            const elapsedMs = Math.max(0, now - state.lastRefillTs);
            const tokensToAdd = (elapsedMs / 1000) * this.refillPerSecond();
            const replenished = Math.min(this.maxTokens(), state.tokens + tokensToAdd);

            if (replenished >= 1) {
              return {
                tokens: replenished - 1,
                lastRefillTs: now,
                allowed: true,
                value,
              };
            }

            return {
              tokens: replenished,
              lastRefillTs: now,
              allowed: false,
              value,
            };
          },
          {
            tokens: this.maxTokens(),
            lastRefillTs: Date.now(),
            allowed: false,
            value: 0,
          },
        ),
        tap((state) => {
          if (state.allowed) {
            this.allowed.update((count) => count + 1);
            this.latestAllowedId.set(state.value);
          } else {
            this.dropped.update((count) => count + 1);
          }
        }),
        filter((state) => state.allowed),
      )
      .subscribe();
  }

  stop(): void {
    this.streamSubscription?.unsubscribe();
    this.streamSubscription = undefined;
    this.running.set(false);
  }

  setMaxTokens(value: number): void {
    this.maxTokens.set(Math.max(1, Math.min(20, value || 5)));
  }

  setRefillPerSecond(value: number): void {
    this.refillPerSecond.set(Math.max(1, Math.min(20, value || 5)));
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private resetStats(): void {
    this.sequence = 0;
    this.produced.set(0);
    this.allowed.set(0);
    this.dropped.set(0);
    this.latestAllowedId.set(null);
  }

}
