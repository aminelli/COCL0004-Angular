import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RateLimitingDemo } from './rate-limiting-demo';

describe('RateLimitingDemo', () => {
  let component: RateLimitingDemo;
  let fixture: ComponentFixture<RateLimitingDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RateLimitingDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RateLimitingDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
