import { Component, OnDestroy, signal } from '@angular/core';
import { filter, interval, map, Subscription, tap, bufferTime } from 'rxjs';

@Component({
  selector: 'app-buffering-demo',
  imports: [],
  templateUrl: './buffering-demo.html',
  styleUrl: './buffering-demo.scss',
})
export class BufferingDemo implements OnDestroy {
  readonly running = signal(false);
  readonly produced = signal(0);
  readonly processed = signal(0);
  readonly batches = signal(0);
  readonly bufferMs = signal(1000);
  readonly recentBatches = signal<string[]>([]);

  private sequence = 0;
  private streamSubscription?: Subscription;

  // Avvia una sorgente rapida e la trasforma in batch temporali per ridurre
  // il costo di elaborazione evento-per-evento.
  start(): void {
    this.stop();
    this.resetStats();
    this.running.set(true);

    this.streamSubscription = interval(80)
      .pipe(
        map(() => ++this.sequence),
        tap(() => this.produced.update((value) => value + 1)),
        bufferTime(this.bufferMs()),
        filter((batch) => batch.length > 0),
      )
      .subscribe((batch) => {
        this.batches.update((value) => value + 1);
        this.processed.update((value) => value + batch.length);

        const preview = `Batch #${this.batches()} -> ${batch.length} eventi (da ${batch[0]} a ${batch[batch.length - 1]})`;
        this.recentBatches.update((items) => [preview, ...items].slice(0, 6));
      });
  }

  // Interrompe il flusso per liberare risorse quando la demo non serve più.
  stop(): void {
    this.streamSubscription?.unsubscribe();
    this.streamSubscription = undefined;
    this.running.set(false);
  }

  // Cambia la finestra di buffering: maggiore è il valore, minore è il numero
  // di emissioni verso valle ma aumenta la latenza percepita.
  setBufferMs(value: number): void {
    const sanitized = Math.max(100, Math.min(5000, value || 1000));
    this.bufferMs.set(sanitized);
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private resetStats(): void {
    this.sequence = 0;
    this.produced.set(0);
    this.processed.set(0);
    this.batches.set(0);
    this.recentBatches.set([]);
  }

}
