import { Component } from '@angular/core';
import { BufferingDemo } from '../buffering-demo/buffering-demo';
import { ThrottlingDemo } from '../throttling-demo/throttling-demo';
import { DebouncingDemo } from '../debouncing-demo/debouncing-demo';
import { RateLimitingDemo } from '../rate-limiting-demo/rate-limiting-demo';
import { WindowingDemo } from '../windowing-demo/windowing-demo';
import { DropStrategiesDemo } from '../drop-strategies-demo/drop-strategies-demo';
import { PausingResumingDemo } from '../pausing-resuming-demo/pausing-resuming-demo';
import { ReactiveStreamsDemo } from '../reactive-streams-demo/reactive-streams-demo';
import { AdvancedTechniquesDemo } from '../advanced-techniques-demo/advanced-techniques-demo';

@Component({
  selector: 'app-backpressure-playground',
  imports: [
    BufferingDemo,
    ThrottlingDemo,
    DebouncingDemo,
    RateLimitingDemo,
    WindowingDemo,
    DropStrategiesDemo,
    PausingResumingDemo,
    ReactiveStreamsDemo,
    AdvancedTechniquesDemo,
  ],
  templateUrl: './backpressure-playground.html',
  styleUrl: './backpressure-playground.scss',
})
export class BackpressurePlayground {
  // Elenco sintetico dei concetti base mostrati all'inizio della pagina.
  readonly coreConcepts = [
    'Buffering: accumula eventi in batch per ridurre overhead.',
    'Throttling: limita frequenza massima di emissione verso valle.',
    'Debouncing: emette solo dopo una pausa di quiete.',
    'Rate limiting: applica un budget di richieste al secondo.',
  ];
}
