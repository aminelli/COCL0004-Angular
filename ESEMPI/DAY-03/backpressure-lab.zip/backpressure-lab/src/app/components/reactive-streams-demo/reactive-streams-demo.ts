import { Component, OnDestroy, signal } from '@angular/core';
import {
  concatMap,
  defer,
  exhaustMap,
  interval,
  map,
  mergeMap,
  Observable,
  Subscription,
  switchMap,
  tap,
  timer,
  finalize,
} from 'rxjs';

type StreamMode = 'concatMap' | 'switchMap' | 'exhaustMap' | 'mergeMap2';

@Component({
  selector: 'app-reactive-streams-demo',
  imports: [],
  templateUrl: './reactive-streams-demo.html',
  styleUrl: './reactive-streams-demo.scss',
})
export class ReactiveStreamsDemo implements OnDestroy {
  readonly mode = signal<StreamMode>('concatMap');
  readonly running = signal(false);
  readonly incoming = signal(0);
  readonly completed = signal(0);
  readonly dropped = signal(0);
  readonly active = signal(0);
  readonly latestCompletedId = signal<number | null>(null);

  private sequence = 0;
  private streamSubscription?: Subscription;

  // Mostra come i diversi flattening operator di RxJS implementano politiche
  // di backpressure differenti quando l'elaborazione è più lenta dell'input.
  start(): void {
    this.stop();
    this.reset();
    this.running.set(true);

    let seenWhileBusy = 0;

    const source$ = interval(250).pipe(
      map(() => ++this.sequence),
      tap(() => this.incoming.update((count) => count + 1)),
      tap(() => {
        if (this.active() > 0) {
          seenWhileBusy += 1;
        }
      }),
    );

    const handler = (id: number) => this.simulatedRequest$(id);

    const pipeline$ = (() => {
      switch (this.mode()) {
        case 'switchMap':
          return source$.pipe(
            tap(() => {
              if (this.active() > 0) {
                this.dropped.update((count) => count + 1);
              }
            }),
            switchMap(handler),
          );
        case 'exhaustMap':
          return source$.pipe(
            tap(() => {
              if (this.active() > 0) {
                this.dropped.update((count) => count + 1);
              }
            }),
            exhaustMap(handler),
          );
        case 'mergeMap2':
          return source$.pipe(mergeMap(handler, 2));
        case 'concatMap':
        default:
          return source$.pipe(concatMap(handler));
      }
    })();

    this.streamSubscription = pipeline$.subscribe((id) => {
      this.completed.update((count) => count + 1);
      this.latestCompletedId.set(id);

      if (this.mode() === 'mergeMap2' || this.mode() === 'concatMap') {
        this.dropped.set(0);
      } else if (seenWhileBusy > 0) {
        seenWhileBusy = 0;
      }
    });
  }

  stop(): void {
    this.streamSubscription?.unsubscribe();
    this.streamSubscription = undefined;
    this.running.set(false);
  }

  setMode(value: string): void {
    if (value === 'concatMap' || value === 'switchMap' || value === 'exhaustMap' || value === 'mergeMap2') {
      this.mode.set(value);
    }
  }

  ngOnDestroy(): void {
    this.stop();
  }

  private simulatedRequest$(id: number): Observable<number> {
    return defer(() => {
      this.active.update((count) => count + 1);
      return timer(900).pipe(
        map(() => id),
        finalize(() => this.active.update((count) => Math.max(0, count - 1))),
      );
    });
  }

  private reset(): void {
    this.sequence = 0;
    this.incoming.set(0);
    this.completed.set(0);
    this.dropped.set(0);
    this.active.set(0);
    this.latestCompletedId.set(null);
  }

}
