import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveStreamsDemo } from './reactive-streams-demo';

describe('ReactiveStreamsDemo', () => {
  let component: ReactiveStreamsDemo;
  let fixture: ComponentFixture<ReactiveStreamsDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveStreamsDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReactiveStreamsDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
