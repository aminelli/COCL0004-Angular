import { Component, OnDestroy, signal } from '@angular/core';
import { debounceTime, distinctUntilChanged, map, Subject, Subscription, tap } from 'rxjs';

@Component({
  selector: 'app-debouncing-demo',
  imports: [],
  templateUrl: './debouncing-demo.html',
  styleUrl: './debouncing-demo.scss',
})
export class DebouncingDemo implements OnDestroy {
  readonly debounceMs = signal(450);
  readonly rawEvents = signal(0);
  readonly emittedEvents = signal(0);
  readonly latestQuery = signal('');
  readonly running = signal(true);

  private readonly inputSubject = new Subject<string>();
  private inputSubscription?: Subscription;

  constructor() {
    this.configurePipeline();
  }

  // Registra ogni battitura: le emissioni reali saranno ritardate finché
  // l'utente non smette di digitare per il tempo di debounce configurato.
  onType(value: string): void {
    this.rawEvents.update((count) => count + 1);
    this.inputSubject.next(value);
  }

  setDebounceMs(value: number): void {
    const sanitized = Math.max(100, Math.min(2000, value || 450));
    this.debounceMs.set(sanitized);
    this.configurePipeline();
  }

  clear(): void {
    this.rawEvents.set(0);
    this.emittedEvents.set(0);
    this.latestQuery.set('');
  }

  ngOnDestroy(): void {
    this.inputSubscription?.unsubscribe();
    this.inputSubject.complete();
  }

  private configurePipeline(): void {
    this.inputSubscription?.unsubscribe();
    this.running.set(true);

    this.inputSubscription = this.inputSubject
      .pipe(
        map((value) => value.trim()),
        debounceTime(this.debounceMs()),
        distinctUntilChanged(),
        tap((query) => {
          this.emittedEvents.update((count) => count + 1);
          this.latestQuery.set(query);
        }),
      )
      .subscribe();
  }

}
