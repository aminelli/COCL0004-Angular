import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DebouncingDemo } from './debouncing-demo';

describe('DebouncingDemo', () => {
  let component: DebouncingDemo;
  let fixture: ComponentFixture<DebouncingDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DebouncingDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DebouncingDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
