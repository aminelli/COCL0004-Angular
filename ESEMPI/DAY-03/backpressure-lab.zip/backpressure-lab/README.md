# BackpressureLab

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 21.1.4.

## Guida rapida alle demo Backpressure

Apri l'app su `http://localhost:4200/` e scorri le sezioni in ordine:

1. **Buffering**
	- Aumenta/diminuisci `Finestra buffer (ms)`.
	- Osserva come cambiano numero di batch, latenza e costo di elaborazione.

2. **Throttling**
	- Modifica `Intervallo throttle (ms)`.
	- Verifica il rapporto tra eventi prodotti, inoltrati e scartati.

3. **Debouncing**
	- Digita velocemente nel campo testo.
	- Misura la riduzione delle emissioni utili rispetto agli input grezzi.

4. **Rate Limiting (Token Bucket)**
	- Regola `Capacità bucket` e `Refill al secondo`.
	- Simula policy API-safe per controllare throughput medio e burst.

5. **Windowing / Chunking**
	- Cambia `Dimensione chunk`.
	- Valuta la differenza tra elaborazione evento-per-evento e in blocchi.

6. **Drop Strategies**
	- Prova `Drop Newest`, `Drop Oldest`, `Drop Random`, `Fail fast`.
	- Confronta qualità del dato e stabilità sotto pressione.

7. **Pausing / Resuming (Push–Pull)**
	- Avvia, metti in pausa il consumer, poi riprendi.
	- Osserva accumulo buffer e recupero graduale del backlog.

8. **RxJS / Reactive Streams**
	- Confronta `concatMap`, `switchMap`, `exhaustMap`, `mergeMap(2)`.
	- Ogni operatore implementa una policy di backpressure diversa.

9. **Tecniche extra**
	- `sampleTime`, `auditTime`, conflation (ultimo valore batch).
	- Utili per stream telemetrici/IoT e dashboard real-time.

### Suggerimento didattico

Per capire bene i trade-off, cambia **un solo parametro alla volta** e annota:
- throughput (eventi processati),
- latenza percepita,
- perdita dati (drop),
- stabilità del buffer.

## Development server

To start a local development server, run:

```bash
ng serve
```

Once the server is running, open your browser and navigate to `http://localhost:4200/`. The application will automatically reload whenever you modify any of the source files.

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the project run:

```bash
ng build
```

This will compile your project and store the build artifacts in the `dist/` directory. By default, the production build optimizes your application for performance and speed.

## Running unit tests

To execute unit tests with the [Vitest](https://vitest.dev/) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
