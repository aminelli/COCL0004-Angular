import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutocompleteDemo } from './autocomplete-demo';

describe('AutocompleteDemo', () => {
  let component: AutocompleteDemo;
  let fixture: ComponentFixture<AutocompleteDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AutocompleteDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AutocompleteDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
