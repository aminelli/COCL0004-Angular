import { Component } from '@angular/core';
import {
  AccordionGroup,
  AccordionTrigger,
  AccordionPanel,
  AccordionContent,
} from '@angular/aria/accordion';


@Component({
  selector: 'app-accordion-single-demo',
  imports: [AccordionGroup, AccordionTrigger, AccordionPanel, AccordionContent],
  templateUrl: './accordion-single-demo.html',
  styleUrl: './accordion-single-demo.css'
})
export class AccordionSingleDemo {

}
