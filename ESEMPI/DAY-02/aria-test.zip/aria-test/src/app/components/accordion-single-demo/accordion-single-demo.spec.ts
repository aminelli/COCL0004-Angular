import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccordionSingleDemo } from './accordion-single-demo';

describe('AccordionSingleDemo', () => {
  let component: AccordionSingleDemo;
  let fixture: ComponentFixture<AccordionSingleDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AccordionSingleDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccordionSingleDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
