import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AccordionSingleDemo } from './components/accordion-single-demo/accordion-single-demo';
import { AutocompleteDemo } from './components/autocomplete-demo/autocomplete-demo';

@Component({
  selector: 'app-root',
  imports: [AccordionSingleDemo, AutocompleteDemo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('aria-test');
}
