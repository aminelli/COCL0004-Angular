import {
  ListFocus,
  ListNavigation
} from "./chunk-QKKY6CTE.js";
import {
  Combobox,
  ComboboxDialog,
  ComboboxInput,
  ComboboxPopup,
  ComboboxPopupContainer
} from "./chunk-QATKE2KZ.js";
import {
  KeyboardEventManager,
  Modifier,
  PointerEventManager,
  computed as computed2,
  signal as signal2
} from "./chunk-WGVT42ER.js";
import {
  _IdGenerator
} from "./chunk-XWJ447ND.js";
import {
  Directionality
} from "./chunk-JQ4H3PS3.js";
import "./chunk-DPB7LQAW.js";
import "./chunk-56N2IXW4.js";
import {
  ContentChildren,
  Directive,
  ElementRef,
  InjectionToken,
  Input,
  Output,
  __spreadProps,
  __spreadValues,
  afterRenderEffect,
  booleanAttribute,
  computed,
  contentChildren,
  forwardRef,
  inject,
  input,
  model,
  setClassMetadata,
  signal,
  untracked,
  ɵɵHostDirectivesFeature,
  ɵɵProvidersFeature,
  ɵɵattribute,
  ɵɵcontentQuerySignal,
  ɵɵdefineDirective,
  ɵɵlistener,
  ɵɵqueryAdvance
} from "./chunk-XVCATVL7.js";

// node_modules/@angular/aria/fesm2022/_list-typeahead-chunk.mjs
var ListSelection = class {
  inputs;
  rangeStartIndex = signal2(0);
  rangeEndIndex = signal2(0);
  selectedItems = computed2(() => this.inputs.items().filter((item) => this.inputs.values().includes(item.value())));
  constructor(inputs) {
    this.inputs = inputs;
  }
  select(item, opts = {
    anchor: true
  }) {
    item = item ?? this.inputs.focusManager.inputs.activeItem();
    if (!item || item.disabled() || !item.selectable() || !this.inputs.focusManager.isFocusable(item) || this.inputs.values().includes(item.value())) {
      return;
    }
    if (!this.inputs.multi()) {
      this.deselectAll();
    }
    const index = this.inputs.items().findIndex((i) => i === item);
    if (opts.anchor) {
      this.beginRangeSelection(index);
    }
    this.inputs.values.update((values) => values.concat(item.value()));
  }
  deselect(item) {
    item = item ?? this.inputs.focusManager.inputs.activeItem();
    if (item && !item.disabled() && item.selectable()) {
      this.inputs.values.update((values) => values.filter((value) => value !== item.value()));
    }
  }
  toggle(item) {
    item = item ?? this.inputs.focusManager.inputs.activeItem();
    if (item) {
      this.inputs.values().includes(item.value()) ? this.deselect(item) : this.select(item);
    }
  }
  toggleOne() {
    const item = this.inputs.focusManager.inputs.activeItem();
    if (item) {
      this.inputs.values().includes(item.value()) ? this.deselect() : this.selectOne();
    }
  }
  selectAll() {
    if (!this.inputs.multi()) {
      return;
    }
    for (const item of this.inputs.items()) {
      this.select(item, {
        anchor: false
      });
    }
    this.beginRangeSelection();
  }
  deselectAll() {
    for (const value of this.inputs.values()) {
      const item = this.inputs.items().find((i) => i.value() === value);
      item ? this.deselect(item) : this.inputs.values.update((values) => values.filter((v) => v !== value));
    }
  }
  toggleAll() {
    const selectableValues = this.inputs.items().filter((i) => !i.disabled() && i.selectable() && this.inputs.focusManager.isFocusable(i)).map((i) => i.value());
    selectableValues.every((i) => this.inputs.values().includes(i)) ? this.deselectAll() : this.selectAll();
  }
  selectOne() {
    const item = this.inputs.focusManager.inputs.activeItem();
    if (item && (item.disabled() || !item.selectable())) {
      return;
    }
    this.deselectAll();
    if (this.inputs.values().length > 0 && !this.inputs.multi()) {
      return;
    }
    this.select();
  }
  selectRange(opts = {
    anchor: true
  }) {
    const isStartOfRange = this.inputs.focusManager.prevActiveIndex() === this.rangeStartIndex();
    if (isStartOfRange && opts.anchor) {
      this.beginRangeSelection(this.inputs.focusManager.prevActiveIndex());
    }
    const itemsInRange = this._getItemsFromIndex(this.rangeStartIndex());
    const itemsOutOfRange = this._getItemsFromIndex(this.rangeEndIndex()).filter((i) => !itemsInRange.includes(i));
    for (const item of itemsOutOfRange) {
      this.deselect(item);
    }
    for (const item of itemsInRange) {
      this.select(item, {
        anchor: false
      });
    }
    if (itemsInRange.length) {
      const item = itemsInRange.pop();
      const index = this.inputs.items().findIndex((i) => i === item);
      this.rangeEndIndex.set(index);
    }
  }
  beginRangeSelection(index = this.inputs.focusManager.activeIndex()) {
    this.rangeStartIndex.set(index);
    this.rangeEndIndex.set(index);
  }
  _getItemsFromIndex(index) {
    if (index === -1) {
      return [];
    }
    const upper = Math.max(this.inputs.focusManager.activeIndex(), index);
    const lower = Math.min(this.inputs.focusManager.activeIndex(), index);
    const items = [];
    for (let i = lower; i <= upper; i++) {
      items.push(this.inputs.items()[i]);
    }
    if (this.inputs.focusManager.activeIndex() < index) {
      return items.reverse();
    }
    return items;
  }
};
var ListTypeahead = class {
  inputs;
  timeout;
  focusManager;
  isTyping = computed2(() => this._query().length > 0);
  _query = signal2("");
  _startIndex = signal2(void 0);
  constructor(inputs) {
    this.inputs = inputs;
    this.focusManager = inputs.focusManager;
  }
  search(char) {
    if (char.length !== 1) {
      return false;
    }
    if (!this.isTyping() && char === " ") {
      return false;
    }
    if (this._startIndex() === void 0) {
      this._startIndex.set(this.focusManager.activeIndex());
    }
    clearTimeout(this.timeout);
    this._query.update((q) => q + char.toLowerCase());
    const item = this._getItem();
    if (item) {
      this.focusManager.focus(item);
    }
    this.timeout = setTimeout(() => {
      this._query.set("");
      this._startIndex.set(void 0);
    }, this.inputs.typeaheadDelay());
    return true;
  }
  _getItem() {
    const items = this.focusManager.inputs.items();
    const itemCount = items.length;
    const startIndex = this._startIndex();
    for (let i = 0; i < itemCount; i++) {
      const index = (startIndex + 1 + i) % itemCount;
      const item = items[index];
      if (this.focusManager.isFocusable(item) && item.searchTerm().toLowerCase().startsWith(this._query())) {
        return item;
      }
    }
    return void 0;
  }
};

// node_modules/@angular/aria/fesm2022/_list-chunk.mjs
var List = class {
  inputs;
  navigationBehavior;
  selectionBehavior;
  typeaheadBehavior;
  focusBehavior;
  disabled = computed2(() => this.focusBehavior.isListDisabled());
  activeDescendant = computed2(() => this.focusBehavior.getActiveDescendant());
  tabIndex = computed2(() => this.focusBehavior.getListTabIndex());
  activeIndex = computed2(() => this.focusBehavior.activeIndex());
  _anchorIndex = signal2(0);
  _wrap = signal2(true);
  constructor(inputs) {
    this.inputs = inputs;
    this.focusBehavior = new ListFocus(inputs);
    this.selectionBehavior = new ListSelection(__spreadProps(__spreadValues({}, inputs), {
      focusManager: this.focusBehavior
    }));
    this.typeaheadBehavior = new ListTypeahead(__spreadProps(__spreadValues({}, inputs), {
      focusManager: this.focusBehavior
    }));
    this.navigationBehavior = new ListNavigation(__spreadProps(__spreadValues({}, inputs), {
      focusManager: this.focusBehavior,
      wrap: computed2(() => this._wrap() && this.inputs.wrap())
    }));
  }
  getItemTabindex(item) {
    return this.focusBehavior.getItemTabIndex(item);
  }
  first(opts) {
    this._navigate(opts, () => this.navigationBehavior.first(opts));
  }
  last(opts) {
    this._navigate(opts, () => this.navigationBehavior.last(opts));
  }
  next(opts) {
    this._navigate(opts, () => this.navigationBehavior.next(opts));
  }
  prev(opts) {
    this._navigate(opts, () => this.navigationBehavior.prev(opts));
  }
  goto(item, opts) {
    this._navigate(opts, () => this.navigationBehavior.goto(item, opts));
  }
  unfocus() {
    this.inputs.activeItem.set(void 0);
  }
  anchor(index) {
    this._anchorIndex.set(index);
  }
  search(char, opts) {
    this._navigate(opts, () => this.typeaheadBehavior.search(char));
  }
  isTyping() {
    return this.typeaheadBehavior.isTyping();
  }
  select(item) {
    this.selectionBehavior.select(item);
  }
  selectOne() {
    this.selectionBehavior.selectOne();
  }
  deselect(item) {
    this.selectionBehavior.deselect(item);
  }
  deselectAll() {
    this.selectionBehavior.deselectAll();
  }
  toggle(item) {
    this.selectionBehavior.toggle(item);
  }
  toggleOne() {
    this.selectionBehavior.toggleOne();
  }
  toggleAll() {
    this.selectionBehavior.toggleAll();
  }
  isFocusable(item) {
    return this.focusBehavior.isFocusable(item);
  }
  updateSelection(opts = {
    anchor: true
  }) {
    if (opts.toggle) {
      this.selectionBehavior.toggle();
    }
    if (opts.select) {
      this.selectionBehavior.select();
    }
    if (opts.selectOne) {
      this.selectionBehavior.selectOne();
    }
    if (opts.selectRange) {
      this.selectionBehavior.selectRange();
    }
    if (!opts.anchor) {
      this.anchor(this.selectionBehavior.rangeStartIndex());
    }
  }
  _navigate(opts = {}, operation) {
    if (opts?.selectRange) {
      this._wrap.set(false);
      this.selectionBehavior.rangeStartIndex.set(this._anchorIndex());
    }
    const moved = operation();
    if (moved) {
      this.updateSelection(opts);
    }
    this._wrap.set(true);
  }
};

// node_modules/@angular/aria/fesm2022/_combobox-listbox-chunk.mjs
var ListboxPattern = class {
  inputs;
  listBehavior;
  orientation;
  disabled = computed2(() => this.listBehavior.disabled());
  readonly;
  tabIndex = computed2(() => this.listBehavior.tabIndex());
  activeDescendant = computed2(() => this.listBehavior.activeDescendant());
  multi;
  setsize = computed2(() => this.inputs.items().length);
  followFocus = computed2(() => this.inputs.selectionMode() === "follow");
  wrap = signal2(true);
  prevKey = computed2(() => {
    if (this.inputs.orientation() === "vertical") {
      return "ArrowUp";
    }
    return this.inputs.textDirection() === "rtl" ? "ArrowRight" : "ArrowLeft";
  });
  nextKey = computed2(() => {
    if (this.inputs.orientation() === "vertical") {
      return "ArrowDown";
    }
    return this.inputs.textDirection() === "rtl" ? "ArrowLeft" : "ArrowRight";
  });
  dynamicSpaceKey = computed2(() => this.listBehavior.isTyping() ? "" : " ");
  typeaheadRegexp = /^.$/;
  keydown = computed2(() => {
    const manager = new KeyboardEventManager();
    if (this.readonly()) {
      return manager.on(this.prevKey, () => this.listBehavior.prev(), {
        ignoreRepeat: false
      }).on(this.nextKey, () => this.listBehavior.next(), {
        ignoreRepeat: false
      }).on("Home", () => this.listBehavior.first()).on("End", () => this.listBehavior.last()).on(this.typeaheadRegexp, (e) => this.listBehavior.search(e.key));
    }
    if (!this.followFocus()) {
      manager.on(this.prevKey, () => this.listBehavior.prev(), {
        ignoreRepeat: false
      }).on(this.nextKey, () => this.listBehavior.next(), {
        ignoreRepeat: false
      }).on("Home", () => this.listBehavior.first()).on("End", () => this.listBehavior.last()).on(this.typeaheadRegexp, (e) => this.listBehavior.search(e.key));
    }
    if (this.followFocus()) {
      manager.on(this.prevKey, () => this.listBehavior.prev({
        selectOne: true
      }), {
        ignoreRepeat: false
      }).on(this.nextKey, () => this.listBehavior.next({
        selectOne: true
      }), {
        ignoreRepeat: false
      }).on("Home", () => this.listBehavior.first({
        selectOne: true
      })).on("End", () => this.listBehavior.last({
        selectOne: true
      })).on(this.typeaheadRegexp, (e) => this.listBehavior.search(e.key, {
        selectOne: true
      }));
    }
    if (this.inputs.multi()) {
      manager.on(Modifier.Any, "Shift", () => this.listBehavior.anchor(this.listBehavior.activeIndex())).on(Modifier.Shift, this.prevKey, () => this.listBehavior.prev({
        selectRange: true
      }), {
        ignoreRepeat: false
      }).on(Modifier.Shift, this.nextKey, () => this.listBehavior.next({
        selectRange: true
      }), {
        ignoreRepeat: false
      }).on([Modifier.Ctrl | Modifier.Shift, Modifier.Meta | Modifier.Shift], "Home", () => this.listBehavior.first({
        selectRange: true,
        anchor: false
      })).on([Modifier.Ctrl | Modifier.Shift, Modifier.Meta | Modifier.Shift], "End", () => this.listBehavior.last({
        selectRange: true,
        anchor: false
      })).on(Modifier.Shift, "Enter", () => this.listBehavior.updateSelection({
        selectRange: true,
        anchor: false
      })).on(Modifier.Shift, this.dynamicSpaceKey, () => this.listBehavior.updateSelection({
        selectRange: true,
        anchor: false
      }));
    }
    if (!this.followFocus() && this.inputs.multi()) {
      manager.on(this.dynamicSpaceKey, () => this.listBehavior.toggle()).on("Enter", () => this.listBehavior.toggle()).on([Modifier.Ctrl, Modifier.Meta], "A", () => this.listBehavior.toggleAll());
    }
    if (!this.followFocus() && !this.inputs.multi()) {
      manager.on(this.dynamicSpaceKey, () => this.listBehavior.toggleOne());
      manager.on("Enter", () => this.listBehavior.toggleOne());
    }
    if (this.inputs.multi() && this.followFocus()) {
      manager.on([Modifier.Ctrl, Modifier.Meta], this.prevKey, () => this.listBehavior.prev(), {
        ignoreRepeat: false
      }).on([Modifier.Ctrl, Modifier.Meta], this.nextKey, () => this.listBehavior.next(), {
        ignoreRepeat: false
      }).on([Modifier.Ctrl, Modifier.Meta], " ", () => this.listBehavior.toggle()).on([Modifier.Ctrl, Modifier.Meta], "Enter", () => this.listBehavior.toggle()).on([Modifier.Ctrl, Modifier.Meta], "Home", () => this.listBehavior.first()).on([Modifier.Ctrl, Modifier.Meta], "End", () => this.listBehavior.last()).on([Modifier.Ctrl, Modifier.Meta], "A", () => {
        this.listBehavior.toggleAll();
        this.listBehavior.select();
      });
    }
    return manager;
  });
  pointerdown = computed2(() => {
    const manager = new PointerEventManager();
    if (this.readonly()) {
      return manager.on((e) => this.listBehavior.goto(this._getItem(e)));
    }
    if (this.multi()) {
      manager.on(Modifier.Shift, (e) => this.listBehavior.goto(this._getItem(e), {
        selectRange: true
      }));
    }
    if (!this.multi() && this.followFocus()) {
      return manager.on((e) => this.listBehavior.goto(this._getItem(e), {
        selectOne: true
      }));
    }
    if (!this.multi() && !this.followFocus()) {
      return manager.on((e) => this.listBehavior.goto(this._getItem(e), {
        toggle: true
      }));
    }
    if (this.multi() && this.followFocus()) {
      return manager.on((e) => this.listBehavior.goto(this._getItem(e), {
        selectOne: true
      })).on(Modifier.Ctrl, (e) => this.listBehavior.goto(this._getItem(e), {
        toggle: true
      }));
    }
    if (this.multi() && !this.followFocus()) {
      return manager.on((e) => this.listBehavior.goto(this._getItem(e), {
        toggle: true
      }));
    }
    return manager;
  });
  constructor(inputs) {
    this.inputs = inputs;
    this.readonly = inputs.readonly;
    this.orientation = inputs.orientation;
    this.multi = inputs.multi;
    this.listBehavior = new List(inputs);
  }
  validate() {
    const violations = [];
    if (!this.inputs.multi() && this.inputs.values().length > 1) {
      violations.push(`A single-select listbox should not have multiple selected options. Selected options: ${this.inputs.values().join(", ")}`);
    }
    return violations;
  }
  onKeydown(event) {
    if (!this.disabled()) {
      this.keydown().handle(event);
    }
  }
  onPointerdown(event) {
    if (!this.disabled()) {
      this.pointerdown().handle(event);
    }
  }
  setDefaultState() {
    let firstItem = null;
    for (const item of this.inputs.items()) {
      if (this.listBehavior.isFocusable(item)) {
        if (!firstItem) {
          firstItem = item;
        }
        if (item.selected()) {
          this.inputs.activeItem.set(item);
          return;
        }
      }
    }
    if (firstItem) {
      this.inputs.activeItem.set(firstItem);
    }
  }
  _getItem(e) {
    if (!(e.target instanceof HTMLElement)) {
      return;
    }
    const element = e.target.closest('[role="option"]');
    return this.inputs.items().find((i) => i.element() === element);
  }
};
var OptionPattern = class {
  id;
  value;
  index = computed2(() => this.listbox()?.inputs.items().indexOf(this) ?? -1);
  active = computed2(() => this.listbox()?.inputs.activeItem() === this);
  selected = computed2(() => this.listbox()?.inputs.values().includes(this.value()));
  selectable = () => true;
  disabled;
  searchTerm;
  listbox;
  tabIndex = computed2(() => this.listbox()?.listBehavior.getItemTabindex(this));
  element;
  constructor(args) {
    this.id = args.id;
    this.value = args.value;
    this.listbox = args.listbox;
    this.element = args.element;
    this.disabled = args.disabled;
    this.searchTerm = args.searchTerm;
  }
};
var ComboboxListboxPattern = class extends ListboxPattern {
  inputs;
  id = computed2(() => this.inputs.id());
  role = computed2(() => "listbox");
  activeId = computed2(() => this.listBehavior.activeDescendant());
  items = computed2(() => this.inputs.items());
  tabIndex = () => -1;
  multi = computed2(() => {
    return this.inputs.combobox()?.readonly() ? this.inputs.multi() : false;
  });
  constructor(inputs) {
    if (inputs.combobox()) {
      inputs.focusMode = () => "activedescendant";
      inputs.element = inputs.combobox().inputs.inputEl;
    }
    super(inputs);
    this.inputs = inputs;
  }
  onKeydown(_) {
  }
  onPointerdown(_) {
  }
  setDefaultState() {
  }
  focus = (item, opts) => {
    this.listBehavior.goto(item, opts);
  };
  getActiveItem = () => this.inputs.activeItem();
  next = () => this.listBehavior.next();
  prev = () => this.listBehavior.prev();
  last = () => this.listBehavior.last();
  first = () => this.listBehavior.first();
  unfocus = () => this.listBehavior.unfocus();
  select = (item) => this.listBehavior.select(item);
  toggle = (item) => this.listBehavior.toggle(item);
  clearSelection = () => this.listBehavior.deselectAll();
  getItem = (e) => this._getItem(e);
  getSelectedItems = () => {
    const items = [];
    for (const value of this.inputs.values()) {
      const item = this.items().find((i) => i.value() === value);
      if (item) {
        items.push(item);
      }
    }
    return items;
  };
  setValue = (value) => this.inputs.values.set(value ? [value] : []);
};

// node_modules/@angular/aria/fesm2022/listbox.mjs
var LISTBOX = new InjectionToken("LISTBOX");
var Option = class _Option {
  element = inject(ElementRef).nativeElement;
  active = computed(() => this._pattern.active(), ...ngDevMode ? [{
    debugName: "active"
  }] : []);
  _listbox = inject(LISTBOX);
  id = input(inject(_IdGenerator).getId("ng-option-", true), ...ngDevMode ? [{
    debugName: "id"
  }] : []);
  searchTerm = computed(() => this.label() ?? this.element.textContent, ...ngDevMode ? [{
    debugName: "searchTerm"
  }] : []);
  _listboxPattern = computed(() => this._listbox._pattern, ...ngDevMode ? [{
    debugName: "_listboxPattern"
  }] : []);
  value = input.required(...ngDevMode ? [{
    debugName: "value"
  }] : []);
  disabled = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "disabled"
  } : {}), {
    transform: booleanAttribute
  }));
  label = input(...ngDevMode ? [void 0, {
    debugName: "label"
  }] : []);
  selected = computed(() => this._pattern.selected(), ...ngDevMode ? [{
    debugName: "selected"
  }] : []);
  _pattern = new OptionPattern(__spreadProps(__spreadValues({}, this), {
    id: this.id,
    value: this.value,
    listbox: this._listboxPattern,
    element: () => this.element,
    searchTerm: () => this.searchTerm() ?? ""
  }));
  static ɵfac = function Option_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Option)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _Option,
    selectors: [["", "ngOption", ""]],
    hostAttrs: ["role", "option"],
    hostVars: 5,
    hostBindings: function Option_HostBindings(rf, ctx) {
      if (rf & 2) {
        ɵɵattribute("data-active", ctx.active())("id", ctx._pattern.id())("tabindex", ctx._pattern.tabIndex())("aria-selected", ctx._pattern.selected())("aria-disabled", ctx._pattern.disabled());
      }
    },
    inputs: {
      id: [1, "id"],
      value: [1, "value"],
      disabled: [1, "disabled"],
      label: [1, "label"]
    },
    exportAs: ["ngOption"]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Option, [{
    type: Directive,
    args: [{
      selector: "[ngOption]",
      exportAs: "ngOption",
      host: {
        "role": "option",
        "[attr.data-active]": "active()",
        "[attr.id]": "_pattern.id()",
        "[attr.tabindex]": "_pattern.tabIndex()",
        "[attr.aria-selected]": "_pattern.selected()",
        "[attr.aria-disabled]": "_pattern.disabled()"
      }
    }]
  }], null, {
    id: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "id",
        required: false
      }]
    }],
    value: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "value",
        required: true
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    label: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "label",
        required: false
      }]
    }]
  });
})();
var Listbox = class _Listbox {
  id = input(inject(_IdGenerator).getId("ng-listbox-", true), ...ngDevMode ? [{
    debugName: "id"
  }] : []);
  _popup = inject(ComboboxPopup, {
    optional: true
  });
  _elementRef = inject(ElementRef);
  element = this._elementRef.nativeElement;
  _options = contentChildren(Option, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "_options"
  } : {}), {
    descendants: true
  }));
  textDirection = inject(Directionality).valueSignal.asReadonly();
  items = computed(() => this._options().map((option) => option._pattern), ...ngDevMode ? [{
    debugName: "items"
  }] : []);
  orientation = input("vertical", ...ngDevMode ? [{
    debugName: "orientation"
  }] : []);
  multi = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "multi"
  } : {}), {
    transform: booleanAttribute
  }));
  wrap = input(true, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "wrap"
  } : {}), {
    transform: booleanAttribute
  }));
  softDisabled = input(true, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "softDisabled"
  } : {}), {
    transform: booleanAttribute
  }));
  focusMode = input("roving", ...ngDevMode ? [{
    debugName: "focusMode"
  }] : []);
  selectionMode = input("follow", ...ngDevMode ? [{
    debugName: "selectionMode"
  }] : []);
  typeaheadDelay = input(500, ...ngDevMode ? [{
    debugName: "typeaheadDelay"
  }] : []);
  disabled = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "disabled"
  } : {}), {
    transform: booleanAttribute
  }));
  readonly = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "readonly"
  } : {}), {
    transform: booleanAttribute
  }));
  values = model([], ...ngDevMode ? [{
    debugName: "values"
  }] : []);
  _pattern;
  _hasFocused = signal(false, ...ngDevMode ? [{
    debugName: "_hasFocused"
  }] : []);
  constructor() {
    const inputs = __spreadProps(__spreadValues({}, this), {
      id: this.id,
      items: this.items,
      activeItem: signal(void 0),
      textDirection: this.textDirection,
      element: () => this._elementRef.nativeElement,
      combobox: () => this._popup?.combobox?._pattern
    });
    this._pattern = this._popup?.combobox ? new ComboboxListboxPattern(inputs) : new ListboxPattern(inputs);
    if (this._popup) {
      this._popup._controls.set(this._pattern);
    }
    afterRenderEffect(() => {
      if (typeof ngDevMode === "undefined" || ngDevMode) {
        const violations = this._pattern.validate();
        for (const violation of violations) {
          console.error(violation);
        }
      }
    });
    afterRenderEffect(() => {
      if (!this._hasFocused()) {
        this._pattern.setDefaultState();
      }
    });
    afterRenderEffect(() => {
      const items = inputs.items();
      const activeItem = untracked(() => inputs.activeItem());
      if (!items.some((i) => i === activeItem) && activeItem) {
        this._pattern.listBehavior.unfocus();
      }
    });
    afterRenderEffect(() => {
      const items = inputs.items();
      const values = untracked(() => this.values());
      if (items && values.some((v) => !items.some((i) => i.value() === v))) {
        this.values.set(values.filter((v) => items.some((i) => i.value() === v)));
      }
    });
  }
  _onFocus() {
    this._hasFocused.set(true);
  }
  scrollActiveItemIntoView(options = {
    block: "nearest"
  }) {
    this._pattern.inputs.activeItem()?.element()?.scrollIntoView(options);
  }
  gotoFirst() {
    this._pattern.listBehavior.first();
  }
  static ɵfac = function Listbox_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Listbox)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _Listbox,
    selectors: [["", "ngListbox", ""]],
    contentQueries: function Listbox_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuerySignal(dirIndex, ctx._options, Option, 5);
      }
      if (rf & 2) {
        ɵɵqueryAdvance();
      }
    },
    hostAttrs: ["role", "listbox"],
    hostVars: 7,
    hostBindings: function Listbox_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("keydown", function Listbox_keydown_HostBindingHandler($event) {
          return ctx._pattern.onKeydown($event);
        })("pointerdown", function Listbox_pointerdown_HostBindingHandler($event) {
          return ctx._pattern.onPointerdown($event);
        })("focusin", function Listbox_focusin_HostBindingHandler() {
          return ctx._onFocus();
        });
      }
      if (rf & 2) {
        ɵɵattribute("id", ctx.id())("tabindex", ctx._pattern.tabIndex())("aria-readonly", ctx._pattern.readonly())("aria-disabled", ctx._pattern.disabled())("aria-orientation", ctx._pattern.orientation())("aria-multiselectable", ctx._pattern.multi())("aria-activedescendant", ctx._pattern.activeDescendant());
      }
    },
    inputs: {
      id: [1, "id"],
      orientation: [1, "orientation"],
      multi: [1, "multi"],
      wrap: [1, "wrap"],
      softDisabled: [1, "softDisabled"],
      focusMode: [1, "focusMode"],
      selectionMode: [1, "selectionMode"],
      typeaheadDelay: [1, "typeaheadDelay"],
      disabled: [1, "disabled"],
      readonly: [1, "readonly"],
      values: [1, "values"]
    },
    outputs: {
      values: "valuesChange"
    },
    exportAs: ["ngListbox"],
    features: [ɵɵProvidersFeature([{
      provide: LISTBOX,
      useExisting: _Listbox
    }]), ɵɵHostDirectivesFeature([ComboboxPopup])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Listbox, [{
    type: Directive,
    args: [{
      selector: "[ngListbox]",
      exportAs: "ngListbox",
      host: {
        "role": "listbox",
        "[attr.id]": "id()",
        "[attr.tabindex]": "_pattern.tabIndex()",
        "[attr.aria-readonly]": "_pattern.readonly()",
        "[attr.aria-disabled]": "_pattern.disabled()",
        "[attr.aria-orientation]": "_pattern.orientation()",
        "[attr.aria-multiselectable]": "_pattern.multi()",
        "[attr.aria-activedescendant]": "_pattern.activeDescendant()",
        "(keydown)": "_pattern.onKeydown($event)",
        "(pointerdown)": "_pattern.onPointerdown($event)",
        "(focusin)": "_onFocus()"
      },
      hostDirectives: [ComboboxPopup],
      providers: [{
        provide: LISTBOX,
        useExisting: Listbox
      }]
    }]
  }], () => [], {
    id: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "id",
        required: false
      }]
    }],
    _options: [{
      type: ContentChildren,
      args: [forwardRef(() => Option), __spreadProps(__spreadValues({}, {
        descendants: true
      }), {
        isSignal: true
      })]
    }],
    orientation: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "orientation",
        required: false
      }]
    }],
    multi: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "multi",
        required: false
      }]
    }],
    wrap: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "wrap",
        required: false
      }]
    }],
    softDisabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "softDisabled",
        required: false
      }]
    }],
    focusMode: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "focusMode",
        required: false
      }]
    }],
    selectionMode: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "selectionMode",
        required: false
      }]
    }],
    typeaheadDelay: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "typeaheadDelay",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    readonly: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "readonly",
        required: false
      }]
    }],
    values: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "values",
        required: false
      }]
    }, {
      type: Output,
      args: ["valuesChange"]
    }]
  });
})();
export {
  Listbox,
  Option,
  Combobox as ɵɵCombobox,
  ComboboxDialog as ɵɵComboboxDialog,
  ComboboxInput as ɵɵComboboxInput,
  ComboboxPopup as ɵɵComboboxPopup,
  ComboboxPopupContainer as ɵɵComboboxPopupContainer
};
//# sourceMappingURL=@angular_aria_listbox.js.map
