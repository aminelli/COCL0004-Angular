import {
  ListFocus,
  ListNavigation
} from "./chunk-QKKY6CTE.js";
import {
  DeferredContent,
  DeferredContentAware,
  KeyboardEventManager,
  PointerEventManager,
  computed as computed2
} from "./chunk-WGVT42ER.js";
import {
  _IdGenerator
} from "./chunk-XWJ447ND.js";
import {
  Directionality
} from "./chunk-JQ4H3PS3.js";
import "./chunk-DPB7LQAW.js";
import "./chunk-56N2IXW4.js";
import {
  ContentChildren,
  Directive,
  ElementRef,
  InjectionToken,
  Input,
  Output,
  __spreadProps,
  __spreadValues,
  afterRenderEffect,
  booleanAttribute,
  computed,
  contentChildren,
  forwardRef,
  inject,
  input,
  model,
  setClassMetadata,
  signal,
  ɵɵHostDirectivesFeature,
  ɵɵProvidersFeature,
  ɵɵattribute,
  ɵɵcontentQuerySignal,
  ɵɵdefineDirective,
  ɵɵdomProperty,
  ɵɵlistener,
  ɵɵqueryAdvance
} from "./chunk-XVCATVL7.js";

// node_modules/@angular/aria/fesm2022/_expansion-chunk.mjs
var ListExpansion = class {
  inputs;
  constructor(inputs) {
    this.inputs = inputs;
  }
  open(item) {
    if (!this.isExpandable(item)) return false;
    if (item.expanded()) return false;
    if (!this.inputs.multiExpandable()) {
      this.closeAll();
    }
    item.expanded.set(true);
    return true;
  }
  close(item) {
    if (!this.isExpandable(item)) return false;
    item.expanded.set(false);
    return true;
  }
  toggle(item) {
    return item.expanded() ? this.close(item) : this.open(item);
  }
  openAll() {
    if (this.inputs.multiExpandable()) {
      for (const item of this.inputs.items()) {
        this.open(item);
      }
    }
  }
  closeAll() {
    for (const item of this.inputs.items()) {
      this.close(item);
    }
  }
  isExpandable(item) {
    return !this.inputs.disabled() && !item.disabled() && item.expandable();
  }
};

// node_modules/@angular/aria/fesm2022/_accordion-chunk.mjs
var focusMode = () => "roving";
var AccordionGroupPattern = class {
  inputs;
  navigationBehavior;
  focusBehavior;
  expansionBehavior;
  constructor(inputs) {
    this.inputs = inputs;
    this.focusBehavior = new ListFocus(__spreadProps(__spreadValues({}, inputs), {
      focusMode
    }));
    this.navigationBehavior = new ListNavigation(__spreadProps(__spreadValues({}, inputs), {
      focusMode,
      focusManager: this.focusBehavior
    }));
    this.expansionBehavior = new ListExpansion(__spreadValues({}, inputs));
  }
  prevKey = computed2(() => {
    if (this.inputs.orientation() === "vertical") {
      return "ArrowUp";
    }
    return this.inputs.textDirection() === "rtl" ? "ArrowRight" : "ArrowLeft";
  });
  nextKey = computed2(() => {
    if (this.inputs.orientation() === "vertical") {
      return "ArrowDown";
    }
    return this.inputs.textDirection() === "rtl" ? "ArrowLeft" : "ArrowRight";
  });
  keydown = computed2(() => {
    return new KeyboardEventManager().on(this.prevKey, () => this.navigationBehavior.prev(), {
      ignoreRepeat: false
    }).on(this.nextKey, () => this.navigationBehavior.next(), {
      ignoreRepeat: false
    }).on("Home", () => this.navigationBehavior.first()).on("End", () => this.navigationBehavior.last()).on(" ", () => this.toggle()).on("Enter", () => this.toggle());
  });
  pointerdown = computed2(() => {
    return new PointerEventManager().on((e) => {
      const item = this.inputs.getItem(e.target);
      if (!item) return;
      this.navigationBehavior.goto(item);
      this.expansionBehavior.toggle(item);
    });
  });
  onKeydown(event) {
    this.keydown().handle(event);
  }
  onPointerdown(event) {
    this.pointerdown().handle(event);
  }
  onFocus(event) {
    const item = this.inputs.getItem(event.target);
    if (!item) return;
    if (!this.focusBehavior.isFocusable(item)) return;
    this.focusBehavior.focus(item);
  }
  toggle() {
    const activeItem = this.inputs.activeItem();
    if (activeItem === void 0) return;
    this.expansionBehavior.toggle(activeItem);
  }
};
var AccordionTriggerPattern = class {
  inputs;
  id = () => this.inputs.id();
  element = () => this.inputs.element();
  expandable = () => true;
  expanded;
  active = computed2(() => this.inputs.accordionGroup().inputs.activeItem() === this);
  controls = computed2(() => this.inputs.accordionPanel()?.inputs.id());
  tabIndex = computed2(() => this.inputs.accordionGroup().focusBehavior.isFocusable(this) ? 0 : -1);
  disabled = computed2(() => this.inputs.disabled() || this.inputs.accordionGroup().inputs.disabled());
  hardDisabled = computed2(() => this.disabled() && !this.inputs.accordionGroup().inputs.softDisabled());
  index = computed2(() => this.inputs.accordionGroup().inputs.items().indexOf(this));
  constructor(inputs) {
    this.inputs = inputs;
    this.expanded = inputs.expanded;
  }
  open() {
    this.inputs.accordionGroup().expansionBehavior.open(this);
  }
  close() {
    this.inputs.accordionGroup().expansionBehavior.close(this);
  }
  toggle() {
    this.inputs.accordionGroup().expansionBehavior.toggle(this);
  }
};
var AccordionPanelPattern = class {
  inputs;
  id;
  accordionTrigger;
  hidden;
  constructor(inputs) {
    this.inputs = inputs;
    this.id = inputs.id;
    this.accordionTrigger = inputs.accordionTrigger;
    this.hidden = computed2(() => inputs.accordionTrigger()?.expanded() === false);
  }
};

// node_modules/@angular/aria/fesm2022/accordion.mjs
var AccordionPanel = class _AccordionPanel {
  _deferredContentAware = inject(DeferredContentAware);
  id = input(inject(_IdGenerator).getId("ng-accordion-panel-", true), ...ngDevMode ? [{
    debugName: "id"
  }] : []);
  panelId = input.required(...ngDevMode ? [{
    debugName: "panelId"
  }] : []);
  visible = computed(() => !this._pattern.hidden(), ...ngDevMode ? [{
    debugName: "visible"
  }] : []);
  _accordionTriggerPattern = signal(void 0, ...ngDevMode ? [{
    debugName: "_accordionTriggerPattern"
  }] : []);
  _pattern = new AccordionPanelPattern({
    id: this.id,
    panelId: this.panelId,
    accordionTrigger: () => this._accordionTriggerPattern()
  });
  constructor() {
    afterRenderEffect(() => {
      this._deferredContentAware.contentVisible.set(this.visible());
    });
  }
  expand() {
    this._accordionTriggerPattern()?.open();
  }
  collapse() {
    this._accordionTriggerPattern()?.close();
  }
  toggle() {
    this._accordionTriggerPattern()?.toggle();
  }
  static ɵfac = function AccordionPanel_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AccordionPanel)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _AccordionPanel,
    selectors: [["", "ngAccordionPanel", ""]],
    hostAttrs: ["role", "region"],
    hostVars: 3,
    hostBindings: function AccordionPanel_HostBindings(rf, ctx) {
      if (rf & 2) {
        let tmp_1_0;
        ɵɵattribute("id", ctx._pattern.id())("aria-labelledby", (tmp_1_0 = ctx._pattern.accordionTrigger()) == null ? null : tmp_1_0.id())("inert", !ctx.visible() ? true : null);
      }
    },
    inputs: {
      id: [1, "id"],
      panelId: [1, "panelId"]
    },
    exportAs: ["ngAccordionPanel"],
    features: [ɵɵHostDirectivesFeature([{
      directive: DeferredContentAware,
      inputs: ["preserveContent", "preserveContent"]
    }])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AccordionPanel, [{
    type: Directive,
    args: [{
      selector: "[ngAccordionPanel]",
      exportAs: "ngAccordionPanel",
      hostDirectives: [{
        directive: DeferredContentAware,
        inputs: ["preserveContent"]
      }],
      host: {
        "role": "region",
        "[attr.id]": "_pattern.id()",
        "[attr.aria-labelledby]": "_pattern.accordionTrigger()?.id()",
        "[attr.inert]": "!visible() ? true : null"
      }
    }]
  }], () => [], {
    id: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "id",
        required: false
      }]
    }],
    panelId: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "panelId",
        required: true
      }]
    }]
  });
})();
var ACCORDION_GROUP = new InjectionToken("ACCORDION_GROUP");
var AccordionTrigger = class _AccordionTrigger {
  _elementRef = inject(ElementRef);
  element = this._elementRef.nativeElement;
  _accordionGroup = inject(ACCORDION_GROUP);
  id = input(inject(_IdGenerator).getId("ng-accordion-trigger-", true), ...ngDevMode ? [{
    debugName: "id"
  }] : []);
  panelId = input.required(...ngDevMode ? [{
    debugName: "panelId"
  }] : []);
  disabled = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "disabled"
  } : {}), {
    transform: booleanAttribute
  }));
  expanded = model(false, ...ngDevMode ? [{
    debugName: "expanded"
  }] : []);
  active = computed(() => this._pattern.active(), ...ngDevMode ? [{
    debugName: "active"
  }] : []);
  _accordionPanelPattern = signal(void 0, ...ngDevMode ? [{
    debugName: "_accordionPanelPattern"
  }] : []);
  _pattern = new AccordionTriggerPattern(__spreadProps(__spreadValues({}, this), {
    accordionGroup: computed(() => this._accordionGroup._pattern),
    accordionPanel: this._accordionPanelPattern,
    element: () => this.element
  }));
  expand() {
    this._pattern.open();
  }
  collapse() {
    this._pattern.close();
  }
  toggle() {
    this._pattern.toggle();
  }
  static ɵfac = function AccordionTrigger_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AccordionTrigger)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _AccordionTrigger,
    selectors: [["", "ngAccordionTrigger", ""]],
    hostAttrs: ["role", "button"],
    hostVars: 7,
    hostBindings: function AccordionTrigger_HostBindings(rf, ctx) {
      if (rf & 2) {
        ɵɵdomProperty("id", ctx._pattern.id());
        ɵɵattribute("data-active", ctx.active())("aria-expanded", ctx.expanded())("aria-controls", ctx._pattern.controls())("aria-disabled", ctx._pattern.disabled())("disabled", ctx._pattern.hardDisabled() ? true : null)("tabindex", ctx._pattern.tabIndex());
      }
    },
    inputs: {
      id: [1, "id"],
      panelId: [1, "panelId"],
      disabled: [1, "disabled"],
      expanded: [1, "expanded"]
    },
    outputs: {
      expanded: "expandedChange"
    },
    exportAs: ["ngAccordionTrigger"]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AccordionTrigger, [{
    type: Directive,
    args: [{
      selector: "[ngAccordionTrigger]",
      exportAs: "ngAccordionTrigger",
      host: {
        "[attr.data-active]": "active()",
        "role": "button",
        "[id]": "_pattern.id()",
        "[attr.aria-expanded]": "expanded()",
        "[attr.aria-controls]": "_pattern.controls()",
        "[attr.aria-disabled]": "_pattern.disabled()",
        "[attr.disabled]": "_pattern.hardDisabled() ? true : null",
        "[attr.tabindex]": "_pattern.tabIndex()"
      }
    }]
  }], null, {
    id: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "id",
        required: false
      }]
    }],
    panelId: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "panelId",
        required: true
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    expanded: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "expanded",
        required: false
      }]
    }, {
      type: Output,
      args: ["expandedChange"]
    }]
  });
})();
var AccordionGroup = class _AccordionGroup {
  _elementRef = inject(ElementRef);
  element = this._elementRef.nativeElement;
  _triggers = contentChildren(AccordionTrigger, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "_triggers"
  } : {}), {
    descendants: true
  }));
  _triggerPatterns = computed(() => this._triggers().map((t) => t._pattern), ...ngDevMode ? [{
    debugName: "_triggerPatterns"
  }] : []);
  _panels = contentChildren(AccordionPanel, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "_panels"
  } : {}), {
    descendants: true
  }));
  textDirection = inject(Directionality).valueSignal;
  disabled = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "disabled"
  } : {}), {
    transform: booleanAttribute
  }));
  multiExpandable = input(true, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "multiExpandable"
  } : {}), {
    transform: booleanAttribute
  }));
  softDisabled = input(true, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "softDisabled"
  } : {}), {
    transform: booleanAttribute
  }));
  wrap = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "wrap"
  } : {}), {
    transform: booleanAttribute
  }));
  _pattern = new AccordionGroupPattern(__spreadProps(__spreadValues({}, this), {
    activeItem: signal(void 0),
    items: this._triggerPatterns,
    orientation: () => "vertical",
    getItem: (e) => this._getItem(e),
    element: () => this.element
  }));
  constructor() {
    afterRenderEffect(() => {
      const triggers = this._triggers();
      const panels = this._panels();
      for (const trigger of triggers) {
        const panel = panels.find((p) => p.panelId() === trigger.panelId());
        trigger._accordionPanelPattern.set(panel?._pattern);
        if (panel) {
          panel._accordionTriggerPattern.set(trigger._pattern);
        }
      }
    });
  }
  expandAll() {
    this._pattern.expansionBehavior.openAll();
  }
  collapseAll() {
    this._pattern.expansionBehavior.closeAll();
  }
  _getItem(element) {
    let target = element;
    while (target) {
      const pattern = this._triggerPatterns().find((t) => t.element() === target);
      if (pattern) {
        return pattern;
      }
      target = target.parentElement?.closest("[ngAccordionTrigger]");
    }
    return void 0;
  }
  static ɵfac = function AccordionGroup_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AccordionGroup)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _AccordionGroup,
    selectors: [["", "ngAccordionGroup", ""]],
    contentQueries: function AccordionGroup_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuerySignal(dirIndex, ctx._triggers, AccordionTrigger, 5)(dirIndex, ctx._panels, AccordionPanel, 5);
      }
      if (rf & 2) {
        ɵɵqueryAdvance(2);
      }
    },
    hostBindings: function AccordionGroup_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("keydown", function AccordionGroup_keydown_HostBindingHandler($event) {
          return ctx._pattern.onKeydown($event);
        })("pointerdown", function AccordionGroup_pointerdown_HostBindingHandler($event) {
          return ctx._pattern.onPointerdown($event);
        })("focusin", function AccordionGroup_focusin_HostBindingHandler($event) {
          return ctx._pattern.onFocus($event);
        });
      }
    },
    inputs: {
      disabled: [1, "disabled"],
      multiExpandable: [1, "multiExpandable"],
      softDisabled: [1, "softDisabled"],
      wrap: [1, "wrap"]
    },
    exportAs: ["ngAccordionGroup"],
    features: [ɵɵProvidersFeature([{
      provide: ACCORDION_GROUP,
      useExisting: _AccordionGroup
    }])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AccordionGroup, [{
    type: Directive,
    args: [{
      selector: "[ngAccordionGroup]",
      exportAs: "ngAccordionGroup",
      host: {
        "(keydown)": "_pattern.onKeydown($event)",
        "(pointerdown)": "_pattern.onPointerdown($event)",
        "(focusin)": "_pattern.onFocus($event)"
      },
      providers: [{
        provide: ACCORDION_GROUP,
        useExisting: AccordionGroup
      }]
    }]
  }], () => [], {
    _triggers: [{
      type: ContentChildren,
      args: [forwardRef(() => AccordionTrigger), __spreadProps(__spreadValues({}, {
        descendants: true
      }), {
        isSignal: true
      })]
    }],
    _panels: [{
      type: ContentChildren,
      args: [forwardRef(() => AccordionPanel), __spreadProps(__spreadValues({}, {
        descendants: true
      }), {
        isSignal: true
      })]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    multiExpandable: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "multiExpandable",
        required: false
      }]
    }],
    softDisabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "softDisabled",
        required: false
      }]
    }],
    wrap: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "wrap",
        required: false
      }]
    }]
  });
})();
var AccordionContent = class _AccordionContent {
  static ɵfac = function AccordionContent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AccordionContent)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _AccordionContent,
    selectors: [["ng-template", "ngAccordionContent", ""]],
    features: [ɵɵHostDirectivesFeature([DeferredContent])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AccordionContent, [{
    type: Directive,
    args: [{
      selector: "ng-template[ngAccordionContent]",
      hostDirectives: [DeferredContent]
    }]
  }], null, null);
})();
export {
  AccordionContent,
  AccordionGroup,
  AccordionPanel,
  AccordionTrigger,
  DeferredContent as ɵɵDeferredContent,
  DeferredContentAware as ɵɵDeferredContentAware
};
//# sourceMappingURL=@angular_aria_accordion.js.map
