import {
  DeferredContent,
  DeferredContentAware,
  KeyboardEventManager,
  PointerEventManager,
  computed as computed2,
  signal as signal2
} from "./chunk-WGVT42ER.js";
import {
  Directionality
} from "./chunk-JQ4H3PS3.js";
import {
  ContentChild,
  Directive,
  ElementRef,
  InjectionToken,
  Input,
  Output,
  __spreadProps,
  __spreadValues,
  afterRenderEffect,
  booleanAttribute,
  computed,
  contentChild,
  forwardRef,
  inject,
  input,
  model,
  setClassMetadata,
  signal,
  untracked,
  ɵɵHostDirectivesFeature,
  ɵɵProvidersFeature,
  ɵɵattribute,
  ɵɵcontentQuerySignal,
  ɵɵdefineDirective,
  ɵɵdomProperty,
  ɵɵlistener,
  ɵɵqueryAdvance
} from "./chunk-XVCATVL7.js";

// node_modules/@angular/aria/fesm2022/_combobox-chunk.mjs
var ComboboxPattern = class {
  inputs;
  expanded = signal2(false);
  disabled = () => this.inputs.disabled();
  activeDescendant = computed2(() => {
    const popupControls = this.inputs.popupControls();
    if (popupControls instanceof ComboboxDialogPattern) {
      return null;
    }
    return popupControls?.activeId() ?? null;
  });
  highlightedItem = signal2(void 0);
  isDeleting = false;
  isFocused = signal2(false);
  hasBeenFocused = signal2(false);
  expandKey = computed2(() => this.inputs.textDirection() === "rtl" ? "ArrowLeft" : "ArrowRight");
  collapseKey = computed2(() => this.inputs.textDirection() === "rtl" ? "ArrowRight" : "ArrowLeft");
  popupId = computed2(() => this.inputs.popupControls()?.id() || null);
  autocomplete = computed2(() => this.inputs.filterMode() === "highlight" ? "both" : "list");
  hasPopup = computed2(() => this.inputs.popupControls()?.role() || null);
  readonly = computed2(() => this.inputs.readonly() || this.inputs.disabled() || null);
  listControls = () => {
    const popupControls = this.inputs.popupControls();
    if (popupControls instanceof ComboboxDialogPattern) {
      return null;
    }
    return popupControls;
  };
  treeControls = () => {
    const popupControls = this.inputs.popupControls();
    if (popupControls?.role() === "tree") {
      return popupControls;
    }
    return null;
  };
  keydown = computed2(() => {
    const manager = new KeyboardEventManager();
    const popupControls = this.inputs.popupControls();
    if (!popupControls) {
      return manager;
    }
    if (popupControls instanceof ComboboxDialogPattern) {
      if (!this.expanded()) {
        manager.on("ArrowUp", () => this.open()).on("ArrowDown", () => this.open());
        if (this.readonly()) {
          manager.on("Enter", () => this.open()).on(" ", () => this.open());
        }
      }
      return manager;
    }
    if (!this.inputs.alwaysExpanded()) {
      manager.on("Escape", () => this.close({
        reset: !this.readonly()
      }));
    }
    if (!this.expanded()) {
      manager.on("ArrowDown", () => this.open({
        first: true
      })).on("ArrowUp", () => this.open({
        last: true
      }));
      if (this.readonly()) {
        manager.on("Enter", () => this.open({
          selected: true
        })).on(" ", () => this.open({
          selected: true
        }));
      }
      return manager;
    }
    manager.on("ArrowDown", () => this.next(), {
      ignoreRepeat: false
    }).on("ArrowUp", () => this.prev(), {
      ignoreRepeat: false
    }).on("Home", () => this.first()).on("End", () => this.last());
    if (this.readonly()) {
      manager.on(" ", () => this.select({
        commit: true,
        close: !popupControls.multi()
      }));
    }
    if (popupControls.role() === "listbox") {
      manager.on("Enter", () => {
        this.select({
          commit: true,
          close: !popupControls.multi()
        });
      });
    }
    const treeControls = this.treeControls();
    if (treeControls?.isItemSelectable()) {
      manager.on("Enter", () => this.select({
        commit: true,
        close: true
      }));
    }
    if (treeControls?.isItemExpandable()) {
      manager.on(this.expandKey(), () => this.expandItem()).on(this.collapseKey(), () => this.collapseItem());
      if (!treeControls.isItemSelectable()) {
        manager.on("Enter", () => this.expandItem());
      }
    }
    if (treeControls?.isItemCollapsible()) {
      manager.on(this.collapseKey(), () => this.collapseItem());
    }
    return manager;
  });
  click = computed2(() => new PointerEventManager().on((e) => {
    if (e.target === this.inputs.inputEl()) {
      if (this.readonly()) {
        this.expanded() ? this.close() : this.open({
          selected: true
        });
      }
    }
    const controls = this.inputs.popupControls();
    if (controls instanceof ComboboxDialogPattern) {
      return;
    }
    const item = controls?.getItem(e);
    if (item) {
      if (controls?.role() === "tree") {
        const treeControls = controls;
        if (treeControls.isItemExpandable(item) && !treeControls.isItemSelectable(item)) {
          treeControls.toggleExpansion(item);
          this.inputs.inputEl()?.focus();
          return;
        }
      }
      this.select({
        item,
        commit: true,
        close: !controls?.multi()
      });
      this.inputs.inputEl()?.focus();
    }
  }));
  constructor(inputs) {
    this.inputs = inputs;
  }
  onKeydown(event) {
    if (!this.inputs.disabled()) {
      this.keydown().handle(event);
    }
  }
  onClick(event) {
    if (!this.inputs.disabled()) {
      this.click().handle(event);
    }
  }
  onInput(event) {
    if (this.inputs.disabled() || this.inputs.readonly()) {
      return;
    }
    const inputEl = this.inputs.inputEl();
    if (!inputEl) {
      return;
    }
    const popupControls = this.inputs.popupControls();
    if (popupControls instanceof ComboboxDialogPattern) {
      return;
    }
    this.open();
    this.inputs.inputValue?.set(inputEl.value);
    this.isDeleting = event instanceof InputEvent && !!event.inputType.match(/^delete/);
    if (this.inputs.filterMode() === "highlight" && !this.isDeleting) {
      this.highlight();
    }
  }
  onFocusIn() {
    if (this.inputs.alwaysExpanded() && !this.hasBeenFocused()) {
      const firstSelectedItem = this.listControls()?.getSelectedItems()[0];
      firstSelectedItem ? this.listControls()?.focus(firstSelectedItem) : this.first();
    }
    this.isFocused.set(true);
    this.hasBeenFocused.set(true);
  }
  onFocusOut(event) {
    if (this.inputs.disabled()) {
      return;
    }
    const popupControls = this.inputs.popupControls();
    if (popupControls instanceof ComboboxDialogPattern) {
      return;
    }
    if (!(event.relatedTarget instanceof HTMLElement) || !this.inputs.containerEl()?.contains(event.relatedTarget)) {
      this.isFocused.set(false);
      if (!this.expanded()) {
        return;
      }
      if (this.readonly()) {
        this.close();
        return;
      }
      if (this.inputs.filterMode() !== "manual") {
        this.commit();
      } else {
        const item = popupControls?.items().find((i) => i.searchTerm() === this.inputs.inputEl()?.value);
        if (item) {
          this.select({
            item
          });
        }
      }
      this.close();
    }
  }
  firstMatch = computed2(() => {
    if (this.listControls()?.role() === "listbox") {
      return this.listControls()?.items()[0];
    }
    return this.listControls()?.items().find((i) => i.value() === this.inputs.firstMatch());
  });
  onFilter() {
    if (this.readonly()) {
      return;
    }
    const popupControls = this.inputs.popupControls();
    if (popupControls instanceof ComboboxDialogPattern) {
      return;
    }
    const isInitialRender = !this.inputs.inputValue?.().length && !this.isDeleting;
    if (isInitialRender) {
      return;
    }
    if (!this.isFocused()) {
      return;
    }
    if (this.inputs.popupControls()?.role() === "tree") {
      const treeControls = this.inputs.popupControls();
      this.inputs.inputValue?.().length ? treeControls.expandAll() : treeControls.collapseAll();
    }
    const item = this.firstMatch();
    if (!item) {
      popupControls?.clearSelection();
      popupControls?.unfocus();
      return;
    }
    popupControls?.focus(item);
    if (this.inputs.filterMode() !== "manual") {
      this.select({
        item
      });
    }
    if (this.inputs.filterMode() === "highlight" && !this.isDeleting) {
      this.highlight();
    }
  }
  highlight() {
    const inputEl = this.inputs.inputEl();
    const selectedItems = this.listControls()?.getSelectedItems();
    const item = selectedItems?.[0];
    if (!inputEl || !item) {
      return;
    }
    const isHighlightable = item.searchTerm().toLowerCase().startsWith(this.inputs.inputValue().toLowerCase());
    if (isHighlightable) {
      inputEl.value = this.inputs.inputValue() + item.searchTerm().slice(this.inputs.inputValue().length);
      inputEl.setSelectionRange(this.inputs.inputValue().length, item.searchTerm().length);
      this.highlightedItem.set(item);
    }
  }
  close(opts) {
    const popupControls = this.inputs.popupControls();
    if (this.inputs.alwaysExpanded()) {
      return;
    }
    if (popupControls instanceof ComboboxDialogPattern) {
      this.expanded.set(false);
      return;
    }
    if (this.readonly()) {
      this.expanded.set(false);
      popupControls?.unfocus();
      return;
    }
    if (!opts?.reset) {
      if (this.inputs.filterMode() === "manual") {
        if (!this.listControls()?.items().some((i) => i.searchTerm() === this.inputs.inputEl()?.value)) {
          this.listControls()?.clearSelection();
        }
      }
      this.expanded.set(false);
      popupControls?.unfocus();
      return;
    }
    if (!this.expanded()) {
      this.inputs.inputValue?.set("");
      popupControls?.clearSelection();
      const inputEl = this.inputs.inputEl();
      if (inputEl) {
        inputEl.value = "";
      }
    } else if (this.expanded()) {
      this.expanded.set(false);
      const selectedItem = popupControls?.getSelectedItems()?.[0];
      if (selectedItem?.searchTerm() !== this.inputs.inputValue()) {
        popupControls?.clearSelection();
      }
      return;
    }
    this.close();
    if (!this.readonly()) {
      popupControls?.clearSelection();
    }
  }
  open(nav) {
    this.expanded.set(true);
    const popupControls = this.inputs.popupControls();
    if (popupControls instanceof ComboboxDialogPattern) {
      return;
    }
    const inputEl = this.inputs.inputEl();
    if (inputEl && this.inputs.filterMode() === "highlight") {
      const isHighlighting = inputEl.selectionStart !== inputEl.value.length;
      this.inputs.inputValue?.set(inputEl.value.slice(0, inputEl.selectionStart || 0));
      if (!isHighlighting) {
        this.highlightedItem.set(void 0);
      }
    }
    if (nav?.first) {
      this.first();
    }
    if (nav?.last) {
      this.last();
    }
    if (nav?.selected) {
      const selectedItem = popupControls?.items().find((i) => popupControls?.getSelectedItems().includes(i));
      if (selectedItem) {
        popupControls?.focus(selectedItem);
      }
    }
  }
  next() {
    this._navigate(() => this.listControls()?.next());
  }
  prev() {
    this._navigate(() => this.listControls()?.prev());
  }
  first() {
    this._navigate(() => this.listControls()?.first());
  }
  last() {
    this._navigate(() => this.listControls()?.last());
  }
  collapseItem() {
    const controls = this.inputs.popupControls();
    this._navigate(() => controls?.collapseItem());
  }
  expandItem() {
    const controls = this.inputs.popupControls();
    this._navigate(() => controls?.expandItem());
  }
  select(opts = {}) {
    const controls = this.listControls();
    const item = opts.item ?? controls?.getActiveItem();
    if (item?.disabled()) {
      return;
    }
    if (opts.item) {
      controls?.focus(opts.item, {
        focusElement: false
      });
    }
    controls?.multi() ? controls.toggle(opts.item) : controls?.select(opts.item);
    if (opts.commit) {
      this.commit();
    }
    if (opts.close) {
      this.close();
    }
  }
  commit() {
    const inputEl = this.inputs.inputEl();
    const selectedItems = this.listControls()?.getSelectedItems();
    if (!inputEl) {
      return;
    }
    inputEl.value = selectedItems?.map((i) => i.searchTerm()).join(", ") || "";
    this.inputs.inputValue?.set(inputEl.value);
    if (this.inputs.filterMode() === "highlight" && !this.readonly()) {
      const length = inputEl.value.length;
      inputEl.setSelectionRange(length, length);
    }
  }
  _navigate(operation) {
    operation();
    if (this.inputs.filterMode() !== "manual") {
      this.select();
    }
    if (this.inputs.filterMode() === "highlight") {
      const selectedItem = this.listControls()?.getSelectedItems()[0];
      if (!selectedItem) {
        return;
      }
      if (selectedItem === this.highlightedItem()) {
        this.highlight();
      } else {
        const inputEl = this.inputs.inputEl();
        inputEl.value = selectedItem?.searchTerm();
      }
    }
  }
};
var ComboboxDialogPattern = class {
  inputs;
  id = () => this.inputs.id();
  role = () => "dialog";
  keydown = computed2(() => {
    return new KeyboardEventManager().on("Escape", () => this.inputs.combobox.close());
  });
  constructor(inputs) {
    this.inputs = inputs;
  }
  onKeydown(event) {
    this.keydown().handle(event);
  }
  onClick(event) {
    if (event.target === this.inputs.element()) {
      this.inputs.combobox.close();
    }
  }
};

// node_modules/@angular/aria/fesm2022/combobox.mjs
var COMBOBOX = new InjectionToken("COMBOBOX");
var ComboboxPopup = class _ComboboxPopup {
  combobox = inject(COMBOBOX, {
    optional: true
  });
  _controls = signal(void 0, ...ngDevMode ? [{
    debugName: "_controls"
  }] : []);
  static ɵfac = function ComboboxPopup_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ComboboxPopup)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _ComboboxPopup,
    selectors: [["", "ngComboboxPopup", ""]],
    exportAs: ["ngComboboxPopup"]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ComboboxPopup, [{
    type: Directive,
    args: [{
      selector: "[ngComboboxPopup]",
      exportAs: "ngComboboxPopup"
    }]
  }], null, null);
})();
var Combobox = class _Combobox {
  textDirection = inject(Directionality).valueSignal.asReadonly();
  _elementRef = inject(ElementRef);
  element = this._elementRef.nativeElement;
  _deferredContentAware = inject(DeferredContentAware, {
    optional: true
  });
  popup = contentChild(ComboboxPopup, ...ngDevMode ? [{
    debugName: "popup"
  }] : []);
  filterMode = input("manual", ...ngDevMode ? [{
    debugName: "filterMode"
  }] : []);
  disabled = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "disabled"
  } : {}), {
    transform: booleanAttribute
  }));
  readonly = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "readonly"
  } : {}), {
    transform: booleanAttribute
  }));
  firstMatch = input(void 0, ...ngDevMode ? [{
    debugName: "firstMatch"
  }] : []);
  expanded = computed(() => this.alwaysExpanded() || this._pattern.expanded(), ...ngDevMode ? [{
    debugName: "expanded"
  }] : []);
  alwaysExpanded = input(false, __spreadProps(__spreadValues({}, ngDevMode ? {
    debugName: "alwaysExpanded"
  } : {}), {
    transform: booleanAttribute
  }));
  inputElement = computed(() => this._pattern.inputs.inputEl(), ...ngDevMode ? [{
    debugName: "inputElement"
  }] : []);
  _pattern = new ComboboxPattern(__spreadProps(__spreadValues({}, this), {
    textDirection: this.textDirection,
    disabled: this.disabled,
    readonly: this.readonly,
    inputValue: signal(""),
    inputEl: signal(void 0),
    containerEl: () => this._elementRef.nativeElement,
    popupControls: () => this.popup()?._controls()
  }));
  constructor() {
    afterRenderEffect(() => {
      if (this.alwaysExpanded()) {
        this._pattern.expanded.set(true);
      }
    });
    afterRenderEffect(() => {
      if (!this._deferredContentAware?.contentVisible() && (this._pattern.isFocused() || this.alwaysExpanded())) {
        this._deferredContentAware?.contentVisible.set(true);
      }
    });
  }
  open() {
    this._pattern.open({
      selected: true
    });
  }
  close() {
    this._pattern.close();
  }
  static ɵfac = function Combobox_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Combobox)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _Combobox,
    selectors: [["", "ngCombobox", ""]],
    contentQueries: function Combobox_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuerySignal(dirIndex, ctx.popup, ComboboxPopup, 5);
      }
      if (rf & 2) {
        ɵɵqueryAdvance();
      }
    },
    hostVars: 1,
    hostBindings: function Combobox_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("input", function Combobox_input_HostBindingHandler($event) {
          return ctx._pattern.onInput($event);
        })("keydown", function Combobox_keydown_HostBindingHandler($event) {
          return ctx._pattern.onKeydown($event);
        })("click", function Combobox_click_HostBindingHandler($event) {
          return ctx._pattern.onClick($event);
        })("focusin", function Combobox_focusin_HostBindingHandler() {
          return ctx._pattern.onFocusIn();
        })("focusout", function Combobox_focusout_HostBindingHandler($event) {
          return ctx._pattern.onFocusOut($event);
        });
      }
      if (rf & 2) {
        ɵɵattribute("data-expanded", ctx.expanded());
      }
    },
    inputs: {
      filterMode: [1, "filterMode"],
      disabled: [1, "disabled"],
      readonly: [1, "readonly"],
      firstMatch: [1, "firstMatch"],
      alwaysExpanded: [1, "alwaysExpanded"]
    },
    exportAs: ["ngCombobox"],
    features: [ɵɵProvidersFeature([{
      provide: COMBOBOX,
      useExisting: _Combobox
    }]), ɵɵHostDirectivesFeature([{
      directive: DeferredContentAware,
      inputs: ["preserveContent", "preserveContent"]
    }])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Combobox, [{
    type: Directive,
    args: [{
      selector: "[ngCombobox]",
      exportAs: "ngCombobox",
      hostDirectives: [{
        directive: DeferredContentAware,
        inputs: ["preserveContent"]
      }],
      host: {
        "[attr.data-expanded]": "expanded()",
        "(input)": "_pattern.onInput($event)",
        "(keydown)": "_pattern.onKeydown($event)",
        "(click)": "_pattern.onClick($event)",
        "(focusin)": "_pattern.onFocusIn()",
        "(focusout)": "_pattern.onFocusOut($event)"
      },
      providers: [{
        provide: COMBOBOX,
        useExisting: Combobox
      }]
    }]
  }], () => [], {
    popup: [{
      type: ContentChild,
      args: [forwardRef(() => ComboboxPopup), {
        isSignal: true
      }]
    }],
    filterMode: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "filterMode",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    readonly: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "readonly",
        required: false
      }]
    }],
    firstMatch: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "firstMatch",
        required: false
      }]
    }],
    alwaysExpanded: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "alwaysExpanded",
        required: false
      }]
    }]
  });
})();
var ComboboxDialog = class _ComboboxDialog {
  _elementRef = inject(ElementRef);
  element = this._elementRef.nativeElement;
  combobox = inject(Combobox);
  _popup = inject(ComboboxPopup, {
    optional: true
  });
  _pattern;
  constructor() {
    this._pattern = new ComboboxDialogPattern({
      id: () => "",
      element: () => this._elementRef.nativeElement,
      combobox: this.combobox._pattern
    });
    if (this._popup) {
      this._popup._controls.set(this._pattern);
    }
    afterRenderEffect(() => {
      if (this._elementRef) {
        this.combobox._pattern.expanded() ? this._elementRef.nativeElement.showModal() : this._elementRef.nativeElement.close();
      }
    });
  }
  close() {
    this._popup?.combobox?._pattern.close();
  }
  static ɵfac = function ComboboxDialog_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ComboboxDialog)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _ComboboxDialog,
    selectors: [["dialog", "ngComboboxDialog", ""]],
    hostVars: 1,
    hostBindings: function ComboboxDialog_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("keydown", function ComboboxDialog_keydown_HostBindingHandler($event) {
          return ctx._pattern.onKeydown($event);
        })("click", function ComboboxDialog_click_HostBindingHandler($event) {
          return ctx._pattern.onClick($event);
        });
      }
      if (rf & 2) {
        ɵɵattribute("data-open", ctx.combobox._pattern.expanded());
      }
    },
    exportAs: ["ngComboboxDialog"],
    features: [ɵɵHostDirectivesFeature([ComboboxPopup])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ComboboxDialog, [{
    type: Directive,
    args: [{
      selector: "dialog[ngComboboxDialog]",
      exportAs: "ngComboboxDialog",
      host: {
        "[attr.data-open]": "combobox._pattern.expanded()",
        "(keydown)": "_pattern.onKeydown($event)",
        "(click)": "_pattern.onClick($event)"
      },
      hostDirectives: [ComboboxPopup]
    }]
  }], () => [], null);
})();
var ComboboxInput = class _ComboboxInput {
  _elementRef = inject(ElementRef);
  element = this._elementRef.nativeElement;
  combobox = inject(Combobox);
  value = model("", ...ngDevMode ? [{
    debugName: "value"
  }] : []);
  constructor() {
    this.combobox._pattern.inputs.inputEl.set(this._elementRef.nativeElement);
    this.combobox._pattern.inputs.inputValue = this.value;
    const controls = this.combobox.popup()?._controls();
    if (controls instanceof ComboboxDialogPattern) {
      return;
    }
    afterRenderEffect(() => {
      this.value();
      controls?.items();
      untracked(() => this.combobox._pattern.onFilter());
    });
  }
  static ɵfac = function ComboboxInput_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ComboboxInput)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _ComboboxInput,
    selectors: [["input", "ngComboboxInput", ""]],
    hostAttrs: ["role", "combobox"],
    hostVars: 8,
    hostBindings: function ComboboxInput_HostBindings(rf, ctx) {
      if (rf & 2) {
        ɵɵdomProperty("value", ctx.value());
        ɵɵattribute("aria-disabled", ctx.combobox._pattern.disabled())("aria-expanded", ctx.combobox._pattern.expanded())("aria-activedescendant", ctx.combobox._pattern.activeDescendant())("aria-controls", ctx.combobox._pattern.popupId())("aria-haspopup", ctx.combobox._pattern.hasPopup())("aria-autocomplete", ctx.combobox._pattern.autocomplete())("readonly", ctx.combobox._pattern.readonly());
      }
    },
    inputs: {
      value: [1, "value"]
    },
    outputs: {
      value: "valueChange"
    },
    exportAs: ["ngComboboxInput"]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ComboboxInput, [{
    type: Directive,
    args: [{
      selector: "input[ngComboboxInput]",
      exportAs: "ngComboboxInput",
      host: {
        "role": "combobox",
        "[value]": "value()",
        "[attr.aria-disabled]": "combobox._pattern.disabled()",
        "[attr.aria-expanded]": "combobox._pattern.expanded()",
        "[attr.aria-activedescendant]": "combobox._pattern.activeDescendant()",
        "[attr.aria-controls]": "combobox._pattern.popupId()",
        "[attr.aria-haspopup]": "combobox._pattern.hasPopup()",
        "[attr.aria-autocomplete]": "combobox._pattern.autocomplete()",
        "[attr.readonly]": "combobox._pattern.readonly()"
      }
    }]
  }], () => [], {
    value: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "value",
        required: false
      }]
    }, {
      type: Output,
      args: ["valueChange"]
    }]
  });
})();
var ComboboxPopupContainer = class _ComboboxPopupContainer {
  static ɵfac = function ComboboxPopupContainer_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ComboboxPopupContainer)();
  };
  static ɵdir = ɵɵdefineDirective({
    type: _ComboboxPopupContainer,
    selectors: [["ng-template", "ngComboboxPopupContainer", ""]],
    exportAs: ["ngComboboxPopupContainer"],
    features: [ɵɵHostDirectivesFeature([DeferredContent])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ComboboxPopupContainer, [{
    type: Directive,
    args: [{
      selector: "ng-template[ngComboboxPopupContainer]",
      exportAs: "ngComboboxPopupContainer",
      hostDirectives: [DeferredContent]
    }]
  }], null, null);
})();

export {
  ComboboxPopup,
  Combobox,
  ComboboxDialog,
  ComboboxInput,
  ComboboxPopupContainer
};
//# sourceMappingURL=chunk-QATKE2KZ.js.map
