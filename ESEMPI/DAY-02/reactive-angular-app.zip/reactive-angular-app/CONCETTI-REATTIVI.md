# Programmazione Reattiva in Angular 21 - Guida Completa

## 📚 Introduzione

Questa applicazione è una guida interattiva completa per apprendere i concetti fondamentali della programmazione reattiva in Angular 21, seguendo le best practices più recenti.

## 🎯 Tecnologie Utilizzate

- **Angular 21** - Framework web moderno
- **RxJS** - Libreria per programmazione reattiva
- **Signal** - Sistema di reattività nativo di Angular
- **TypeScript** - Linguaggio type-safe
- **Bootstrap 5** - Framework CSS responsive
- **SCSS** - Preprocessore CSS

## ✨ Caratteristiche Angular 21

- ✅ **Zoneless** - Performance migliorate senza Zone.js
- ✅ **SSR (Server-Side Rendering)** - Rendering lato server
- ✅ **Standalone Components** - No NgModule
- ✅ **Signal-based** - Gestione stato reattiva nativa
- ✅ **No Deprecated APIs** - Solo API moderne

## 📖 Concetti Coperti

### 1. 💫 Paradigma Imperativo vs Reattivo

**Imperativo (Come):**
- Descrivi COME eseguire ogni step
- Controllo esplicito del flusso
- Modifica diretta dello stato
- Gestione manuale delle risorse

**Reattivo (Cosa):**
- Descrivi COSA vuoi ottenere
- Reazione automatica ai cambiamenti
- Stream di dati immutabili
- Gestione automatica delle risorse

**Esempio Pratico:**
```typescript
// Imperativo
let count = 0;
const id = setInterval(() => {
  count++;
  updateUI(count);
  if (count >= 10) clearInterval(id);
}, 1000);

// Reattivo
interval(1000).pipe(
  take(10),
  map(n => n + 1)
).subscribe(count => updateUI(count));
```

### 2. 🔄 Push vs Pull

**PULL (Consumer in controllo):**
- Il consumer decide QUANDO ottenere i dati
- Esempi: funzioni, getter, array access
- Sincrono
- Dati disponibili immediatamente

**PUSH (Producer in controllo):**
- Il producer decide QUANDO inviare i dati
- Esempi: eventi, Observable, Promise
- Asincrono
- Dati arrivano nel tempo

**Tabella Comparativa:**

| Aspetto | PULL | PUSH |
|---------|------|------|
| Controllo | Consumer | Producer |
| Timing | Immediato | Quando pronto |
| Modalità | Sincrono | Asincrono |
| Valori multipli | Con iterazione | Stream naturale |

### 3. 🌊 Stream di Eventi

**Stream:** Sequenza di valori nel tempo
```
Click:  ---1---2---3---4--->
Mouse:  ------(x,y)-(x,y)--->
Time:   -0-1-2-3-4-5-6-7-8->
```

**Operatori Comuni:**

- `map()` - Trasforma valori
- `filter()` - Filtra valori
- `scan()` - Accumula (come reduce)
- `throttleTime()` - Limita frequenza
- `debounceTime()` - Attende silenzio
- `merge()` - Combina stream

**Best Practices:**
- Usa `takeUntil()` per cleanup
- `debounce` per ricerche/API
- `throttle` per scroll/resize
- Combina stream con merge/combine

### 4. 📦 Observable come Modello Mentale

**Observable:** Una "ricetta" per produrre valori

**Caratteristiche:**
- Lazy execution
- Può emettere 0, 1 o molti valori
- Può completare o andare in errore
- Unicast (di default)

**Contract:** `next* (error | complete)?`

**Anatomia:**
```typescript
const obs$ = new Observable(observer => {
  // 1. Setup
  console.log('Esecuzione avviata');
  
  // 2. Emissioni
  observer.next(1);
  observer.next(2);
  
  // 3. Terminazione
  observer.complete();
  
  // 4. Cleanup
  return () => console.log('Pulizia');
});
```

**Observer (chi ascolta):**
```typescript
obs$.subscribe({
  next: (v) => console.log(v),
  error: (e) => console.error(e),
  complete: () => console.log('Fine!')
});
```

### 5. 🌡️ Cold vs Hot Observable

**COLD (Unicast):**
- Ogni subscriber = nuova esecuzione
- Producer creato dentro Observable
- Come un film su Netflix (ognuno lo avvia)

**HOT (Multicast):**
- Esecuzione condivisa
- Producer fuori dall'Observable
- Come TV in diretta (tutti vedono lo stesso)

**Trasformazione Cold → Hot:**
```typescript
// Cold
const cold$ = interval(1000);

// Hot (con share)
const hot$ = cold$.pipe(share());
```

**Subject:** Sempre Hot
- Può emettere E ricevere
- Tutti i subscriber condividono i valori
- Chi arriva tardi perde i valori precedenti

### 6. ⏱️ Gestione del Tempo

**Operatori Temporali:**

**debounceTime(ms):** Attende silenzio
```typescript
search$.pipe(debounceTime(500))
// Per: ricerca, autocomplete, validazione
```

**throttleTime(ms):** Limita frequenza
```typescript
scroll$.pipe(throttleTime(200))
// Per: scroll, resize, mousemove
```

**sampleTime(ms):** Snapshot periodico
```typescript
data$.pipe(sampleTime(1000))
// Prende l'ultimo valore ogni 1s
```

**auditTime(ms):** Emette poi pausa
```typescript
clicks$.pipe(auditTime(1000))
// Primo click passa, poi ignora per 1s
```

**bufferTime(ms):** Accumula in array
```typescript
events$.pipe(bufferTime(1000))
// Raccoglie eventi per 1s, poi emette array
```

**delay(ms):** Ritarda tutto
```typescript
data$.pipe(delay(1000))
// Sposta tutto lo stream avanti di 1s
```

### 7. 🎨 Reactive UI

**Signal-based Reactivity (Angular 21):**

```typescript
// Signal base
const firstName = signal('Mario');
const lastName = signal('Rossi');

// Computed (derivato)
const fullName = computed(() => 
  `${firstName()} ${lastName()}`
);

// Aggiornamento
firstName.set('Luigi');  // fullName si aggiorna automaticamente!
```

**Vantaggi:**
- Aggiornamenti automatici UI
- Performance ottimali
- Type-safe
- No boilerplate

**Pattern:**
```typescript
// Stato base (Signal)
products = signal([...]);

// Stato derivato (Computed)
total = computed(() => 
  products().reduce((sum, p) => sum + p.price, 0)
);

// Template si aggiorna automaticamente
{{ total() }}
```

### 8. ❌ Error Propagation

**Gestione Errori negli Observable:**

**catchError:** Gestisce errore e continua
```typescript
http$.pipe(
  catchError(err => {
    console.error(err);
    return of(defaultValue);  // Fallback
  })
)
```

**retry(n):** Riprova N volte
```typescript
http$.pipe(
  retry(3)  // 3 retry = 4 tentativi totali
)
```

**retryWhen:** Logica personalizzata
```typescript
http$.pipe(
  retryWhen(errors => errors.pipe(
    delay(1000),     // Attendi 1s tra retry
    take(3)          // Max 3 retry
  ))
)
```

**Best Practices:**
- Usa `catchError` per fallback
- Usa `retry` per errori transienti HTTP
- Usa `retryWhen` per delay incrementale
- Logga sempre gli errori
- Mostra feedback all'utente

## 🚀 Come Iniziare

### Prerequisiti
- Node.js 18+ 
- npm 9+
- Angular CLI 21+

### Installazione

```bash
# Installa dipendenze
npm install

# Avvia server di sviluppo
ng serve

# Apri browser
http://localhost:4200
```

### Build

```bash
# Build di produzione
ng build

# Build con SSR
npm run build:ssr

# Serve SSR build
npm run serve:ssr
```

## 📁 Struttura Progetto

```
reactive-angular-app/
├── src/
│   ├── app/
│   │   ├── components/
│   │   │   ├── imperative-vs-reactive/
│   │   │   ├── push-vs-pull/
│   │   │   ├── event-streams/
│   │   │   ├── observable-mental-model/
│   │   │   ├── cold-vs-hot/
│   │   │   ├── time-management/
│   │   │   ├── reactive-ui/
│   │   │   └── error-propagation/
│   │   ├── app.ts              # Componente principale
│   │   ├── app.html            # Layout con navigazione
│   │   ├── app.routes.ts       # Configurazione routing
│   │   └── app.config.ts       # Configurazione app
│   ├── styles.scss             # Stili globali + Bootstrap
│   └── main.ts                 # Bootstrap app
└── angular.json                # Configurazione Angular
```

## 💡 Best Practices Implementate

1. **Zoneless Architecture**
   - Migliori performance
   - Change detection ottimizzata

2. **Signal-based State**
   - Reattività nativa
   - Type-safe
   - Performance eccellenti

3. **Standalone Components**
   - No NgModule
   - Tree-shakable
   - Più semplice

4. **Server-Side Rendering**
   - SEO migliore
   - First paint più veloce
   - UX ottimizzata

5. **Responsive Design**
   - Bootstrap 5
   - Mobile-first
   - Accessibile

## 🎓 Ordine di Studio Consigliato

1. **Imperativo vs Reattivo** - Comprendi il cambio di paradigma
2. **Push vs Pull** - Capisci chi controlla il flusso
3. **Stream di Eventi** - Lavora con eventi come stream
4. **Observable Model** - Modello mentale fondamentale
5. **Cold vs Hot** - Unicast vs Multicast
6. **Gestione Tempo** - Operatori temporali
7. **Reactive UI** - Signal e computed
8. **Error Propagation** - Gestione errori robusti

## 📚 Risorse Aggiuntive

- [Angular Documentation](https://angular.dev)
- [RxJS Documentation](https://rxjs.dev)
- [RxJS Marbles](https://rxmarbles.com) - Visualizza operatori
- [Learn RxJS](https://www.learnrxjs.io) - Esempi pratici

## 🤝 Contribuire

Questo progetto è a scopo educativo. Sentiti libero di:
- Sperimentare con il codice
- Aggiungere nuovi esempi
- Migliorare la documentazione
- Condividere con altri

## 📝 Note

- Tutti i commenti nel codice sono in italiano
- Ogni componente è completamente documentato
- Gli esempi sono interattivi
- Il design è responsive e accessibile

## ⚡ Performance

- Zoneless per performance native
- Signal per change detection ottimizzata
- OnPush strategy dove applicabile
- Lazy loading routes (se espanso)

## 🎯 Obiettivi di Apprendimento

Dopo aver completato questa guida, sarai in grado di:
- ✅ Pensare in modo reattivo
- ✅ Usare RxJS efficacemente
- ✅ Gestire stato con Signal
- ✅ Creare UI reattive performanti
- ✅ Gestire errori correttamente
- ✅ Seguire best practices Angular 21

---

**Buono studio! 🚀**
