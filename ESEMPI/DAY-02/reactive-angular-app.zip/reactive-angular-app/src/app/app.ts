import { Component, signal } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';

/**
 * Componente principale dell'applicazione
 * Fornisce la navigazione tra i vari concetti di programmazione reattiva
 */
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected readonly title = signal('Programmazione Reattiva in Angular 21');
  
  // Controlla se il menu mobile è aperto
  mobileMenuOpen = signal(false);
  
  // Menu items con icone
  menuItems = [
    { path: '/imperative-vs-reactive', label: 'Imperativo vs Reattivo', icon: '⚛️' },
    { path: '/push-vs-pull', label: 'Push vs Pull', icon: '🔄' },
    { path: '/event-streams', label: 'Stream di Eventi', icon: '🌊' },
    { path: '/observable-model', label: 'Observable Model', icon: '📦' },
    { path: '/cold-vs-hot', label: 'Cold vs Hot', icon: '🌡️' },
    { path: '/time-management', label: 'Gestione Tempo', icon: '⏱️' },
    { path: '/reactive-ui', label: 'Reactive UI', icon: '🎨' },
    { path: '/error-propagation', label: 'Error Propagation', icon: '❌' }
  ];
  
  toggleMobileMenu(): void {
    this.mobileMenuOpen.update(open => !open);
  }
  
  closeMobileMenu(): void {
    this.mobileMenuOpen.set(false);
  }
}
