import { Routes } from '@angular/router';
import { ImperativeVsReactiveComponent } from './components/imperative-vs-reactive/imperative-vs-reactive';
import { PushVsPullComponent } from './components/push-vs-pull/push-vs-pull';
import { EventStreamsComponent } from './components/event-streams/event-streams';
import { ObservableMentalModelComponent } from './components/observable-mental-model/observable-mental-model';
import { ColdVsHotComponent } from './components/cold-vs-hot/cold-vs-hot';
import { TimeManagementComponent } from './components/time-management/time-management';
import { ReactiveUiComponent } from './components/reactive-ui/reactive-ui';
import { ErrorPropagationComponent } from './components/error-propagation/error-propagation';

export const routes: Routes = [
  { path: '', redirectTo: '/imperative-vs-reactive', pathMatch: 'full' },
  { path: 'imperative-vs-reactive', component: ImperativeVsReactiveComponent },
  { path: 'push-vs-pull', component: PushVsPullComponent },
  { path: 'event-streams', component: EventStreamsComponent },
  { path: 'observable-model', component: ObservableMentalModelComponent },
  { path: 'cold-vs-hot', component: ColdVsHotComponent },
  { path: 'time-management', component: TimeManagementComponent },
  { path: 'reactive-ui', component: ReactiveUiComponent },
  { path: 'error-propagation', component: ErrorPropagationComponent }
];
