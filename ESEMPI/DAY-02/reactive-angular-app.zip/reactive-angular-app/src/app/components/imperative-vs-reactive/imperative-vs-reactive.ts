import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { interval, map, take } from 'rxjs';

/**
 * Componente che dimostra la differenza tra paradigma imperativo e reattivo
 *
 * PARADIGMA IMPERATIVO:
 * - Dice "come" fare le cose step by step
 * - Controlla esplicitamente il flusso di esecuzione
 * - Modifica lo stato in modo diretto
 *
 * PARADIGMA REATTIVO:
 * - Dice "cosa" fare, non "come"
 * - Reagisce ai cambiamenti dei dati
 * - Usa stream di dati immutabili
 */
@Component({
  selector: 'app-imperative-vs-reactive',
  imports: [CommonModule],
  templateUrl: './imperative-vs-reactive.html',
  styleUrl: './imperative-vs-reactive.scss',
})
export class ImperativeVsReactiveComponent {
  // Signal per il contatore imperativo (Angular 21 usa signal per lo stato)
  imperativeCounter = signal(0);

  // Signal per il contatore reattivo
  reactiveCounter = signal(0);

  // Array dei risultati per approccio imperativo
  imperativeResults = signal<number[]>([]);

  // Array dei risultati per approccio reattivo
  reactiveResults = signal<number[]>([]);

  /**
   * APPROCCIO IMPERATIVO
   * Incrementiamo manualmente il contatore usando setInterval
   * Dobbiamo gestire esplicitamente l'avvio, l'arresto e la pulizia
   */
  private imperativeInterval?: number;

  startImperative(): void {
    // Reset
    this.imperativeCounter.set(0);
    this.imperativeResults.set([]);

    // Cancella intervallo precedente se esiste
    if (this.imperativeInterval) {
      clearInterval(this.imperativeInterval);
    }

    // Crea un nuovo intervallo che incrementa il contatore ogni secondo
    this.imperativeInterval = window.setInterval(() => {
      // Leggiamo il valore corrente
      const current = this.imperativeCounter();

      // Calcoliamo il nuovo valore
      const newValue = current + 1;

      // Aggiorniamo il signal
      this.imperativeCounter.set(newValue);

      // Aggiorniamo l'array dei risultati
      const currentResults = this.imperativeResults();
      this.imperativeResults.set([...currentResults, newValue * 2]);

      // Fermiamo dopo 10 iterazioni
      if (newValue >= 10) {
        this.stopImperative();
      }
    }, 1000);
  }

  stopImperative(): void {
    if (this.imperativeInterval) {
      clearInterval(this.imperativeInterval);
      this.imperativeInterval = undefined;
    }
  }

  /**
   * APPROCCIO REATTIVO
   * Creiamo uno stream Observable che emette valori automaticamente
   * Il framework gestisce la sottoscrizione e la pulizia
   */
  startReactive(): void {
    // Reset
    this.reactiveCounter.set(0);
    this.reactiveResults.set([]);

    // Creiamo un Observable che emette un valore ogni secondo
    // interval(1000) = emette 0, 1, 2, 3... ogni 1000ms
    // take(10) = prende solo i primi 10 valori e poi completa automaticamente
    // map(n => n + 1) = trasforma ogni valore incrementandolo di 1
    interval(1000)
      .pipe(
        take(10), // Prendi solo 10 valori
        map((n) => n + 1), // Trasforma: 0->1, 1->2, etc.
      )
      .subscribe({
        next: (value) => {
          // Questo viene chiamato per ogni valore emesso
          this.reactiveCounter.set(value);

          // Aggiorniamo l'array dei risultati in modo reattivo
          this.reactiveResults.update((current) => [...current, value * 2]);
        },
        complete: () => {
          // Questo viene chiamato quando lo stream completa (dopo 10 emissioni)
          console.log('Stream reattivo completato automaticamente');
        },
      });

    // Nota: non abbiamo bisogno di gestire manualmente la pulizia!
    // L'Observable si completa da solo dopo 10 emissioni grazie a take(10)
  }

  /**
   * Pulizia alla distruzione del componente
   * Importante per evitare memory leak
   */
  ngOnDestroy(): void {
    this.stopImperative();
  }
}
