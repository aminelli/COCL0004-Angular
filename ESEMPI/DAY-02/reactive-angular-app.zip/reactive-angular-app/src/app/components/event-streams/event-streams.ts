import { Component, signal, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { fromEvent, merge, interval } from 'rxjs';
import { map, throttleTime, debounceTime, scan, takeUntil, Subject, filter } from 'rxjs';

/**
 * Componente che dimostra gli Stream di Eventi
 *
 * STREAM DI EVENTI:
 * - Sequenza di eventi che si verificano nel tempo
 * - Ogni evento è un punto nel tempo con un valore
 * - Possono essere trasformati, filtrati, combinati
 * - Rappresentati come Observable in RxJS
 */
@Component({
  selector: 'app-event-streams',
  imports: [CommonModule],
  templateUrl: './event-streams.html',
  styleUrl: './event-streams.scss'
})
export class EventStreamsComponent {
  // ViewChild per accedere agli elementi DOM
  @ViewChild('clickBox', { static: false }) clickBox?: ElementRef;
  @ViewChild('searchInput', { static: false }) searchInput?: ElementRef;

  // Signal per visualizzare i dati
  clickCount = signal(0);
  mousePosition = signal({ x: 0, y: 0 });
  searchQuery = signal('');
  throttledClicks = signal(0);
  debouncedSearch = signal('');
  timerValue = signal(0);

  // Array per lo storico degli eventi
  eventHistory = signal<string[]>([]);

  // Subject per gestire la pulizia
  private destroy$ = new Subject<void>();

  ngAfterViewInit(): void {
    this.setupClickStream();
    this.setupMouseMoveStream();
    this.setupSearchStream();
    this.setupThrottleExample();
    this.setupDebounceExample();
    this.setupMergedStreams();
  }

  /**
   * STREAM DI CLICK
   * Trasforma i click in un contatore
   */
  private setupClickStream(): void {
    if (!this.clickBox) return;

    // fromEvent crea un Observable dagli eventi DOM
    fromEvent<MouseEvent>(this.clickBox.nativeElement, 'click')
      .pipe(
        // scan accumula i valori come Array.reduce
        scan((count) => count + 1, 0),
        takeUntil(this.destroy$)
      )
      .subscribe(count => {
        this.clickCount.set(count);
        this.addToHistory(`Click #${count}`);
      });
  }

  /**
   * STREAM DI MOVIMENTO MOUSE
   * Traccia la posizione del mouse
   */
  private setupMouseMoveStream(): void {
    if (!this.clickBox) return;

    fromEvent<MouseEvent>(this.clickBox.nativeElement, 'mousemove')
      .pipe(
        // map trasforma ogni evento
        map(event => ({
          x: event.offsetX,
          y: event.offsetY
        })),
        // throttleTime limita la frequenza degli eventi (max uno ogni 100ms)
        throttleTime(100),
        takeUntil(this.destroy$)
      )
      .subscribe(position => {
        this.mousePosition.set(position);
      });
  }

  /**
   * STREAM DI INPUT RICERCA
   * Cattura ogni carattere digitato
   */
  private setupSearchStream(): void {
    if (!this.searchInput) return;

    fromEvent<Event>(this.searchInput.nativeElement, 'input')
      .pipe(
        map(event => (event.target as HTMLInputElement).value),
        takeUntil(this.destroy$)
      )
      .subscribe(value => {
        this.searchQuery.set(value);
        this.addToHistory(`Ricerca: "${value}"`);
      });
  }

  /**
   * THROTTLE EXAMPLE
   * Throttle: emette il primo evento, poi ignora gli altri per un periodo
   * Utile per: scroll, resize, mousemove
   */
  private setupThrottleExample(): void {
    if (!this.clickBox) return;

    fromEvent<MouseEvent>(this.clickBox.nativeElement, 'click')
      .pipe(
        throttleTime(2000), // Max un evento ogni 2 secondi
        scan((count) => count + 1, 0),
        takeUntil(this.destroy$)
      )
      .subscribe(count => {
        this.throttledClicks.set(count);
        this.addToHistory(`Click Throttled #${count} (max 1 ogni 2s)`);
      });
  }

  /**
   * DEBOUNCE EXAMPLE
   * Debounce: attende che gli eventi si fermino per un periodo
   * Utile per: ricerca, autocomplete, validazione
   */
  private setupDebounceExample(): void {
    if (!this.searchInput) return;

    fromEvent<Event>(this.searchInput.nativeElement, 'input')
      .pipe(
        map(event => (event.target as HTMLInputElement).value),
        // Attende 500ms di silenzio prima di emettere
        debounceTime(500),
        // Filtra valori vuoti
        filter(value => value.length > 0),
        takeUntil(this.destroy$)
      )
      .subscribe(value => {
        this.debouncedSearch.set(value);
        this.addToHistory(`Ricerca Debounced: "${value}"`);
      });
  }

  /**
   * MERGE DI STREAM
   * Combina più stream in uno solo
   */
  private setupMergedStreams(): void {
    // Stream di timer
    const timer$ = interval(1000).pipe(
      map(n => `Timer: ${n + 1}s`)
    );

    // Stream di click (se disponibile)
    const clicks$ = this.clickBox ?
      fromEvent(this.clickBox.nativeElement, 'click').pipe(
        map(() => 'Click!')
      ) :
      new Subject<string>(); // fallback se clickBox non è disponibile

    // Merge: combina entrambi gli stream
    merge(timer$, clicks$)
      .pipe(
        takeUntil(this.destroy$)
      )
      .subscribe(event => {
        if (event.startsWith('Timer:')) {
          const seconds = parseInt(event.split(':')[1]);
          this.timerValue.set(seconds);
        }
      });
  }

  /**
   * Aggiunge evento allo storico (max 10 eventi)
   */
  private addToHistory(event: string): void {
    this.eventHistory.update(history => {
      const newHistory = [event, ...history];
      return newHistory.slice(0, 10); // Mantieni solo gli ultimi 10
    });
  }

  resetHistory(): void {
    this.eventHistory.set([]);
    this.clickCount.set(0);
    this.throttledClicks.set(0);
  }

  ngOnDestroy(): void {
    // Completa tutti gli Observable per evitare memory leak
    this.destroy$.next();
    this.destroy$.complete();
  }
}
