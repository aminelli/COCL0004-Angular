import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, throwError, of, interval } from 'rxjs';
import { map, catchError, retry, retryWhen, delay, take, mergeMap } from 'rxjs/operators';

/**
 * Componente che dimostra la propagazione degli errori negli Observable
 * 
 * ERROR PROPAGATION:
 * - Gli errori terminano lo stream
 * - Possono essere catturati con catchError
 * - Possono essere ritentati con retry/retryWhen
 * - Si propagano lungo la catena di operatori
 */
@Component({
  selector: 'app-error-propagation',
  imports: [CommonModule],
  templateUrl: './error-propagation.html',
  styleUrl: './error-propagation.scss'
})
export class ErrorPropagationComponent {
  eventLog = signal<string[]>([]);
  values = signal<number[]>([]);
  errorMessage = signal<string>('');
  isComplete = signal(false);
  retryCount = signal(0);

  /**
   * Observable che emette errore dopo alcuni valori
   */
  private createErrorStream(): Observable<number> {
    return new Observable<number>(observer => {
      this.log('📡 Stream avviato');
      let count = 0;
      
      const intervalId = setInterval(() => {
        count++;
        
        if (count <= 3) {
          this.log(`✅ Emesso: ${count}`);
          observer.next(count);
        } else {
          // Errore dopo il terzo valore
          clearInterval(intervalId);
          this.log('❌ Errore generato!');
          observer.error(new Error('Errore simulato dopo 3 emissioni'));
        }
      }, 800);
      
      return () => {
        clearInterval(intervalId);
        this.log('🧹 Cleanup eseguito');
      };
    });
  }

  /**
   * SENZA gestione errori - lo stream termina
   */
  demonstrateUnhandledError(): void {
    this.reset();
    this.log('🏁 Demo: Errore NON gestito');
    
    this.createErrorStream().subscribe({
      next: (value) => {
        this.log(`📥 Ricevuto: ${value}`);
        this.values.update(arr => [...arr, value]);
      },
      error: (err) => {
        this.log(`💥 Errore ricevuto: ${err.message}`);
        this.log('⚠️ Lo stream è terminato!');
        this.errorMessage.set(err.message);
      },
      complete: () => {
        this.log('✅ Completato');
        this.isComplete.set(true);
      }
    });
  }

  /**
   * CON catchError - gestisce l'errore e continua con valore di fallback
   */
  demonstrateCatchError(): void {
    this.reset();
    this.log('🏁 Demo: catchError - gestione con fallback');
    
    this.createErrorStream().pipe(
      catchError(err => {
        this.log(`🛡️ Errore catturato con catchError: ${err.message}`);
        this.log('🔄 Ritorno stream di fallback');
        this.errorMessage.set(`Gestito: ${err.message}`);
        
        // Ritorna un Observable di fallback
        return of(999);  // Emette 999 e completa
      })
    ).subscribe({
      next: (value) => {
        this.log(`📥 Ricevuto: ${value}`);
        this.values.update(arr => [...arr, value]);
      },
      error: (err) => {
        // Non dovrebbe mai arrivare qui
        this.log(`💥 Errore: ${err.message}`);
      },
      complete: () => {
        this.log('✅ Stream completato con successo');
        this.isComplete.set(true);
      }
    });
  }

  /**
   * CON retry - riprova automaticamente N volte
   */
  demonstrateRetry(): void {
    this.reset();
    this.log('🏁 Demo: retry(2) - riprova 2 volte');
    let attemptNumber = 0;
    
    // Observable che fallisce sempre per dimostrare retry
    const failingStream$ = new Observable<number>(observer => {
      attemptNumber++;
      this.retryCount.set(attemptNumber);
      this.log(`🔄 Tentativo #${attemptNumber}`);
      
      observer.next(attemptNumber);
      
      setTimeout(() => {
        this.log(`❌ Errore al tentativo #${attemptNumber}`);
        observer.error(new Error(`Errore tentativo ${attemptNumber}`));
      }, 500);
    });
    
    failingStream$.pipe(
      retry(2)  // Riprova 2 volte (totale 3 tentativi)
    ).subscribe({
      next: (value) => {
        this.log(`📥 Ricevuto: ${value}`);
        this.values.update(arr => [...arr, value]);
      },
      error: (err) => {
        this.log('💥 Tutti i tentativi falliti!');
        this.errorMessage.set('Fallito dopo 3 tentativi');
      },
      complete: () => {
        this.log('✅ Completato');
        this.isComplete.set(true);
      }
    });
  }

  /**
   * CON retryWhen - riprova con logica personalizzata
   */
  demonstrateRetryWhen(): void {
    this.reset();
    this.log('🏁 Demo: retryWhen - con delay incrementale');
    let attemptNumber = 0;
    
    const failingStream$ = new Observable<number>(observer => {
      attemptNumber++;
      this.retryCount.set(attemptNumber);
      this.log(`🔄 Tentativo #${attemptNumber}`);
      
      if (attemptNumber < 3) {
        observer.next(attemptNumber);
        setTimeout(() => {
          this.log(`❌ Errore - riprovo tra ${attemptNumber}s...`);
          observer.error(new Error(`Errore ${attemptNumber}`));
        }, 500);
      } else {
        // Successo al terzo tentativo
        observer.next(attemptNumber);
        this.log('✅ Successo!');
        observer.complete();
      }
    });
    
    failingStream$.pipe(
      retryWhen(errors => 
        errors.pipe(
          mergeMap((error, index) => {
            if (index >= 2) {
              // Dopo 2 retry, propaga l'errore
              this.log('❌ Troppi tentativi');
              return throwError(() => error);
            }
            // Delay incrementale: 1s, 2s
            const delayMs = (index + 1) * 1000;
            this.log(`⏱️ Attendo ${delayMs}ms prima del retry...`);
            return of(error).pipe(delay(delayMs));
          })
        )
      )
    ).subscribe({
      next: (value) => {
        this.log(`📥 Ricevuto: ${value}`);
        this.values.update(arr => [...arr, value]);
      },
      error: (err) => {
        this.log(`💥 Errore finale: ${err.message}`);
        this.errorMessage.set('Fallito definitivamente');
      },
      complete: () => {
        this.log('✅ Completato con successo!');
        this.isComplete.set(true);
      }
    });
  }

  /**
   * Log helper
   */
  private log(message: string): void {
    const timestamp = new Date().toLocaleTimeString();
    this.eventLog.update(log => [`[${timestamp}] ${message}`, ...log].slice(0, 20));
  }

  reset(): void {
    this.values.set([]);
    this.errorMessage.set('');
    this.isComplete.set(false);
    this.retryCount.set(0);
    this.eventLog.set([]);
  }
}
