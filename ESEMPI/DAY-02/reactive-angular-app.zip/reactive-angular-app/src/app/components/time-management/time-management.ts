import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { interval, timer, Subject } from 'rxjs';
import {
  debounceTime, throttleTime, delay, timeout,
  sampleTime, auditTime, bufferTime, takeUntil, map, take
} from 'rxjs/operators';

/**
 * Componente che dimostra la gestione del tempo nei flussi reattivi
 *
 * Gli operatori temporali permettono di controllare QUANDO e COME
 * i valori fluiscono attraverso lo stream.
 */
@Component({
  selector: 'app-time-management',
  imports: [CommonModule],
  templateUrl: './time-management.html',
  styleUrl: './time-management.scss'
})
export class TimeManagementComponent {
  // Signal per visualizzare i risultati
  originalValues = signal<number[]>([]);
  debounceValues = signal<number[]>([]);
  throttleValues = signal<number[]>([]);
  sampleValues = signal<number[]>([]);
  auditValues = signal<number[]>([]);
  bufferValues = signal<number[][]>([]);
  delayValues = signal<number[]>([]);

  eventLog = signal<string[]>([]);
  isRunning = signal(false);

  // Subject per input manuale
  private inputSubject = new Subject<number>();
  private destroy$ = new Subject<void>();

  /**
   * DEBOUNCE: Attende che gli eventi si fermino per X ms
   * Utile per: ricerca, autocomplete, validazione input
   */
  demonstrateDebounce(): void {
    this.reset();
    this.isRunning.set(true);
    this.log('🏁 Inizio demo DEBOUNCE (500ms)');

    // Stream veloce che emette ogni 200ms
    const source$ = interval(200).pipe(
      takeUntil(this.destroy$),
      map(n => n + 1)
    );

    // Stream originale
    source$.subscribe(value => {
      this.log(`⚡ Emesso: ${value}`);
      this.originalValues.update(arr => [...arr, value]);
    });

    // Con debounce: emette solo dopo 500ms di silenzio
    // Siccome emettiamo ogni 200ms, non ci sarà mai silenzio!
    // Fermiamo dopo 2 secondi per vedere l'effetto
    setTimeout(() => {
      this.log('⏸️ Fermato! Ora debounce può emettere...');
      this.destroy$.next();
    }, 2000);

    source$.pipe(
      debounceTime(500)
    ).subscribe(value => {
      this.log(`🎯 Debounce emesso: ${value}`);
      this.debounceValues.update(arr => [...arr, value]);
    });

    setTimeout(() => this.isRunning.set(false), 2500);
  }

  /**
   * THROTTLE: Limita la frequenza a max uno ogni X ms
   * Utile per: scroll, resize, mousemove
   */
  demonstrateThrottle(): void {
    this.reset();
    this.isRunning.set(true);
    this.log('🏁 Inizio demo THROTTLE (1000ms)');

    // Stream veloce
    const source$ = interval(200).pipe(
      takeUntil(timer(3000)),
      map(n => n + 1)
    );

    source$.subscribe(value => {
      this.log(`⚡ Emesso: ${value}`);
      this.originalValues.update(arr => [...arr, value]);
    });

    // Con throttle: max uno ogni 1000ms
    source$.pipe(
      throttleTime(1000)
    ).subscribe(value => {
      this.log(`🎯 Throttle emesso: ${value}`);
      this.throttleValues.update(arr => [...arr, value]);
    });

    setTimeout(() => this.isRunning.set(false), 3500);
  }

  /**
   * SAMPLE: Emette l'ultimo valore a intervalli regolari
   * Simile a throttle ma sempre preciso nell'intervallo
   */
  demonstrateSample(): void {
    this.reset();
    this.isRunning.set(true);
    this.log('🏁 Inizio demo SAMPLE (800ms)');

    const source$ = interval(150).pipe(
      takeUntil(timer(3000)),
      map(n => n + 1)
    );

    source$.subscribe(value => {
      this.log(`⚡ Emesso: ${value}`);
      this.originalValues.update(arr => [...arr, value]);
    });

    // Sample: prende l'ultimo valore ogni 800ms
    source$.pipe(
      sampleTime(800)
    ).subscribe(value => {
      this.log(`📸 Sample emesso: ${value}`);
      this.sampleValues.update(arr => [...arr, value]);
    });

    setTimeout(() => this.isRunning.set(false), 3500);
  }

  /**
   * AUDIT: Emette un valore, poi ignora per X ms
   * Prima emissione passa, poi pausa
   */
  demonstrateAudit(): void {
    this.reset();
    this.isRunning.set(true);
    this.log('🏁 Inizio demo AUDIT (1000ms)');

    const source$ = interval(200).pipe(
      takeUntil(timer(3000)),
      map(n => n + 1)
    );

    source$.subscribe(value => {
      this.log(`⚡ Emesso: ${value}`);
      this.originalValues.update(arr => [...arr, value]);
    });

    // Audit: emette, poi ignora per 1000ms
    source$.pipe(
      auditTime(1000)
    ).subscribe(value => {
      this.log(`🔇 Audit emesso: ${value}`);
      this.auditValues.update(arr => [...arr, value]);
    });

    setTimeout(() => this.isRunning.set(false), 3500);
  }

  /**
   * BUFFER: Accumula valori per X ms, poi emette array
   * Utile per: batch processing
   */
  demonstrateBuffer(): void {
    this.reset();
    this.isRunning.set(true);
    this.log('🏁 Inizio demo BUFFER (1000ms)');

    const source$ = interval(200).pipe(
      takeUntil(timer(3500)),
      map(n => n + 1)
    );

    source$.subscribe(value => {
      this.log(`⚡ Emesso: ${value}`);
      this.originalValues.update(arr => [...arr, value]);
    });

    // Buffer: accumula per 1000ms, poi emette array
    source$.pipe(
      bufferTime(1000)
    ).subscribe(buffer => {
      this.log(`📦 Buffer emesso: [${buffer.join(', ')}]`);
      this.bufferValues.update(arr => [...arr, buffer]);
    });

    setTimeout(() => this.isRunning.set(false), 4000);
  }

  /**
   * DELAY: Ritarda ogni valore di X ms
   * Sposta tutto lo stream avanti nel tempo
   */
  demonstrateDelay(): void {
    this.reset();
    this.isRunning.set(true);
    this.log('🏁 Inizio demo DELAY (1000ms)');

    const source$ = interval(500).pipe(
      take(5),
      map((n: number) => n + 1)
    );

    source$.subscribe(value => {
      this.log(`⚡ Emesso: ${value}`);
      this.originalValues.update(arr => [...arr, value]);
    });

    // Con delay: ogni valore ritardato di 1000ms
    source$.pipe(
      delay(1000)
    ).subscribe(value => {
      this.log(`⏰ Delayed emesso: ${value}`);
      this.delayValues.update(arr => [...arr, value]);
    });

    setTimeout(() => this.isRunning.set(false), 4000);
  }

  /**
   * Log helper
   */
  private log(message: string): void {
    const timestamp = new Date().toLocaleTimeString();
    this.eventLog.update(log => [`[${timestamp}] ${message}`, ...log].slice(0, 25));
  }

  reset(): void {
    this.destroy$.next();
    this.originalValues.set([]);
    this.debounceValues.set([]);
    this.throttleValues.set([]);
    this.sampleValues.set([]);
    this.auditValues.set([]);
    this.bufferValues.set([]);
    this.delayValues.set([]);
    this.eventLog.set([]);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
