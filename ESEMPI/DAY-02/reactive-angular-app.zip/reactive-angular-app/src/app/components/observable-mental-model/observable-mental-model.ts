import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, Observer } from 'rxjs';

/**
 * Componente che spiega il modello mentale degli Observable
 * 
 * OBSERVABLE: Una "ricetta" per produrre valori
 * - Non è il valore stesso, ma come ottenerlo
 * - Lazy: non fa nulla finché qualcuno si sottoscrive
 * - Può produrre: 0, 1 o molti valori nel tempo
 * - Può completare o andare in errore
 * 
 * CONTRACT: next* (error | complete)?
 * - Zero o più notifiche "next"
 * - Seguita da UNA notifica "error" O "complete" (opzionale)
 */
@Component({
  selector: 'app-observable-mental-model',
  imports: [CommonModule],
  templateUrl: './observable-mental-model.html',
  styleUrl: './observable-mental-model.scss'
})
export class ObservableMentalModelComponent {
  // Signal per visualizzare lo stato
  nextValues = signal<number[]>([]);
  errorMessage = signal<string>('');
  completionMessage = signal<string>('');
  isSubscribed = signal(false);
  
  // Log degli eventi
  eventLog = signal<string[]>([]);

  /**
   * Observable creato manualmente usando il costruttore
   * Questo è il modo più "puro" per capire come funziona
   */
  createSimpleObservable(): Observable<number> {
    return new Observable<number>((observer: Observer<number>) => {
      this.log('🔧 Observable creato (ma non ancora eseguito)');
      
      // Questo codice viene eseguito SOLO quando qualcuno si sottoscrive
      this.log('▶️ Subscriber connesso! Inizio emissione...');
      
      let count = 0;
      const intervalId = setInterval(() => {
        count++;
        
        // next(): invia il prossimo valore
        this.log(`📤 next(${count})`);
        observer.next(count);
        
        // Dopo 5 emissioni, completa
        if (count >= 5) {
          clearInterval(intervalId);
          
          // complete(): segnala che non ci saranno più valori
          this.log('✅ complete()');
          observer.complete();
        }
      }, 1000);
      
      // Teardown function: viene chiamata quando ci si unsubscribe
      return () => {
        this.log('🧹 Cleanup: cancellazione interval');
        clearInterval(intervalId);
      };
    });
  }

  /**
   * Observable che emette un errore
   */
  createErrorObservable(): Observable<number> {
    return new Observable<number>((observer: Observer<number>) => {
      this.log('▶️ Observable di errore avviato');
      
      let count = 0;
      const intervalId = setInterval(() => {
        count++;
        
        if (count < 3) {
          this.log(`📤 next(${count})`);
          observer.next(count);
        } else {
          // error(): segnala un errore e termina lo stream
          clearInterval(intervalId);
          this.log('❌ error("Errore simulato dopo 3 emissioni")');
          observer.error('Errore simulato dopo 3 emissioni');
        }
      }, 800);
      
      return () => {
        clearInterval(intervalId);
      };
    });
  }

  /**
   * Sottoscrizione a un Observable semplice
   */
  subscribeToSimple(): void {
    this.reset();
    this.isSubscribed.set(true);
    
    const observable$ = this.createSimpleObservable();
    this.log('📝 Chiamata a subscribe()...');
    
    observable$.subscribe({
      next: (value) => {
        this.log(`📥 Ricevuto: ${value}`);
        this.nextValues.update(values => [...values, value]);
      },
      error: (err) => {
        this.log(`❌ Errore ricevuto: ${err}`);
        this.errorMessage.set(err);
        this.isSubscribed.set(false);
      },
      complete: () => {
        this.log('✅ Completamento ricevuto');
        this.completionMessage.set('Observable completato con successo!');
        this.isSubscribed.set(false);
      }
    });
  }

  /**
   * Sottoscrizione a un Observable che genera errore
   */
  subscribeToError(): void {
    this.reset();
    this.isSubscribed.set(true);
    
    const observable$ = this.createErrorObservable();
    this.log('📝 Sottoscrizione a Observable di errore...');
    
    observable$.subscribe({
      next: (value) => {
        this.log(`📥 Ricevuto: ${value}`);
        this.nextValues.update(values => [...values, value]);
      },
      error: (err) => {
        this.log(`❌ Errore ricevuto: ${err}`);
        this.errorMessage.set(err);
        this.isSubscribed.set(false);
      },
      complete: () => {
        // Questo non verrà mai chiamato perché c'è un errore
        this.log('✅ Completamento ricevuto');
        this.completionMessage.set('Observable completato');
        this.isSubscribed.set(false);
      }
    });
  }

  /**
   * Dimostra che l'Observable è Lazy
   * Non succede nulla finché non ci si sottoscrive
   */
  demonstrateLaziness(): void {
    this.reset();
    
    this.log('🔧 Creazione Observable...');
    const observable$ = this.createSimpleObservable();
    
    this.log('⏸️ Observable creato ma NON sottoscritto');
    this.log('❓ Succede qualcosa? NO! È lazy!');
    
    setTimeout(() => {
      this.log('⏱️ Attendiamo 2 secondi...');
      setTimeout(() => {
        this.log('📝 Ora sottoscriviamoci!');
        this.isSubscribed.set(true);
        
        observable$.subscribe({
          next: (value) => {
            this.log(`📥 Ricevuto: ${value}`);
            this.nextValues.update(values => [...values, value]);
          },
          complete: () => {
            this.log('✅ Completato!');
            this.completionMessage.set('Lazy Observable completato!');
            this.isSubscribed.set(false);
          }
        });
      }, 2000);
    }, 100);
  }

  /**
   * Aggiunge un log all'event log
   */
  private log(message: string): void {
    const timestamp = new Date().toLocaleTimeString();
    this.eventLog.update(log => [`[${timestamp}] ${message}`, ...log].slice(0, 15));
  }

  /**
   * Reset dello stato
   */
  reset(): void {
    this.nextValues.set([]);
    this.errorMessage.set('');
    this.completionMessage.set('');
    this.eventLog.set([]);
    this.isSubscribed.set(false);
  }
}
