import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { interval } from 'rxjs';
import { map, takeWhile } from 'rxjs/operators';

/**
 * Componente che dimostra la Reactive UI usando Signal di Angular 21
 * 
 * REACTIVE UI:
 * - L'UI reagisce automaticamente ai cambiamenti dello stato
 * - Nessun binding manuale o update esplicito
 * - Usa Signal e computed per derivare stato
 * - Unidirezionale: stato -> UI
 */
@Component({
  selector: 'app-reactive-ui',
  imports: [CommonModule, FormsModule],
  templateUrl: './reactive-ui.html',
  styleUrl: './reactive-ui.scss'
})
export class ReactiveUiComponent {
  // SIGNAL: Stato reattivo base
  firstName = signal('Mario');
  lastName = signal('Rossi');
  age = signal(25);
  salary = signal(30000);
  
  // COMPUTED: Stato derivato automaticamente
  // Si aggiorna automaticamente quando firstName o lastName cambiano
  fullName = computed(() => `${this.firstName()} ${this.lastName()}`);
  
  // Computed: categoria età
  ageCategory = computed(() => {
    const currentAge = this.age();
    if (currentAge < 18) return 'Minorenne';
    if (currentAge < 30) return 'Giovane';
    if (currentAge < 50) return 'Adulto';
    return 'Senior';
  });
  
  // Computed: tasse (progressive)
  taxes = computed(() => {
    const sal = this.salary();
    if (sal < 15000) return sal * 0.23;
    if (sal < 28000) return sal * 0.27;
    if (sal < 55000) return sal * 0.38;
    return sal * 0.43;
  });
  
  // Computed: stipendio netto
  netSalary = computed(() => this.salary() - this.taxes());
  
  // Lista di prodotti con quantità
  products = signal([
    { id: 1, name: 'Laptop', price: 1200, quantity: signal(0) },
    { id: 2, name: 'Mouse', price: 25, quantity: signal(0) },
    { id: 3, name: 'Tastiera', price: 75, quantity: signal(0) },
    { id: 4, name: 'Monitor', price: 300, quantity: signal(0) }
  ]);
  
  // Computed: totale carrello
  cartTotal = computed(() => {
    return this.products().reduce((sum, product) => {
      return sum + (product.price * product.quantity());
    }, 0);
  });
  
  // Computed: numero items
  cartItemsCount = computed(() => {
    return this.products().reduce((sum, product) => sum + product.quantity(), 0);
  });
  
  // Stato del timer
  timerRunning = signal(false);
  currentTime = signal(0);
  
  /**
   * Incrementa quantità prodotto
   */
  incrementProduct(productId: number): void {
    const product = this.products().find(p => p.id === productId);
    if (product) {
      product.quantity.update(q => q + 1);
    }
  }
  
  /**
   * Decrementa quantità prodotto
   */
  decrementProduct(productId: number): void {
    const product = this.products().find(p => p.id === productId);
    if (product && product.quantity() > 0) {
      product.quantity.update(q => q - 1);
    }
  }
  
  /**
   * Reset carrello
   */
  resetCart(): void {
    this.products().forEach(p => p.quantity.set(0));
  }
  
  /**
   * Avvia timer reattivo
   */
  startTimer(): void {
    this.timerRunning.set(true);
    this.currentTime.set(0);
    
    interval(1000).pipe(
      takeWhile(() => this.timerRunning()),
      map((n) => n + 1)
    ).subscribe(time => {
      this.currentTime.set(time);
    });
  }
  
  /**
   * Ferma timer
   */
  stopTimer(): void {
    this.timerRunning.set(false);
  }
}
