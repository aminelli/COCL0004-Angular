import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, Subject, interval, share } from 'rxjs';
import { take, map } from 'rxjs/operators';

/**
 * Componente che dimostra la differenza tra Cold e Hot Observable
 * 
 * COLD OBSERVABLE (Unicast):
 * - Ogni sottoscrizione crea una nuova esecuzione indipendente
 * - Il producer è creato dentro l'Observable
 * - Ogni subscriber riceve la propria sequenza privata
 * - Esempio: HTTP request, timer creato al subscribe
 * 
 * HOT OBSERVABLE (Multicast):
 * - Condivide la stessa esecuzione tra tutti i subscriber
 * - Il producer esiste fuori dall'Observable
 * - Tutti i subscriber ricevono gli stessi valori
 * - Esempio: eventi DOM, Subject, WebSocket condiviso
 */
@Component({
  selector: 'app-cold-vs-hot',
  imports: [CommonModule],
  templateUrl: './cold-vs-hot.html',
  styleUrl: './cold-vs-hot.scss'
})
export class ColdVsHotComponent {
  // Signal per Cold Observable
  coldSubscriber1 = signal<number[]>([]);
  coldSubscriber2 = signal<number[]>([]);
  
  // Signal per Hot Observable
  hotSubscriber1 = signal<number[]>([]);
  hotSubscriber2 = signal<number[]>([]);
  
  // Signal per Subject (sempre Hot)
  subjectSubscriber1 = signal<number[]>([]);
  subjectSubscriber2 = signal<number[]>([]);
  
  // Stato
  currentSubjectValue = signal<number | null>(null);
  eventLog = signal<string[]>([]);

  /**
   * COLD OBSERVABLE EXAMPLE
   * Ogni subscriber ottiene la propria esecuzione indipendente
   */
  demonstrateCold(): void {
    this.reset();
    this.log('🥶 Creazione Cold Observable...');
    
    // Cold Observable: il producer (interval) viene creato per ogni subscriber
    const cold$ = new Observable<number>(observer => {
      this.log('🔵 Nuova esecuzione creata per un subscriber!');
      let count = 0;
      
      const intervalId = setInterval(() => {
        count++;
        observer.next(count);
        
        if (count >= 5) {
          clearInterval(intervalId);
          observer.complete();
        }
      }, 1000);
      
      return () => clearInterval(intervalId);
    });

    // Primo subscriber
    this.log('👤 Subscriber 1 si connette...');
    cold$.subscribe(value => {
      this.log(`👤 Subscriber 1 riceve: ${value}`);
      this.coldSubscriber1.update(arr => [...arr, value]);
    });

    // Secondo subscriber dopo 2.5 secondi
    setTimeout(() => {
      this.log('👤 Subscriber 2 si connette (2.5s dopo)...');
      cold$.subscribe(value => {
        this.log(`👥 Subscriber 2 riceve: ${value}`);
        this.coldSubscriber2.update(arr => [...arr, value]);
      });
    }, 2500);
  }

  /**
   * HOT OBSERVABLE EXAMPLE
   * Tutti i subscriber condividono la stessa esecuzione
   */
  demonstrateHot(): void {
    this.reset();
    this.log('🔥 Creazione Hot Observable (con share)...');
    
    // Cold Observable base
    const cold$ = interval(1000).pipe(
      take(8),
      map(n => n + 1)
    );
    
    // Trasformato in Hot con share()
    // share() = multicast + refCount + auto-cleanup
    const hot$ = cold$.pipe(share());
    
    this.log('🔴 Una singola esecuzione condivisa!');

    // Primo subscriber
    this.log('👤 Subscriber 1 si connette...');
    hot$.subscribe(value => {
      this.log(`👤 Subscriber 1 riceve: ${value}`);
      this.hotSubscriber1.update(arr => [...arr, value]);
    });

    // Secondo subscriber dopo 2.5 secondi
    setTimeout(() => {
      this.log('👥 Subscriber 2 si connette (2.5s dopo)...');
      hot$.subscribe(value => {
        this.log(`👥 Subscriber 2 riceve: ${value}`);
        this.hotSubscriber2.update(arr => [...arr, value]);
      });
    }, 2500);
  }

  /**
   * SUBJECT EXAMPLE
   * Un Subject è sempre Hot e può sia emettere che ricevere
   */
  demonstrateSubject(): void {
    this.reset();
    this.log('📢 Creazione Subject (sempre Hot)...');
    
    const subject$ = new Subject<number>();
    
    // Primo subscriber
    this.log('👤 Subscriber 1 si connette al Subject...');
    subject$.subscribe(value => {
      this.log(`👤 Subscriber 1 riceve: ${value}`);
      this.subjectSubscriber1.update(arr => [...arr, value]);
    });

    // Emetti alcuni valori
    let count = 0;
    const intervalId = setInterval(() => {
      count++;
      this.currentSubjectValue.set(count);
      this.log(`📤 Subject emette: ${count}`);
      subject$.next(count);
      
      if (count >= 8) {
        clearInterval(intervalId);
        subject$.complete();
        this.log('✅ Subject completato');
      }
    }, 1000);

    // Secondo subscriber dopo 2.5 secondi
    setTimeout(() => {
      this.log('👥 Subscriber 2 si connette al Subject (2.5s dopo)...');
      this.log('⚠️ Subscriber 2 perde i valori già emessi!');
      subject$.subscribe(value => {
        this.log(`👥 Subscriber 2 riceve: ${value}`);
        this.subjectSubscriber2.update(arr => [...arr, value]);
      });
    }, 2500);
  }

  /**
   * Log helper
   */
  private log(message: string): void {
    const timestamp = new Date().toLocaleTimeString();
    this.eventLog.update(log => [`[${timestamp}] ${message}`, ...log].slice(0, 30));
  }

  /**
   * Reset
   */
  reset(): void {
    this.coldSubscriber1.set([]);
    this.coldSubscriber2.set([]);
    this.hotSubscriber1.set([]);
    this.hotSubscriber2.set([]);
    this.subjectSubscriber1.set([]);
    this.subjectSubscriber2.set([]);
    this.currentSubjectValue.set(null);
    this.eventLog.set([]);
  }
}
