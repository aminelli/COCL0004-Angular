import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { interval, Subject } from 'rxjs';
import { take } from 'rxjs/operators';

/**
 * Componente che dimostra la differenza tra Push e Pull
 *
 * PULL (Tradizionale):
 * - Il consumer "tira" i dati quando ne ha bisogno
 * - Esempio: chiamare una funzione, leggere una variabile
 * - Il consumer controlla QUANDO ricevere i dati
 *
 * PUSH (Reattivo):
 * - Il producer "spinge" i dati al consumer
 * - Esempio: Eventi, Observable, Promise
 * - Il producer controlla QUANDO inviare i dati
 */
@Component({
  selector: 'app-push-vs-pull',
  imports: [CommonModule],
  templateUrl: './push-vs-pull.html',
  styleUrl: './push-vs-pull.scss'
})
export class PushVsPullComponent {
  // Signal per i dati Pull
  pullData = signal<number[]>([]);
  pullValue = signal<number | null>(null);

  // Signal per i dati Push
  pushData = signal<number[]>([]);
  pushValue = signal<number | null>(null);

  // Subject per simulare eventi push
  private dataSubject = new Subject<number>();

  /**
   * PULL EXAMPLE
   * Array statico che il consumer può "tirare" quando vuole
   */
  private staticDataSource = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

  /**
   * Modello PULL: il consumer richiede i dati
   * Noi decidiamo quando e quali dati ottenere
   */
  pullDataExample(): void {
    // Il consumer decide QUANDO ottenere i dati
    const index = this.pullData().length;

    if (index < this.staticDataSource.length) {
      // "Tiriamo" il dato dalla sorgente
      const value = this.staticDataSource[index];

      // Aggiorniamo lo stato
      this.pullValue.set(value);
      this.pullData.update(current => [...current, value]);
    } else {
      alert('Tutti i dati sono stati estratti!');
    }
  }

  resetPull(): void {
    this.pullData.set([]);
    this.pullValue.set(null);
  }

  /**
   * Modello PUSH: il producer invia i dati
   * Il producer decide QUANDO inviare i dati
   */
  pushDataExample(): void {
    // Reset
    this.pushData.set([]);
    this.pushValue.set(null);

    // Il producer (interval) decide quando inviare i dati
    // Noi non possiamo controllare il timing, solo reagire
    interval(800)  // Emette ogni 800ms
      .pipe(
        take(10)  // Prende 10 valori
      )
      .subscribe({
        next: (index) => {
          // Il dato viene "spinto" a noi quando il producer decide
          const value = (index + 1) * 10;

          // Reagiamo al dato ricevuto
          this.pushValue.set(value);
          this.pushData.update(current => [...current, value]);
        },
        complete: () => {
          console.log('Push stream completato');
        }
      });
  }

  /**
   * PUSH con Subject (eventi personalizzati)
   * Un Subject può sia ricevere che emettere valori
   */
  pushCustomEvent(): void {
    // Generiamo un valore casuale
    const randomValue = Math.floor(Math.random() * 100);

    // "Spingiamo" il valore nello stream
    this.dataSubject.next(randomValue);
  }

  ngOnInit(): void {
    // Sottoscriviamo al Subject per ricevere eventi push
    this.dataSubject.subscribe((value) => {
      console.log('Ricevuto evento push:', value);
      this.pushValue.set(value);
      this.pushData.update(current => [...current, value]);
    });
  }
}
