# Storage Best Practices in Angular 21

Progetto demo Angular 21 (Standalone + SSR + Zoneless + Signals) che mostra in modo pratico come usare le principali soluzioni di persistenza lato browser seguendo best practices moderne.

## Obiettivo del progetto

Questa applicazione è una guida pratica su:

- localStorage
- sessionStorage
- IndexedDB (API nativa)
- Dexie.js
- idb
- ngrx-store-localstorage
- Cache Storage API

L'interfaccia è responsive con Bootstrap 5 e ogni sezione contiene esempi funzionanti.

## Stack tecnico

- Angular CLI: 21.1.4
- Angular: 21 (Standalone, SSR, Zoneless)
- TypeScript
- SCSS
- Bootstrap 5
- NgRx Store + `ngrx-store-localstorage`
- IndexedDB wrappers: `dexie`, `idb`

## Avvio rapido

Installazione dipendenze:

```bash
npm install
```

Avvio in sviluppo:

```bash
npm start
```

Build (browser + server SSR):

```bash
npm run build
```

Test unitari:

```bash
npm test -- --watch=false
```

## Architettura storage

La logica di persistenza è incapsulata in servizi dedicati:

- `src/app/services/browser-storage.service.ts`
	- Gestisce localStorage/sessionStorage con serializzazione JSON.
	- Include guardie SSR-safe (`isPlatformBrowser`).

- `src/app/services/indexeddb-native.service.ts`
	- Implementazione diretta dell'API IndexedDB.
	- Mostra come aprire DB, creare object store e gestire transazioni.

- `src/app/services/indexeddb-dexie.service.ts`
	- Wrapper Dexie.js per semplificare CRUD e schema.

- `src/app/services/indexeddb-idb.service.ts`
	- Wrapper `idb` con API Promise-based tipizzata.

- `src/app/services/cache-storage.service.ts`
	- Esempio di uso Cache Storage con `Request`/`Response`.

La UI demo è in:

- `src/app/app.ts`
- `src/app/app.html`
- `src/app/app.scss`

## NgRx persistence con localStorage

La persistenza dello stato è configurata con meta-reducer:

- `src/app/store/storage.reducer.ts`
	- `localStorageSync` abilitato solo in browser.
	- `rehydrate: true` per ripristino automatico al refresh.

- `src/app/app.config.ts`
	- `provideStore(...)` con feature `storage`.

Feature state demo:

- counter numerico
- note testuali persistite

## Best practices (riassunto operativo)

1. **Non salvare dati sensibili** (token/access credentials) in storage accessibile da JavaScript.
2. **Incapsulare sempre l'accesso storage in servizi**: migliora testabilità, manutenzione e compatibilità SSR.
3. **Scegliere lo storage in base al caso d'uso**:
	 - localStorage: preferenze semplici e non sensibili.
	 - sessionStorage: dati temporanei di sessione/tab.
	 - IndexedDB: dataset grandi, query e strutture complesse.
	 - Cache Storage: caching risorse/response HTTP.
4. **Versionare lo schema IndexedDB** (upgrade controllati).
5. **Persistenza NgRx selettiva**: sincronizzare solo slice necessarie e non sensibili.
6. **Gestire fallback browser/server** per evitare errori SSR/prerender.

## Confronto rapido soluzioni

| Soluzione | Pro | Contro | Quando usarla |
|---|---|---|---|
| localStorage | Semplice, immediata | Solo stringhe, sync API, limite spazio | Preferenze UI leggere |
| sessionStorage | Isolata per tab/sessione | Perde dati a fine sessione | Stato temporaneo sessione |
| IndexedDB nativo | Potente e standard | API verbosa | Controllo totale senza librerie |
| Dexie.js | API ergonomica, produttiva | Dipendenza extra | App con molte operazioni su IndexedDB |
| idb | Leggera e tipizzata | Meno “high-level” di Dexie | Wrapper minimale e moderno |
| ngrx-store-localstorage | Persistenza store rapida | Usa localStorage (limiti sicurezza/dimensione) | Rehydrate di stato non sensibile |
| Cache Storage | Ottima per cache response | Semantica diversa da key-value classico | Strategie cache con SW/PWA |

## Note importanti su warning build

Durante la build possono apparire warning non bloccanti:

- superamento budget iniziale bundle (dovuto a Bootstrap + librerie demo)
- dipendenza CommonJS transitiva (`deepmerge` da `ngrx-store-localstorage`)

Sono warning attesi in un progetto didattico; la build termina correttamente.

## Comando usato per creare il progetto

```bash
ng new storage-best-practices --skip-git --style=scss --routing --ssr --standalone --zoneless --defaults
```

## Possibili estensioni didattiche

- cifratura applicativa dei payload non sensibili prima del salvataggio
- invalidazione TTL per record localStorage/sessionStorage
- migrazioni versionate avanzate IndexedDB
- integrazione Service Worker reale con strategie cache-first/network-first

## Checklist produzione

### Sicurezza

- [ ] Evitare il salvataggio di token di accesso o segreti in localStorage/sessionStorage.
- [ ] Applicare policy CSP severe e sanitizzazione input per ridurre rischi XSS.
- [ ] Limitare la persistenza ai soli dati realmente necessari.
- [ ] Valutare cifratura applicativa dei dati non sensibili ma riservati.

### Robustezza dati

- [ ] Gestire `try/catch` su serializzazione/deserializzazione JSON.
- [ ] Definire schema versionato per IndexedDB e procedure di migrazione.
- [ ] Introdurre meccanismi di invalidazione (TTL, version tag, cleanup periodico).
- [ ] Implementare fallback graceful quando una tecnologia storage non è disponibile.

### Limiti e performance

- [ ] Monitorare quota disponibile per origin e intercettare errori di tipo `QuotaExceededError`.
- [ ] Usare IndexedDB per payload medio/grande invece di localStorage.
- [ ] Evitare operazioni sincrone intensive su localStorage nel rendering critico.
- [ ] Ridurre il volume persistito nello store NgRx (persistenza selettiva per slice).

### Compatibilità browser e SSR

- [ ] Verificare sempre l'esecuzione in browser (`isPlatformBrowser`) prima di usare Web APIs.
- [ ] Testare il comportamento in SSR/prerender senza accesso a `window`, `localStorage`, `indexedDB`, `caches`.
- [ ] Definire matrice browser supportati e fallback minimi richiesti.
- [ ] Validare i comportamenti in modalità privata/incognito (alcuni browser riducono quota/storage).

### Osservabilità e manutenzione

- [ ] Aggiungere log diagnostici non sensibili per errori storage lato client.
- [ ] Tracciare metriche applicative su fallimenti di persistenza e tassi di rehydrate.
- [ ] Coprire servizi storage con test unitari mirati e test di integrazione browser-based.
- [ ] Documentare policy di retention e cancellazione dati lato client.
