import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class IndexedDbNativeService {
  private readonly dbName = 'storage-demo-native-db';
  private readonly storeName = 'kv';
  private readonly isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

  public async setValue(key: string, value: string): Promise<void> {
    const db = await this.openDb();
    if (!db) {
      return;
    }

    await this.executeTransaction(db, 'readwrite', store => {
      store.put({ key, value });
    });
  }

  public async getValue(key: string): Promise<string | undefined> {
    const db = await this.openDb();
    if (!db) {
      return undefined;
    }

    const result = await this.readRequest<{ key: string; value: string } | undefined>(db, store => store.get(key));
    return result?.value;
  }

  public async deleteValue(key: string): Promise<void> {
    const db = await this.openDb();
    if (!db) {
      return;
    }

    await this.executeTransaction(db, 'readwrite', store => {
      store.delete(key);
    });
  }

  public async listAll(): Promise<Array<{ key: string; value: string }>> {
    const db = await this.openDb();
    if (!db) {
      return [];
    }

    return this.readRequest<Array<{ key: string; value: string }>>(db, store => store.getAll());
  }

  private async openDb(): Promise<IDBDatabase | null> {
    if (!this.isBrowser || typeof indexedDB === 'undefined') {
      return null;
    }

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1);

      // La migrazione schema è centralizzata qui: in futuro basta incrementare la versione e gestire upgrade.
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName, { keyPath: 'key' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  private async executeTransaction(
    db: IDBDatabase,
    mode: IDBTransactionMode,
    action: (store: IDBObjectStore) => void
  ): Promise<void> {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(this.storeName, mode);
      const store = transaction.objectStore(this.storeName);

      action(store);

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  }

  private async readRequest<T>(
    db: IDBDatabase,
    action: (store: IDBObjectStore) => IDBRequest<T>
  ): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const transaction = db.transaction(this.storeName, 'readonly');
      const store = transaction.objectStore(this.storeName);
      const request = action(store);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
}
