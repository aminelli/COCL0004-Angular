import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import type DexieType from 'dexie';
import type { Table } from 'dexie';

interface DexieEntry {
  key: string;
  value: string;
}

type DexieDatabase = DexieType & {
  kv: Table<DexieEntry, string>;
};

@Injectable({
  providedIn: 'root'
})
export class IndexedDbDexieService {
  private readonly isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
  private readonly hasIndexedDb = this.isBrowser && typeof indexedDB !== 'undefined';
  private dbPromise: Promise<DexieDatabase | null> | null = null;

  public async setValue(key: string, value: string): Promise<void> {
    const db = await this.getDb();
    if (!db) {
      return;
    }

    await db.kv.put({ key, value });
  }

  public async getValue(key: string): Promise<string | undefined> {
    const db = await this.getDb();
    if (!db) {
      return undefined;
    }

    const row = await db.kv.get(key);
    return row?.value;
  }

  public async deleteValue(key: string): Promise<void> {
    const db = await this.getDb();
    if (!db) {
      return;
    }

    await db.kv.delete(key);
  }

  public async listAll(): Promise<Array<{ key: string; value: string }>> {
    const db = await this.getDb();
    if (!db) {
      return [];
    }

    return db.kv.toArray();
  }

  private async getDb(): Promise<DexieDatabase | null> {
    if (!this.hasIndexedDb) {
      return null;
    }

    this.dbPromise ??= (async () => {
      // Import dinamico: Dexie viene caricato solo quando IndexedDB viene realmente usato.
      const module = await import('dexie');
      const Dexie = module.default;
      const db = new Dexie('storage-demo-dexie-db') as DexieDatabase;

      db.version(1).stores({
        kv: 'key'
      });

      return db;
    })();

    return this.dbPromise;
  }
}
