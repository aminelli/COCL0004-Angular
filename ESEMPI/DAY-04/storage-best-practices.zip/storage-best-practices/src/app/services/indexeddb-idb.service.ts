import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import type { DBSchema, IDBPDatabase } from 'idb';

interface StorageIdbSchema extends DBSchema {
  kv: {
    key: string;
    value: {
      key: string;
      value: string;
    };
  };
}

@Injectable({
  providedIn: 'root'
})
export class IndexedDbIdbService {
  private readonly isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
  private dbPromise: Promise<any> | null = null;

  public async setValue(key: string, value: string): Promise<void> {
    const db = await this.getDb();
    if (!db) {
      return;
    }

    await db.put('kv', { key, value });
  }

  public async getValue(key: string): Promise<string | undefined> {
    const db = await this.getDb();
    if (!db) {
      return undefined;
    }

    const row = await db.get('kv', key);
    return row?.value;
  }

  public async deleteValue(key: string): Promise<void> {
    const db = await this.getDb();
    if (!db) {
      return;
    }

    await db.delete('kv', key);
  }

  public async listAll(): Promise<Array<{ key: string; value: string }>> {
    const db = await this.getDb();
    if (!db) {
      return [];
    }

    return db.getAll('kv');
  }

  private async getDb(): Promise<IDBPDatabase<StorageIdbSchema> | null> {
    if (!this.isBrowser || typeof indexedDB === 'undefined') {
      return null;
    }

    this.dbPromise ??= (async () => {
      // Import dinamico: idb viene caricato solo quando serve davvero (first access).
      const { openDB } = await import('idb');

      return openDB('storage-demo-idb-db', 1, {
        // Anche con idb manteniamo la logica di migrazione schema esplicita e versionata.
        upgrade(db): void {
          if (!db.objectStoreNames.contains('kv')) {
            db.createObjectStore('kv', { keyPath: 'key' });
          }
        }
      });
    })();

    return this.dbPromise;
  }
}
