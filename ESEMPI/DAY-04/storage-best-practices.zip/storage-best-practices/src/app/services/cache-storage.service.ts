import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class CacheStorageService {
  private readonly cacheName = 'storage-demo-cache-v1';
  private readonly isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

  public async put(key: string, value: string): Promise<void> {
    const cache = await this.openCache();
    if (!cache) {
      return;
    }

    // Usiamo Request/Response per simulare il caching di una risorsa HTTP locale.
    const request = this.toRequest(key);
    await cache.put(request, new Response(value, { headers: { 'Content-Type': 'text/plain' } }));
  }

  public async match(key: string): Promise<string | undefined> {
    const cache = await this.openCache();
    if (!cache) {
      return undefined;
    }

    const response = await cache.match(this.toRequest(key));
    if (!response) {
      return undefined;
    }

    return response.text();
  }

  public async delete(key: string): Promise<void> {
    const cache = await this.openCache();
    if (!cache) {
      return;
    }

    await cache.delete(this.toRequest(key));
  }

  public async keys(): Promise<string[]> {
    const cache = await this.openCache();
    if (!cache) {
      return [];
    }

    const requests = await cache.keys();

    return requests.map(request => this.fromRequest(request));
  }

  private async openCache(): Promise<Cache | null> {
    if (!this.isBrowser || typeof caches === 'undefined') {
      return null;
    }

    return caches.open(this.cacheName);
  }

  private toRequest(key: string): Request {
    return new Request(`/cache-storage-demo/${encodeURIComponent(key)}`);
  }

  private fromRequest(request: Request): string {
    const url = new URL(request.url);
    const key = url.pathname.replace('/cache-storage-demo/', '');
    return decodeURIComponent(key);
  }
}
