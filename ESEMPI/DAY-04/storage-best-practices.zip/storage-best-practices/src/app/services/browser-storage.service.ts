import { inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class BrowserStorageService {
  // In Angular SSR/Server non esistono localStorage/sessionStorage, quindi usiamo una guardia centralizzata.
  private readonly isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

  public setLocal(key: string, value: unknown): void {
    this.setItem('local', key, value);
  }

  public getLocal<T>(key: string): T | null {
    return this.getItem<T>('local', key);
  }

  public removeLocal(key: string): void {
    this.removeItem('local', key);
  }

  public setSession(key: string, value: unknown): void {
    this.setItem('session', key, value);
  }

  public getSession<T>(key: string): T | null {
    return this.getItem<T>('session', key);
  }

  public removeSession(key: string): void {
    this.removeItem('session', key);
  }

  private setItem(type: 'local' | 'session', key: string, value: unknown): void {
    const storage = this.resolveStorage(type);
    if (!storage) {
      return;
    }

    // Serializziamo sempre in JSON per supportare non solo stringhe ma anche oggetti/array.
    storage.setItem(key, JSON.stringify(value));
  }

  private getItem<T>(type: 'local' | 'session', key: string): T | null {
    const storage = this.resolveStorage(type);
    if (!storage) {
      return null;
    }

    const rawValue = storage.getItem(key);
    if (rawValue === null) {
      return null;
    }

    try {
      return JSON.parse(rawValue) as T;
    } catch {
      // Se il valore non è JSON valido, restituiamo il valore raw come fallback tipizzato.
      return rawValue as T;
    }
  }

  private removeItem(type: 'local' | 'session', key: string): void {
    const storage = this.resolveStorage(type);
    if (!storage) {
      return;
    }

    storage.removeItem(key);
  }

  private resolveStorage(type: 'local' | 'session'): Storage | null {
    if (!this.isBrowser) {
      return null;
    }

    return type === 'local' ? localStorage : sessionStorage;
  }
}
