import { Action, ActionReducer, createReducer, MetaReducer, on } from '@ngrx/store';
import { localStorageSync } from 'ngrx-store-localstorage';
import { decrementCounter, incrementCounter, resetCounter, setNotes } from './storage.actions';
import { AppState, initialStorageState, StorageFeatureState } from './storage.state';

const internalReducer = createReducer(
  initialStorageState,
  on(incrementCounter, state => ({ ...state, counter: state.counter + 1 })),
  on(decrementCounter, state => ({ ...state, counter: state.counter - 1 })),
  on(resetCounter, state => ({ ...state, counter: 0 })),
  on(setNotes, (state, { notes }) => ({ ...state, notes }))
);

export function storageReducer(state: StorageFeatureState | undefined, action: Action): StorageFeatureState {
  return internalReducer(state, action);
}

// Meta-reducer: sincronizza selettivamente la feature `storage` su localStorage.
export function localStorageSyncReducer(reducer: ActionReducer<AppState>): ActionReducer<AppState> {
  // Durante SSR non dobbiamo toccare localStorage: il reducer resta puro lato server.
  if (typeof localStorage === 'undefined') {
    return reducer;
  }

  return localStorageSync({
    keys: ['storage'],
    rehydrate: true
  })(reducer);
}

export const metaReducers: MetaReducer<AppState>[] = [localStorageSyncReducer];
