export interface StorageFeatureState {
  counter: number;
  notes: string;
}

export interface AppState {
  storage: StorageFeatureState;
}

export const initialStorageState: StorageFeatureState = {
  counter: 0,
  notes: 'Scrivi qui note persistenti nello stato NgRx.'
};
