import { createAction, props } from '@ngrx/store';

// Azioni minimali ma esplicite: mantengono tracciabile ogni modifica di stato.
export const incrementCounter = createAction('[Storage] Increment Counter');
export const decrementCounter = createAction('[Storage] Decrement Counter');
export const resetCounter = createAction('[Storage] Reset Counter');
export const setNotes = createAction('[Storage] Set Notes', props<{ notes: string }>());
