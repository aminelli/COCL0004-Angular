import { createFeatureSelector, createSelector } from '@ngrx/store';
import { StorageFeatureState } from './storage.state';

const selectStorageState = createFeatureSelector<StorageFeatureState>('storage');

export const selectCounter = createSelector(selectStorageState, state => state.counter);
export const selectNotes = createSelector(selectStorageState, state => state.notes);
