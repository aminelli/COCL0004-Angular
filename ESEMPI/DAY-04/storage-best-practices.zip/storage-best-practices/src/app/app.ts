import { CommonModule } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { BrowserStorageService } from './services/browser-storage.service';
import { CacheStorageService } from './services/cache-storage.service';
import { IndexedDbDexieService } from './services/indexeddb-dexie.service';
import { IndexedDbIdbService } from './services/indexeddb-idb.service';
import { IndexedDbNativeService } from './services/indexeddb-native.service';
import { decrementCounter, incrementCounter, resetCounter, setNotes } from './store/storage.actions';
import { selectCounter, selectNotes } from './store/storage.selectors';

@Component({
  selector: 'app-root',
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  private readonly browserStorage = inject(BrowserStorageService);
  private readonly nativeIndexedDb = inject(IndexedDbNativeService);
  private readonly dexieIndexedDb = inject(IndexedDbDexieService);
  private readonly idbIndexedDb = inject(IndexedDbIdbService);
  private readonly cacheStorage = inject(CacheStorageService);
  private readonly store = inject(Store);

  protected readonly title = signal('Storage in Angular 21: best practices');

  protected readonly localKey = signal('utente');
  protected readonly localValue = signal('Mario Rossi');
  protected readonly localReadValue = signal('Nessun valore letto');

  protected readonly sessionKey = signal('sessione');
  protected readonly sessionValue = signal('token-demo');
  protected readonly sessionReadValue = signal('Nessun valore letto');

  protected readonly nativeKey = signal('preferenza-tema');
  protected readonly nativeValue = signal('dark');
  protected readonly nativeReadValue = signal('Nessun valore letto');
  protected readonly nativeEntries = signal<Array<{ key: string; value: string }>>([]);

  protected readonly dexieKey = signal('filtro');
  protected readonly dexieValue = signal('ultimi-30-giorni');
  protected readonly dexieReadValue = signal('Nessun valore letto');
  protected readonly dexieEntries = signal<Array<{ key: string; value: string }>>([]);

  protected readonly idbKey = signal('layout');
  protected readonly idbValue = signal('griglia');
  protected readonly idbReadValue = signal('Nessun valore letto');
  protected readonly idbEntries = signal<Array<{ key: string; value: string }>>([]);

  protected readonly cacheKey = signal('news-home');
  protected readonly cacheValue = signal('Contenuto cache lato browser');
  protected readonly cacheReadValue = signal('Nessun valore letto');
  protected readonly cacheEntries = signal<string[]>([]);

  protected readonly counter = this.store.selectSignal(selectCounter);
  protected readonly notes = this.store.selectSignal(selectNotes);
  protected readonly notesDraft = signal('');

  protected readonly hasAnyIndexedDbData = computed(
    () => this.nativeEntries().length > 0 || this.dexieEntries().length > 0 || this.idbEntries().length > 0
  );

  public async ngOnInit(): Promise<void> {
    // In fase di bootstrap inizializziamo la vista leggendo i dati già persistiti nei vari storage.
    await Promise.all([
      this.refreshNativeEntries(),
      this.refreshDexieEntries(),
      this.refreshIdbEntries(),
      this.refreshCacheEntries()
    ]);

    // Sincronizziamo subito la bozza note con lo stato NgRx (persistito su localStorage tramite meta-reducer).
    this.notesDraft.set(this.notes());
  }

  protected onLocalKeyChange(value: string): void {
    this.localKey.set(value);
  }

  protected onLocalValueChange(value: string): void {
    this.localValue.set(value);
  }

  protected onSessionKeyChange(value: string): void {
    this.sessionKey.set(value);
  }

  protected onSessionValueChange(value: string): void {
    this.sessionValue.set(value);
  }

  protected onNativeKeyChange(value: string): void {
    this.nativeKey.set(value);
  }

  protected onNativeValueChange(value: string): void {
    this.nativeValue.set(value);
  }

  protected onDexieKeyChange(value: string): void {
    this.dexieKey.set(value);
  }

  protected onDexieValueChange(value: string): void {
    this.dexieValue.set(value);
  }

  protected onIdbKeyChange(value: string): void {
    this.idbKey.set(value);
  }

  protected onIdbValueChange(value: string): void {
    this.idbValue.set(value);
  }

  protected onCacheKeyChange(value: string): void {
    this.cacheKey.set(value);
  }

  protected onCacheValueChange(value: string): void {
    this.cacheValue.set(value);
  }

  protected onNotesDraftChange(value: string): void {
    this.notesDraft.set(value);
  }

  protected saveToLocalStorage(): void {
    this.browserStorage.setLocal(this.localKey(), this.localValue());
    this.localReadValue.set('Valore salvato correttamente');
  }

  protected readFromLocalStorage(): void {
    const result = this.browserStorage.getLocal<string>(this.localKey());
    this.localReadValue.set(result ?? 'Valore non presente');
  }

  protected removeFromLocalStorage(): void {
    this.browserStorage.removeLocal(this.localKey());
    this.localReadValue.set('Valore rimosso');
  }

  protected saveToSessionStorage(): void {
    this.browserStorage.setSession(this.sessionKey(), this.sessionValue());
    this.sessionReadValue.set('Valore salvato correttamente');
  }

  protected readFromSessionStorage(): void {
    const result = this.browserStorage.getSession<string>(this.sessionKey());
    this.sessionReadValue.set(result ?? 'Valore non presente');
  }

  protected removeFromSessionStorage(): void {
    this.browserStorage.removeSession(this.sessionKey());
    this.sessionReadValue.set('Valore rimosso');
  }

  protected async saveToNativeIndexedDb(): Promise<void> {
    await this.nativeIndexedDb.setValue(this.nativeKey(), this.nativeValue());
    this.nativeReadValue.set('Valore salvato correttamente');
    await this.refreshNativeEntries();
  }

  protected async readFromNativeIndexedDb(): Promise<void> {
    const result = await this.nativeIndexedDb.getValue(this.nativeKey());
    this.nativeReadValue.set(result ?? 'Valore non presente');
  }

  protected async removeFromNativeIndexedDb(): Promise<void> {
    await this.nativeIndexedDb.deleteValue(this.nativeKey());
    this.nativeReadValue.set('Valore rimosso');
    await this.refreshNativeEntries();
  }

  protected async saveToDexie(): Promise<void> {
    await this.dexieIndexedDb.setValue(this.dexieKey(), this.dexieValue());
    this.dexieReadValue.set('Valore salvato correttamente');
    await this.refreshDexieEntries();
  }

  protected async readFromDexie(): Promise<void> {
    const result = await this.dexieIndexedDb.getValue(this.dexieKey());
    this.dexieReadValue.set(result ?? 'Valore non presente');
  }

  protected async removeFromDexie(): Promise<void> {
    await this.dexieIndexedDb.deleteValue(this.dexieKey());
    this.dexieReadValue.set('Valore rimosso');
    await this.refreshDexieEntries();
  }

  protected async saveToIdb(): Promise<void> {
    await this.idbIndexedDb.setValue(this.idbKey(), this.idbValue());
    this.idbReadValue.set('Valore salvato correttamente');
    await this.refreshIdbEntries();
  }

  protected async readFromIdb(): Promise<void> {
    const result = await this.idbIndexedDb.getValue(this.idbKey());
    this.idbReadValue.set(result ?? 'Valore non presente');
  }

  protected async removeFromIdb(): Promise<void> {
    await this.idbIndexedDb.deleteValue(this.idbKey());
    this.idbReadValue.set('Valore rimosso');
    await this.refreshIdbEntries();
  }

  protected async saveToCacheStorage(): Promise<void> {
    await this.cacheStorage.put(this.cacheKey(), this.cacheValue());
    this.cacheReadValue.set('Valore salvato correttamente');
    await this.refreshCacheEntries();
  }

  protected async readFromCacheStorage(): Promise<void> {
    const result = await this.cacheStorage.match(this.cacheKey());
    this.cacheReadValue.set(result ?? 'Valore non presente');
  }

  protected async removeFromCacheStorage(): Promise<void> {
    await this.cacheStorage.delete(this.cacheKey());
    this.cacheReadValue.set('Valore rimosso');
    await this.refreshCacheEntries();
  }

  protected increment(): void {
    // Lo stato NgRx viene persistito automaticamente in localStorage grazie a ngrx-store-localstorage.
    this.store.dispatch(incrementCounter());
  }

  protected decrement(): void {
    this.store.dispatch(decrementCounter());
  }

  protected reset(): void {
    this.store.dispatch(resetCounter());
  }

  protected saveNotes(): void {
    this.store.dispatch(setNotes({ notes: this.notesDraft() }));
  }

  private async refreshNativeEntries(): Promise<void> {
    const entries = await this.nativeIndexedDb.listAll();
    this.nativeEntries.set(entries);
  }

  private async refreshDexieEntries(): Promise<void> {
    const entries = await this.dexieIndexedDb.listAll();
    this.dexieEntries.set(entries);
  }

  private async refreshIdbEntries(): Promise<void> {
    const entries = await this.idbIndexedDb.listAll();
    this.idbEntries.set(entries);
  }

  private async refreshCacheEntries(): Promise<void> {
    const keys = await this.cacheStorage.keys();
    this.cacheEntries.set(keys);
  }
}
