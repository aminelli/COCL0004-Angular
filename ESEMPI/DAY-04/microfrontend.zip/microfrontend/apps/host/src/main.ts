import './style.css';
import { createGatewayClient } from '@demo/shared-gateway';

const appElement = document.querySelector<HTMLDivElement>('#app');

if (!appElement) {
  throw new Error('Missing #app root element');
}

appElement.innerHTML = `
  <main class="shell">
    <header class="shell-header">
      <h1>Host microfrontend</h1>
      <p>Composizione di 3 microfrontend isolati: Angular, React e Vue.</p>
      <p id="gateway-status">Gateway: controllo in corso…</p>
    </header>

    <section class="grid">
      <article class="card">
        <h2>React microfrontend</h2>
        <iframe title="React microfrontend" src="http://localhost:4173" loading="lazy"></iframe>
      </article>

      <article class="card">
        <h2>Vue microfrontend</h2>
        <iframe title="Vue microfrontend" src="http://localhost:4174" loading="lazy"></iframe>
      </article>

      <article class="card">
        <h2>Angular microfrontend</h2>
        <iframe title="Angular microfrontend" src="http://localhost:4201" loading="lazy"></iframe>
      </article>
    </section>
  </main>
`;

const gatewayStatusElement = document.getElementById('gateway-status');
const client = createGatewayClient({ baseUrl: 'http://localhost:3000' });

client
  .getHealth()
  .then((health) => {
    if (!gatewayStatusElement) {
      return;
    }

    gatewayStatusElement.textContent = `Gateway: ${health.status} (last check ${new Date(health.timestamp).toLocaleTimeString()})`;
  })
  .catch((error: unknown) => {
    if (!gatewayStatusElement) {
      return;
    }

    const message = error instanceof Error ? error.message : 'Errore sconosciuto';
    gatewayStatusElement.textContent = `Gateway: non raggiungibile (${message})`;
  });
