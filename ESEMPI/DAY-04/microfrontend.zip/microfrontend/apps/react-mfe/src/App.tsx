import { useEffect, useMemo, useState } from 'react'
import { createGatewayClient, type DashboardResponse } from '@demo/shared-gateway'
import './App.css'

function App() {
  const client = useMemo(() => createGatewayClient({ baseUrl: 'http://localhost:3000' }), [])
  const [data, setData] = useState<DashboardResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let mounted = true

    client
      .getDashboard('react')
      .then((response) => {
        if (mounted) {
          setData(response)
        }
      })
      .catch((caughtError: unknown) => {
        if (!mounted) {
          return
        }

        setError(caughtError instanceof Error ? caughtError.message : 'Errore durante la chiamata gateway')
      })

    return () => {
      mounted = false
    }
  }, [client])

  return (
    <main className="container">
      <h1>React microfrontend</h1>
      <p>Questo frontend usa il pacchetto condiviso <strong>@demo/shared-gateway</strong>.</p>

      {error && <p className="error">Gateway error: {error}</p>}
      {!error && !data && <p>Caricamento dati...</p>}

      {data && (
        <section className="card">
          <p><strong>Messaggio:</strong> {data.message}</p>
          <p><strong>Timestamp:</strong> {new Date(data.generatedAt).toLocaleString()}</p>
          <ul>
            {data.capabilities.map((capability) => (
              <li key={capability}>{capability}</li>
            ))}
          </ul>
        </section>
      )}
    </main>
  )
}

export default App
