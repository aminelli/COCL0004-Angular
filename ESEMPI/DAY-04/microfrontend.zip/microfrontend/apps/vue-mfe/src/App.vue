<script setup lang="ts">
import { createGatewayClient, type DashboardResponse } from '@demo/shared-gateway'
import { onMounted, ref } from 'vue'

const data = ref<DashboardResponse | null>(null)
const error = ref<string | null>(null)

const client = createGatewayClient({ baseUrl: 'http://localhost:3000' })

onMounted(async () => {
  try {
    data.value = await client.getDashboard('vue')
  } catch (caughtError: unknown) {
    error.value = caughtError instanceof Error ? caughtError.message : 'Errore durante la chiamata gateway'
  }
})
</script>

<template>
  <main class="container">
    <h1>Vue microfrontend</h1>
    <p>Frontend Vue indipendente con accesso ai servizi condivisi.</p>

    <p v-if="error" class="error">Gateway error: {{ error }}</p>
    <p v-else-if="!data">Caricamento dati...</p>

    <section v-if="data" class="card">
      <p><strong>Messaggio:</strong> {{ data.message }}</p>
      <p><strong>Timestamp:</strong> {{ new Date(data.generatedAt).toLocaleString() }}</p>
      <ul>
        <li v-for="capability in data.capabilities" :key="capability">
          {{ capability }}
        </li>
      </ul>
    </section>
  </main>
</template>

<style scoped>
.container {
  padding: 1rem;
  color: #111827;
}

.container h1 {
  margin: 0;
  font-size: 1.3rem;
}

.container p {
  margin: 0.5rem 0;
}

.card {
  margin-top: 0.75rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.75rem;
  background: #fff;
  padding: 0.75rem;
}

.card ul {
  margin: 0.5rem 0 0;
  padding-left: 1.1rem;
}

.error {
  color: #b91c1c;
  font-weight: 600;
}
</style>
