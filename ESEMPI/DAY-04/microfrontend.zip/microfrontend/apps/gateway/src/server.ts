import cors from 'cors';
import express from 'express';
import type { DashboardResponse, FrameworkName, ServiceHealthResponse } from '@demo/shared-gateway';

const app = express();
const port = 3000;

const capabilitiesByFramework: Record<FrameworkName, string[]> = {
  host: ['Orchestrazione microfrontend', 'Routing shell', 'Isolamento runtime'],
  react: ['UI dinamica', 'Hooks moderni', 'Rendering client'],
  vue: ['Composables', 'Reattività fine-grained', 'Single File Components'],
  angular: ['Dependency Injection', 'Signals', 'Tooling enterprise'],
};

app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => {
  const payload: ServiceHealthResponse = {
    status: 'ok',
    service: 'gateway',
    timestamp: new Date().toISOString(),
  };

  res.json(payload);
});

app.get('/api/dashboard', (req, res) => {
  const frameworkParam = String(req.query.framework ?? 'host') as FrameworkName;
  const framework: FrameworkName = ['host', 'react', 'vue', 'angular'].includes(frameworkParam)
    ? frameworkParam
    : 'host';

  const payload: DashboardResponse = {
    framework,
    message: `Gateway response for ${framework} microfrontend`,
    capabilities: capabilitiesByFramework[framework],
    generatedAt: new Date().toISOString(),
  };

  res.json(payload);
});

app.listen(port, () => {
  console.log(`[gateway] listening on http://localhost:${port}`);
});
