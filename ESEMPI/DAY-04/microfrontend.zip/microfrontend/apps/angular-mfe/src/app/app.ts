import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { createGatewayClient, type DashboardResponse } from '@demo/shared-gateway';

@Component({
  selector: 'app-root',
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  data: DashboardResponse | null = null;
  error: string | null = null;

  private readonly client = createGatewayClient({ baseUrl: 'http://localhost:3000' });

  async ngOnInit(): Promise<void> {
    try {
      this.data = await this.client.getDashboard('angular');
    } catch (caughtError: unknown) {
      this.error = caughtError instanceof Error ? caughtError.message : 'Errore durante la chiamata gateway';
    }
  }
}
