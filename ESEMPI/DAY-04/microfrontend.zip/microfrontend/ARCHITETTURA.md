# Architettura Microfrontend

## Panorama

Questa implementazione realizza una shell host che compone tre microfrontend isolati (React, Vue, Angular) e un gateway backend condiviso.

```mermaid
flowchart LR
  Browser[Browser Utente]

  subgraph Host[Host Shell - Vite :4200]
    H[App Host]
  end

  subgraph MFEs[Microfrontend Isolati]
    R[React MFE :4173]
    V[Vue MFE :4174]
    A[Angular MFE :4201]
  end

  subgraph Shared[Pacchetto Condiviso]
    SG[shared-gateway\nGatewayClient + modelli]
  end

  subgraph API[Gateway Backend - Express :3000]
    G[/GET /api/health/]
    D[/GET /api/dashboard?framework=.../]
  end

  Browser --> H
  H -->|iframe| R
  H -->|iframe| V
  H -->|iframe| A

  H --> SG
  R --> SG
  V --> SG
  A --> SG

  SG --> G
  SG --> D
```

## Note operative

- Host verifica lo stato gateway con `getHealth()`.
- Ogni microfrontend richiede il proprio payload con `getDashboard(framework)`.
- Il package `@demo/shared-gateway` centralizza contratto tipi e client HTTP per coerenza cross-framework.
