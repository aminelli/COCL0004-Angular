import type { DashboardResponse, FrameworkName, ServiceHealthResponse } from './models';

export interface GatewayClientOptions {
  baseUrl?: string;
  timeoutMs?: number;
}

const DEFAULT_TIMEOUT_MS = 8_000;

export class GatewayClient {
  private readonly baseUrl: string;
  private readonly timeoutMs: number;

  constructor(options: GatewayClientOptions = {}) {
    this.baseUrl = (options.baseUrl ?? 'http://localhost:3000').replace(/\/$/, '');
    this.timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  async getHealth(): Promise<ServiceHealthResponse> {
    return this.get<ServiceHealthResponse>('/api/health');
  }

  async getDashboard(framework: FrameworkName): Promise<DashboardResponse> {
    const query = new URLSearchParams({ framework });
    return this.get<DashboardResponse>(`/api/dashboard?${query.toString()}`);
  }

  private async get<T>(path: string): Promise<T> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        method: 'GET',
        headers: {
          Accept: 'application/json',
        },
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`Gateway request failed with status ${response.status}`);
      }

      return (await response.json()) as T;
    } finally {
      clearTimeout(timeout);
    }
  }
}

export const createGatewayClient = (options?: GatewayClientOptions): GatewayClient =>
  new GatewayClient(options);
