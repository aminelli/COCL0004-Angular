export type FrameworkName = 'host' | 'react' | 'vue' | 'angular';

export interface DashboardResponse {
  framework: FrameworkName;
  message: string;
  capabilities: string[];
  generatedAt: string;
}

export interface ServiceHealthResponse {
  status: 'ok';
  service: 'gateway';
  timestamp: string;
}
