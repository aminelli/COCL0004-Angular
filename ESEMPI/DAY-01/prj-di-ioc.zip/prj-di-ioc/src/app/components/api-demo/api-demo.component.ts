/**
 * ApiDemoComponent - Componente per dimostrare chiamate API
 *
 * DEPENDENCY INJECTION con SERVIZI COMPLESSI:
 * Questo componente usa ApiService che a sua volta dipende da:
 * - LoggerService
 * - ConfigService
 * - DataService (che dipende da LoggerService)
 *
 * ALBERO DELLE DIPENDENZE:
 * ApiDemoComponent
 *   └─→ ApiService
 *        ├─→ LoggerService
 *        ├─→ ConfigService
 *        └─→ DataService
 *             └─→ LoggerService (stessa istanza!)
 *
 * Angular risolve automaticamente TUTTO questo albero di dipendenze!
 */

import { Component, NgZone, signal  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, ApiResponse } from '../../services/api.service';
import { LoggerService } from '../../services/logger.service';

@Component({
  selector: 'app-api-demo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './api-demo.component.html',
  styleUrls: ['./api-demo.component.scss']
})
export class ApiDemoComponent {
  /**
   * Stato delle chiamate API
   */
  isLoading = signal(false);
  lastResponse = signal<ApiResponse<any> | null>(null);
  error = signal<string | null>(null);

  /**
   * DEPENDENCY INJECTION PROFONDA:
   *
   * Quando Angular inietta ApiService qui, deve prima:
   * 1. Verificare se ApiService esiste (no, è la prima volta)
   * 2. Vedere che ApiService dipende da LoggerService, ConfigService, DataService
   * 3. Verificare se LoggerService esiste (sì, creato prima)
   * 4. Verificare se ConfigService esiste (sì, creato prima)
   * 5. Verificare se DataService esiste (sì, creato prima)
   * 6. Creare ApiService iniettando le tre dipendenze
   * 7. Iniettare ApiService in questo componente
   *
   * Tutto questo avviene AUTOMATICAMENTE!
   *
   * @param apiService - Servizio API con albero di dipendenze complesso
   * @param logger - Servizio logger (stessa istanza usata da ApiService!)
   */
  constructor(
    private apiService: ApiService,
    private logger: LoggerService
  ) {
    this.logger.log('ApiDemoComponent costruttore - ApiService iniettato con tutte le sue dipendenze');
  }

  /**
   * Esegue una chiamata GET simulata
   */
  performGet(): void {
    this.isLoading.set(true);
    this.error.set(null);
    this.logger.log('Inizio chiamata GET tramite ApiService');


    /**
     * Chiamata al metodo del servizio iniettato
     * Il servizio gestisce internamente tutte le dipendenze
     */
    this.apiService.get('/api/data')
      .subscribe({
        next: (response) => {
          this.lastResponse.set(response);
          this.isLoading.set(false);
          this.logger.log('GET completata con successo');
        },
        error: (err) => {
          this.error.set(err.message);
          this.isLoading.set(false);
          this.logger.error(`GET fallita: ${err.message}`);
        }
      });
  }

  /**
   * Esegue una chiamata POST simulata
   */
  performPost(): void {
    this.isLoading.set(true);
    this.error.set(null);
    const testData = { name: 'Test', value: 123 };
    this.logger.log('Inizio chiamata POST tramite ApiService');

    this.apiService.post('/api/data', testData)
      .subscribe({
        next: (response) => {
          this.lastResponse.set(response);
          this.isLoading.set(false);
          this.logger.log('POST completata con successo');
        },
        error: (err) => {
          this.error.set(err.message);
          this.isLoading.set(false);
          this.logger.error(`POST fallita: ${err.message}`);
        }
      });
  }

  /**
   * Simula una chiamata che ha successo
   */
  performSuccess(): void {
    this.isLoading.set(true);
    this.error.set(null);
    this.logger.log('Inizio chiamata con retry (successo)');

    this.apiService.fetchWithRetry(false)
      .subscribe({
        next: (response) => {
          this.lastResponse.set(response);
          this.isLoading.set(false);
          this.logger.log('Chiamata completata con successo');
        },
        error: (err) => {
          this.error.set(err.message);
          this.isLoading.set(false);
        }
      });
  }

  /**
   * Simula una chiamata che fallisce
   */
  performError(): void {
    this.isLoading.set(true);
    this.error.set(null);
    this.logger.log('Inizio chiamata con retry (errore simulato)');

    this.apiService.fetchWithRetry(true)
      .subscribe({
        next: (response) => {
          this.lastResponse.set(response);
          this.isLoading.set(false);
        },
        error: (err) => {
          this.error.set(err.message);
          this.isLoading.set(false);
          this.logger.error(`Chiamata fallita come previsto: ${err.message}`);
        }
      });
  }
}
