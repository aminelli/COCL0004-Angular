/**
 * DataListComponent - Componente per visualizzare la lista di dati
 * 
 * DEPENDENCY INJECTION con OBSERVABLE PATTERN:
 * Questo componente dimostra come usare servizi iniettati che
 * espongono Observable (programmazione reattiva con RxJS).
 * 
 * La combinazione di DI + RxJS è un pattern molto potente in Angular.
 */

import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService, DataItem } from '../../services/data.service';
import { LoggerService } from '../../services/logger.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-data-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './data-list.component.html',
  styleUrls: ['./data-list.component.scss']
})
export class DataListComponent implements OnInit, OnDestroy {
  /**
   * Lista di elementi da visualizzare
   */
  items: DataItem[] = [];

  /**
   * Subject per gestire la disiscrizione dagli Observable
   * Best practice per evitare memory leaks
   */
  private destroy$ = new Subject<void>();

  /**
   * CONSTRUCTOR INJECTION con MULTIPLE DEPENDENCIES:
   * 
   * Anche se questo componente richiede sia DataService che LoggerService,
   * non deve preoccuparsi di come ottenerli o in che ordine.
   * Angular gestisce tutto automaticamente.
   * 
   * @param dataService - Servizio dati iniettato
   * @param logger - Servizio logger iniettato
   */
  constructor(
    private dataService: DataService,
    private logger: LoggerService
  ) {
    this.logger.log('DataListComponent costruttore chiamato');
  }

  /**
   * ngOnInit - Lifecycle hook
   * Qui sottoscriviamo all'Observable esposto da DataService
   * 
   * REACTIVE PROGRAMMING + DI:
   * - DataService espone un Observable (data$)
   * - Ci sottoscriviamo per ricevere aggiornamenti in tempo reale
   * - Quando i dati cambiano (in qualsiasi parte dell'app),
   *   questo componente riceve automaticamente i nuovi dati
   */
  ngOnInit(): void {
    this.logger.log('DataListComponent inizializzato - sottoscrizione ai dati');

    /**
     * Sottoscrizione all'Observable dei dati
     * takeUntil(destroy$) garantisce la disiscrizione automatica
     */
    this.dataService.data$
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          this.items = data;
          this.logger.log(`DataListComponent ricevuto aggiornamento: ${data.length} elementi`);
        },
        error: (err) => {
          this.logger.error(`Errore nella ricezione dati: ${err}`);
        }
      });
  }

  /**
   * Rimuove un elemento dalla lista
   * Usa il servizio iniettato per modificare i dati
   * 
   * @param id - ID dell'elemento da rimuovere
   */
  removeItem(id: number): void {
    this.logger.log(`Richiesta rimozione elemento ID: ${id}`);
    this.dataService.removeItem(id);
  }

  /**
   * ngOnDestroy - Lifecycle hook
   * Chiamato quando il componente viene distrutto
   * 
   * BEST PRACTICE:
   * Emette un valore nel Subject destroy$ che completa
   * tutte le sottoscrizioni create con takeUntil(destroy$)
   */
  ngOnDestroy(): void {
    this.logger.log('DataListComponent distrutto - disiscrizione automatica');
    this.destroy$.next();
    this.destroy$.complete();
  }
}
