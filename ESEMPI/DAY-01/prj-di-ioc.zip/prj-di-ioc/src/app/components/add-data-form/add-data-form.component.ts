/**
 * AddDataFormComponent - Componente per aggiungere nuovi dati
 * 
 * DEPENDENCY INJECTION in REACTIVE FORMS:
 * Questo componente dimostra l'uso di DI insieme ai Reactive Forms di Angular.
 * Combina:
 * - FormBuilder (iniettato)
 * - DataService (iniettato)
 * - LoggerService (iniettato)
 */

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataService } from '../../services/data.service';
import { LoggerService } from '../../services/logger.service';

@Component({
  selector: 'app-add-data-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './add-data-form.component.html',
  styleUrls: ['./add-data-form.component.scss']
})
export class AddDataFormComponent implements OnInit {
  /**
   * FormGroup per gestire il form reattivo
   */
  dataForm!: FormGroup;

  /**
   * Flag per mostrare messaggi di successo
   */
  showSuccess = false;

  /**
   * DEPENDENCY INJECTION con FormBuilder:
   * 
   * FormBuilder è un servizio fornito da Angular (@angular/forms)
   * che semplifica la creazione di form reattivi.
   * 
   * Questo dimostra come Angular fornisce servizi built-in
   * che possono essere iniettati insieme ai nostri servizi custom.
   * 
   * INVERSION OF CONTROL:
   * Non creiamo manualmente un'istanza di FormBuilder,
   * Angular ce lo fornisce già configurato e pronto all'uso.
   * 
   * @param fb - FormBuilder iniettato da Angular
   * @param dataService - Nostro servizio custom iniettato
   * @param logger - Nostro servizio logger iniettato
   */
  constructor(
    private fb: FormBuilder,
    private dataService: DataService,
    private logger: LoggerService
  ) {
    this.logger.log('AddDataFormComponent costruttore chiamato');
  }

  /**
   * Inizializza il form usando FormBuilder (iniettato)
   */
  ngOnInit(): void {
    /**
     * Creazione del form usando il FormBuilder iniettato
     * 
     * BEST PRACTICE:
     * - Validatori dichiarativi
     * - Type-safety con TypeScript
     * - Gestione reattiva degli input
     */
    this.dataForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });

    this.logger.log('Form reattivo inizializzato con FormBuilder');
  }

  /**
   * Gestisce l'invio del form
   * Usa il servizio DataService iniettato per aggiungere i dati
   */
  onSubmit(): void {
    // Verifica validità del form
    if (this.dataForm.invalid) {
      this.logger.error('Form non valido - validazione fallita');
      this.markFormGroupTouched(this.dataForm);
      return;
    }

    // Estrae i valori dal form
    const { name, description } = this.dataForm.value;
    
    this.logger.log(`Aggiunta nuovo elemento: ${name}`);
    
    /**
     * Usa il servizio iniettato per aggiungere i dati
     * 
     * INVERSION OF CONTROL:
     * Il componente non sa COME i dati vengono salvati o gestiti.
     * Delega questa responsabilità al servizio iniettato.
     * Questo rende il codice più mantenibile e testabile.
     */
    this.dataService.addItem(name, description);
    
    // Reset del form
    this.dataForm.reset();
    
    // Mostra messaggio di successo
    this.showSuccessMessage();
  }

  /**
   * Mostra un messaggio di successo temporaneo
   */
  private showSuccessMessage(): void {
    this.showSuccess = true;
    setTimeout(() => {
      this.showSuccess = false;
    }, 3000);
  }

  /**
   * Marca tutti i campi del form come "touched" per mostrare gli errori
   * @param formGroup - Il form group da marcare
   */
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  /**
   * Getter per accedere facilmente ai controlli del form nel template
   */
  get nameControl() {
    return this.dataForm.get('name');
  }

  get descriptionControl() {
    return this.dataForm.get('description');
  }
}
