/**
 * LogViewerComponent - Componente per visualizzare i log
 *
 * SINGLETON PATTERN con DEPENDENCY INJECTION:
 * Questo componente dimostra come tutti i componenti e servizi
 * condividono la stessa istanza di LoggerService.
 *
 * Quando altri componenti scrivono log, questo componente
 * vede automaticamente tutti i log perché usa la stessa istanza.
 */

import { Component, Inject, OnInit, PLATFORM_ID, signal } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { LoggerService } from '../../services/logger.service';

@Component({
  selector: 'app-log-viewer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './log-viewer.component.html',
  styleUrls: ['./log-viewer.component.scss']
})
export class LogViewerComponent implements OnInit {
  /**
   * Array di log da visualizzare
   */
  logs: string[] = [];

  /**
   * Flag per auto-refresh
   */
  autoRefresh = signal(true);

  /**
   * Intervallo per l'auto-refresh
   */
  //private refreshInterval?: number;
  private refreshInterval?: number;

  /**
   * CONSTRUCTOR INJECTION:
   *
   * Anche se molti altri componenti hanno già iniettato LoggerService,
   * riceveremo la STESSA ISTANZA grazie al pattern Singleton.
   *
   * SINGLETON PATTERN + DI:
   * providedIn: 'root' garantisce che esista una sola istanza
   * di LoggerService per tutta l'applicazione.
   *
   * @param logger - LoggerService (istanza condivisa)
   */
  constructor(private logger: LoggerService, @Inject(PLATFORM_ID) private platformId: Object) {
    // Nota: non logghiamo qui per evitare ricorsione infinita
  }

  ngOnInit(): void {
    this.refreshLogs();

    /**
     * Auto-refresh dei log ogni secondo
     * Dimostra come il servizio mantiene lo stato condiviso
     */
    if (this.autoRefresh() && isPlatformBrowser(this.platformId)) {
      this.refreshInterval = window.setInterval(() => {
        this.refreshLogs();
      }, 1000);
    }
  }

  /**
   * Aggiorna la lista dei log dal servizio iniettato
   */
  refreshLogs(): void {
    this.logs = this.logger.getLogs();
  }

  /**
   * Pulisce tutti i log usando il servizio iniettato
   */
  clearLogs(): void {
    this.logger.clearLogs();
    this.refreshLogs();
  }

  /**
   * Toggle auto-refresh
   */
  toggleAutoRefresh(): void {
    this.autoRefresh.set(!this.autoRefresh());

    if (this.autoRefresh()) {
      this.refreshInterval = window.setInterval(() => {
        this.refreshLogs();
      }, 1000);
    } else if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  /**
   * Cleanup quando il componente viene distrutto
   */
  ngOnDestroy(): void {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }
}
