/**
 * AppConfig - Configurazione dell'applicazione Angular
 *
 * PROVIDER CONFIGURATION e DEPENDENCY INJECTION:
 * Questo file configura tutti i provider dell'applicazione.
 * È qui che Angular impara quali servizi, interceptor e guard sono disponibili.
 *
 * BEST PRACTICE Angular 21:
 * - Usa standalone components
 * - Configura provider a livello di applicazione
 * - Usa functional interceptors e guards
 */

import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';

import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { loggingInterceptor } from './interceptors/logging.interceptor';
import { headerInterceptor } from './interceptors/header.interceptor';


/**
 * Configurazione dell'applicazione
 *
 * DEPENDENCY INJECTION CONFIGURATION:
 * ApplicationConfig è dove registriamo tutti i provider che saranno
 * disponibili per l'iniezione in tutta l'applicazione.
 *
 * INVERSION OF CONTROL:
 * Definiamo COSA è disponibile, ma Angular controlla COME e QUANDO
 * vengono create e iniettate le istanze.
 */

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    /**
     * ROUTER PROVIDER:
     * Fornisce il servizio di routing di Angular.
     * Questo è un esempio di servizio built-in che usa DI.
     */
    provideRouter(routes),
    provideClientHydration(withEventReplay()),

    /**
     * HTTP CLIENT PROVIDER con INTERCEPTORS:
     *
     * provideHttpClient() registra HttpClient per DI
     * withInterceptors() registra gli interceptor funzionali
     *
     * CHAIN OF RESPONSIBILITY + DI:
     * Gli interceptor formano una catena dove ogni interceptor può:
     * 1. Iniettare servizi (usando inject())
     * 2. Modificare richieste/risposte
     * 3. Passare al prossimo nella catena
     *
     * L'ordine degli interceptor è importante:
     * 1. headerInterceptor - aggiunge header
     * 2. loggingInterceptor - logga richieste/risposte
     */
    provideHttpClient(
      withInterceptors([
        headerInterceptor,    // Prima aggiunge header
        loggingInterceptor    // Poi logga tutto
      ])
    ),

    /**
     * CUSTOM SERVICES:
     *
     * Non è necessario registrare qui i servizi che usano providedIn: 'root'
     * perché si auto-registrano. Questo è chiamato "tree-shakable providers".
     *
     * TREE-SHAKABLE PROVIDERS:
     * - LoggerService: providedIn: 'root' → auto-registrato
     * - DataService: providedIn: 'root' → auto-registrato
     * - ConfigService: providedIn: 'root' → auto-registrato
     * - ApiService: providedIn: 'root' → auto-registrato
     *
     * Vengono inclusi nel bundle solo se effettivamente usati (tree-shaking)!
     */

    /**
     * Se avessimo provider custom non tree-shakable, li registreremmo così:
     *
     * { provide: MY_TOKEN, useValue: myValue }
     * { provide: MyService, useClass: MyServiceImpl }
     * { provide: API_URL, useFactory: () => environment.apiUrl }
     */
  ]
};
