/**
 * ApiService - Servizio per le chiamate API
 * 
 * DEPENDENCY INJECTION CON MULTIPLE DIPENDENZE:
 * Questo servizio dimostra come un servizio può dipendere da più servizi.
 * Angular risolve automaticamente tutte le dipendenze in modo ricorsivo.
 * 
 * Albero delle dipendenze:
 * ApiService
 *   ├─→ LoggerService
 *   ├─→ ConfigService
 *   └─→ DataService
 *        └─→ LoggerService (stessa istanza!)
 * 
 * SINGLETON PATTERN con DI:
 * Anche se LoggerService è richiesto sia da ApiService che da DataService,
 * Angular crea una sola istanza (Singleton) e la inietta in entrambi.
 */

import { Injectable } from '@angular/core';
import { LoggerService } from './logger.service';
import { ConfigService } from './config.service';
import { DataService } from './data.service';
import { Observable, of, delay, throwError } from 'rxjs';

/**
 * Interfaccia per la risposta API
 */
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  /**
   * COSTRUTTORE con MULTIPLE DEPENDENCY INJECTION:
   * 
   * Angular analizza il costruttore e inietta automaticamente:
   * 1. LoggerService - per il logging
   * 2. ConfigService - per le configurazioni
   * 3. DataService - per la gestione dei dati
   * 
   * INVERSION OF CONTROL (IoC):
   * ApiService non ha il controllo su COME e QUANDO vengono create
   * le sue dipendenze. Angular ha il controllo completo del
   * ciclo di vita di tutti i servizi.
   * 
   * @param logger - Servizio di logging iniettato
   * @param config - Servizio di configurazione iniettato
   * @param dataService - Servizio dati iniettato
   */
  constructor(
    private logger: LoggerService,
    private config: ConfigService,
    private dataService: DataService
  ) {
    this.logger.log('ApiService istanziato con 3 dipendenze iniettate');
    this.logger.log(`API URL: ${this.config.get('apiUrl')}`);
  }

  /**
   * Simula una chiamata GET a un'API
   * @param endpoint - Endpoint da chiamare
   * @returns Observable con la risposta
   */
  get<T>(endpoint: string): Observable<ApiResponse<T>> {
    const apiUrl = this.config.get('apiUrl');
    const fullUrl = `${apiUrl}${endpoint}`;
    
    this.logger.log(`GET request a: ${fullUrl}`);

    // Simula una risposta API con delay
    const response: ApiResponse<T> = {
      success: true,
      data: this.dataService.getItems() as T,
      timestamp: new Date()
    };

    return of(response).pipe(delay(500));
  }

  /**
   * Simula una chiamata POST a un'API
   * @param endpoint - Endpoint da chiamare
   * @param data - Dati da inviare
   * @returns Observable con la risposta
   */
  post<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    const apiUrl = this.config.get('apiUrl');
    const fullUrl = `${apiUrl}${endpoint}`;
    
    this.logger.log(`POST request a: ${fullUrl}`);
    this.logger.log(`Dati inviati: ${JSON.stringify(data)}`);

    // Simula una risposta API con delay
    const response: ApiResponse<T> = {
      success: true,
      data: data as T,
      timestamp: new Date()
    };

    return of(response).pipe(delay(500));
  }

  /**
   * Simula una chiamata API con possibile errore
   * Dimostra la gestione degli errori con RxJS e DI
   * @param shouldFail - Se true, simula un errore
   * @returns Observable che può fallire
   */
  fetchWithRetry(shouldFail: boolean = false): Observable<ApiResponse<any>> {
    const maxRetries = this.config.get('maxRetries');
    this.logger.log(`Tentativo di fetch (max ${maxRetries} retry)`);

    if (shouldFail) {
      this.logger.error('Simulazione errore API');
      return throwError(() => new Error('API Error simulato'));
    }

    const response: ApiResponse<any> = {
      success: true,
      data: { message: 'Operazione completata con successo' },
      timestamp: new Date()
    };

    return of(response).pipe(delay(500));
  }
}
