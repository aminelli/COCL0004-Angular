/**
 * LoggerService - Servizio Base per il Logging
 * 
 * DEPENDENCY INJECTION (DI):
 * Questo servizio dimostra come Angular gestisce automaticamente la creazione
 * e l'iniezione delle dipendenze. Il decorator @Injectable rende questo servizio
 * iniettabile in altri componenti o servizi.
 * 
 * providedIn: 'root' significa che:
 * - Angular crea una SINGOLA istanza del servizio (Singleton pattern)
 * - L'istanza è disponibile a livello di tutta l'applicazione
 * - Non è necessario registrare il servizio in un modulo (tree-shakable)
 */

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root' // Fornito a livello root - Singleton
})
export class LoggerService {
  /**
   * Array che mantiene lo storico dei log
   * Privato per incapsulamento
   */
  private logs: string[] = [];

  constructor() {
    console.log('✅ LoggerService istanziato - Angular DI ha creato questa istanza');
  }

  /**
   * Registra un messaggio di log
   * @param message - Il messaggio da registrare
   */
  log(message: string): void {
    const timestamp = new Date().toLocaleTimeString('it-IT');
    const logEntry = `[${timestamp}] ${message}`;
    this.logs.push(logEntry);
    console.log('📝', logEntry);
  }

  /**
   * Registra un messaggio di errore
   * @param message - Il messaggio di errore
   */
  error(message: string): void {
    const timestamp = new Date().toLocaleTimeString('it-IT');
    const logEntry = `[${timestamp}] ❌ ERRORE: ${message}`;
    this.logs.push(logEntry);
    console.error(logEntry);
  }

  /**
   * Restituisce tutti i log registrati
   * @returns Array di log
   */
  getLogs(): string[] {
    return [...this.logs]; // Restituisce una copia per immutabilità
  }

  /**
   * Pulisce tutti i log
   */
  clearLogs(): void {
    this.logs = [];
    console.log('🗑️ Log cancellati');
  }
}
