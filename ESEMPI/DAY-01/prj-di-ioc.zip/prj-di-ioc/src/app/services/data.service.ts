/**
 * DataService - Servizio per la gestione dei dati
 * 
 * DEPENDENCY INJECTION (DI) CON DIPENDENZE:
 * Questo servizio dimostra come un servizio può dipendere da altri servizi.
 * Angular risolve automaticamente l'albero delle dipendenze:
 * 
 * DataService --dipende-da--> LoggerService
 * 
 * INVERSION OF CONTROL (IoC):
 * DataService non crea un'istanza di LoggerService, ma la riceve
 * tramite il costruttore. Questo inverte il controllo: non è più
 * DataService che controlla la creazione delle sue dipendenze,
 * ma Angular che inietta le dipendenze necessarie.
 */

import { Injectable } from '@angular/core';
import { LoggerService } from './logger.service';
import { BehaviorSubject, Observable } from 'rxjs';

/**
 * Interfaccia che definisce la struttura di un elemento dati
 */
export interface DataItem {
  id: number;
  name: string;
  description: string;
  createdAt: Date;
}

@Injectable({
  providedIn: 'root' // Singleton a livello di applicazione
})
export class DataService {
  /**
   * BehaviorSubject per gestire lo stato reattivo dei dati
   * Permette ai componenti di sottoscriversi ai cambiamenti
   */
  private dataSubject = new BehaviorSubject<DataItem[]>([]);
  
  /**
   * Observable esposto pubblicamente per i consumatori
   * Questo implementa il pattern Observer insieme a DI
   */
  public data$: Observable<DataItem[]> = this.dataSubject.asObservable();

  /**
   * Il costruttore dichiara le dipendenze richieste
   * 
   * DEPENDENCY INJECTION IN AZIONE:
   * Angular vede che DataService richiede LoggerService nel costruttore
   * e automaticamente:
   * 1. Verifica se LoggerService esiste già (è un Singleton)
   * 2. Se non esiste, lo crea
   * 3. Lo inyetta in questo servizio
   * 
   * @param logger - Iniettato automaticamente da Angular
   */
  constructor(private logger: LoggerService) {
    this.logger.log('DataService istanziato con LoggerService iniettato');
    this.initializeData();
  }

  /**
   * Inizializza i dati di esempio
   */
  private initializeData(): void {
    const initialData: DataItem[] = [
      {
        id: 1,
        name: 'Dependency Injection',
        description: 'Pattern che permette di iniettare dipendenze nei componenti',
        createdAt: new Date()
      },
      {
        id: 2,
        name: 'Inversion of Control',
        description: 'Principio che inverte il flusso di controllo dell\'applicazione',
        createdAt: new Date()
      }
    ];
    
    this.dataSubject.next(initialData);
    this.logger.log(`Dati inizializzati: ${initialData.length} elementi`);
  }

  /**
   * Aggiunge un nuovo elemento
   * @param name - Nome dell'elemento
   * @param description - Descrizione dell'elemento
   */
  addItem(name: string, description: string): void {
    const currentData = this.dataSubject.value;
    const newItem: DataItem = {
      id: currentData.length + 1,
      name,
      description,
      createdAt: new Date()
    };
    
    const updatedData = [...currentData, newItem];
    this.dataSubject.next(updatedData);
    this.logger.log(`Nuovo elemento aggiunto: ${name}`);
  }

  /**
   * Rimuove un elemento per ID
   * @param id - ID dell'elemento da rimuovere
   */
  removeItem(id: number): void {
    const currentData = this.dataSubject.value;
    const updatedData = currentData.filter(item => item.id !== id);
    this.dataSubject.next(updatedData);
    this.logger.log(`Elemento rimosso: ID ${id}`);
  }

  /**
   * Restituisce tutti gli elementi correnti
   * @returns Array di DataItem
   */
  getItems(): DataItem[] {
    return this.dataSubject.value;
  }
}
