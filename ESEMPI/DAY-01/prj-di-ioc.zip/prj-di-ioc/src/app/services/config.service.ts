/**
 * ConfigService - Servizio di Configurazione
 * 
 * INJECTION TOKEN e PROVIDER PERSONALIZZATI:
 * Questo servizio dimostra l'uso di InjectionToken per fornire
 * configurazioni personalizzate che possono essere iniettate.
 * 
 * Questo è un pattern avanzato di DI che permette di:
 * - Iniettare valori primitivi o oggetti di configurazione
 * - Creare provider personalizzati
 * - Testare facilmente sostituendo le configurazioni
 */

import { Injectable, InjectionToken } from '@angular/core';

/**
 * Interfaccia per la configurazione dell'applicazione
 */
export interface AppConfig {
  apiUrl: string;
  apiKey: string;
  enableLogging: boolean;
  maxRetries: number;
}

/**
 * InjectionToken per la configurazione
 * 
 * DEPENDENCY INJECTION AVANZATA:
 * InjectionToken permette di creare un token univoco per iniettare
 * valori che non sono classi (come oggetti di configurazione).
 * 
 * Questo è particolarmente utile per:
 * - Configurazioni
 * - Valori costanti
 * - Factory functions
 */
export const APP_CONFIG = new InjectionToken<AppConfig>('app.config', {
  providedIn: 'root',
  factory: () => ({
    apiUrl: 'https://api.example.com',
    apiKey: 'demo-key-12345',
    enableLogging: true,
    maxRetries: 3
  })
});

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  /**
   * Configurazione di default
   * In un'applicazione reale, questa potrebbe essere caricata
   * da un file di configurazione o da variabili d'ambiente
   */
  private config: AppConfig = {
    apiUrl: 'https://api.example.com',
    apiKey: 'demo-key-12345',
    enableLogging: true,
    maxRetries: 3
  };

  constructor() {
    console.log('⚙️ ConfigService istanziato');
  }

  /**
   * Ottiene un valore di configurazione
   * @param key - Chiave della configurazione
   * @returns Valore della configurazione
   */
  get<K extends keyof AppConfig>(key: K): AppConfig[K] {
    return this.config[key];
  }

  /**
   * Imposta un valore di configurazione
   * @param key - Chiave della configurazione
   * @param value - Nuovo valore
   */
  set<K extends keyof AppConfig>(key: K, value: AppConfig[K]): void {
    this.config[key] = value;
  }

  /**
   * Restituisce l'intera configurazione
   * @returns Oggetto di configurazione completo
   */
  getAll(): AppConfig {
    return { ...this.config };
  }
}
