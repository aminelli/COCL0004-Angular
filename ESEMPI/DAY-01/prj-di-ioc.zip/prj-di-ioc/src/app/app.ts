/**
 * AppComponent - Componente Root dell'applicazione
 *
 * DEPENDENCY INJECTION nei COMPONENTI:
 * I componenti Angular possono iniettare servizi esattamente come i servizi
 * possono iniettare altri servizi. Questo crea un'architettura uniforme
 * e facilmente testabile.
 *
 * INVERSION OF CONTROL (IoC):
 * Il componente non ha bisogno di sapere COME creare i servizi o
 * gestire le loro dipendenze. Semplicemente dichiara di cosa ha bisogno
 * e Angular si occupa del resto.
 */

import { Component, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { LoggerService } from './services/logger.service';
import { DataListComponent } from './components/data-list/data-list.component';
import { AddDataFormComponent } from './components/add-data-form/add-data-form.component';
import { LogViewerComponent } from './components/log-viewer/log-viewer.component';
import { ApiDemoComponent } from './components/api-demo/api-demo.component';

@Component({
  /**
   * selector: tag HTML che rappresenta questo componente
   */
  selector: 'app-root',
  /**
   * standalone: true - Angular 21 best practice
   * I componenti standalone non richiedono NgModule
   */
  standalone: true,

  //imports: [RouterOutlet],
  /**
   * imports: altri componenti e moduli necessari
   * Questo è il nuovo modo di dichiarare le dipendenze in Angular 21
   */
  imports: [
    CommonModule,
    DataListComponent,
    AddDataFormComponent,
    LogViewerComponent,
    ApiDemoComponent,
  ],

  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App implements OnInit {
  //protected readonly title = signal('Angular 21 - Dependency Injection & IoC Demo');
  title = 'Angular 21 - Dependency Injection & IoC Demo';
  /**
   * CONSTRUCTOR INJECTION - Il metodo più comune di DI
   *
   * Il costruttore dichiara le dipendenze richieste.
   * Angular automaticamente:
   * 1. Risolve le dipendenze guardando i provider registrati
   * 2. Crea le istanze necessarie (o recupera quelle esistenti)
   * 3. Le inietta nel componente
   *
   * @param logger - LoggerService iniettato da Angular DI system
   */
  constructor(private logger: LoggerService) {
    /**
     * Il costruttore viene chiamato PRIMA di ngOnInit
     * Le dipendenze sono già disponibili qui
     */
    this.logger.log('🚀 AppComponent istanziato');
  }

  /**
   * Lifecycle hook - chiamato dopo la creazione del componente
   * Questo è il posto ideale per inizializzare il componente
   * utilizzando i servizi iniettati
   */
  ngOnInit(): void {
    this.logger.log('✨ AppComponent inizializzato');
    this.logger.log('📚 Dimostrazione di Dependency Injection e Inversion of Control');
  }
}
