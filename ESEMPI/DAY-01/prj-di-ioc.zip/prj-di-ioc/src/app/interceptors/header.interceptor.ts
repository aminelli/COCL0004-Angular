/**
 * HeaderInterceptor - Aggiunge header alle richieste HTTP
 * 
 * DEPENDENCY INJECTION con MULTIPLE SERVICES:
 * Questo interceptor dimostra come iniettare multipli servizi
 * in un contesto funzionale usando inject().
 */

import { HttpInterceptorFn, HttpRequest, HttpHandlerFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { ConfigService } from '../services/config.service';
import { LoggerService } from '../services/logger.service';

/**
 * Interceptor che aggiunge header personalizzati
 * 
 * FUNCTIONAL DEPENDENCY INJECTION:
 * Usa inject() per ottenere ConfigService e LoggerService.
 * Questo dimostra come DI funziona anche in contesti funzionali.
 */
export const headerInterceptor: HttpInterceptorFn = (req, next) => {
  /**
   * Iniezione di multipli servizi con inject()
   * 
   * BEST PRACTICE Angular 21:
   * - Preferire inject() nei contesti funzionali
   * - Più pulito e moderno rispetto ai constructor
   * - Supporta tree-shaking meglio
   */
  const config = inject(ConfigService);
  const logger = inject(LoggerService);

  // Ottiene la chiave API dalla configurazione
  const apiKey = config.get('apiKey');

  /**
   * Clona la richiesta e aggiunge header personalizzati
   * 
   * IMMUTABILITÀ:
   * Le richieste HTTP sono immutabili in Angular.
   * Dobbiamo clonare per modificare.
   */
  const modifiedReq = req.clone({
    setHeaders: {
      'X-API-Key': apiKey,
      'X-App-Version': '1.0.0',
      'X-Timestamp': new Date().toISOString()
    }
  });

  logger.log(`🔑 Header aggiunti alla richiesta ${req.method}`);

  // Passa la richiesta modificata al prossimo handler
  return next(modifiedReq);
};
