/**
 * LoggingInterceptor - HTTP Interceptor con Dependency Injection
 * 
 * DEPENDENCY INJECTION in INTERCEPTORS:
 * Gli interceptors sono un esempio avanzato di come Angular usa DI.
 * Possono iniettare servizi e intercettare tutte le richieste HTTP.
 * 
 * INVERSION OF CONTROL:
 * Gli interceptor non hanno il controllo su QUANDO vengono eseguiti.
 * Angular gestisce automaticamente l'esecuzione degli interceptor
 * nella catena di richieste HTTP.
 * 
 * In Angular 21, gli interceptors sono funzionali invece che class-based.
 */

import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpEvent } from '@angular/common/http';
import { inject } from '@angular/core';
import { Observable, tap, catchError, throwError } from 'rxjs';
import { LoggerService } from '../services/logger.service';

/**
 * Interceptor funzionale (Angular 21 best practice)
 * 
 * FUNCTIONAL INJECTION con inject():
 * In Angular 21, possiamo usare la funzione inject() per iniettare
 * servizi anche al di fuori dei costruttori. Questo è particolarmente
 * utile per gli interceptor funzionali.
 * 
 * @param req - La richiesta HTTP
 * @param next - Il prossimo handler nella catena
 * @returns Observable dell'evento HTTP
 */
export const loggingInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<HttpEvent<unknown>> => {
  /**
   * INJECT FUNCTION - Nuova API di Angular 21:
   * La funzione inject() permette di iniettare servizi in contesti funzionali.
   * Non richiede un costruttore o decoratori @Injectable.
   * 
   * DEPENDENCY INJECTION MODERNA:
   * Questo è il futuro della DI in Angular - più funzionale, meno class-based
   */
  const logger = inject(LoggerService);

  // Log della richiesta in uscita
  logger.log(`🌐 HTTP ${req.method} → ${req.url}`);
  const startTime = Date.now();

  /**
   * Passa la richiesta al prossimo handler e intercetta la risposta
   */
  return next(req).pipe(
    // Log della risposta in caso di successo
    tap(() => {
      const duration = Date.now() - startTime;
      logger.log(`✅ HTTP ${req.method} completata in ${duration}ms`);
    }),
    
    // Log dell'errore in caso di fallimento
    catchError((error) => {
      const duration = Date.now() - startTime;
      logger.error(`❌ HTTP ${req.method} fallita dopo ${duration}ms: ${error.message}`);
      return throwError(() => error);
    })
  );
};
