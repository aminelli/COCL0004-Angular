/**
 * AuthGuard - Route Guard con Dependency Injection
 * 
 * DEPENDENCY INJECTION in GUARDS:
 * I guards sono servizi speciali che proteggono le routes.
 * Possono iniettare altri servizi per verificare autorizzazioni.
 * 
 * In Angular 21, i guards sono funzionali invece che class-based.
 */

import { CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { inject } from '@angular/core';
import { LoggerService } from '../services/logger.service';
import { ConfigService } from '../services/config.service';

/**
 * Guard funzionale per proteggere le routes
 * 
 * FUNCTIONAL GUARD con DEPENDENCY INJECTION:
 * Angular 21 preferisce guards funzionali che usano inject()
 * invece di class-based guards con constructor injection.
 * 
 * INVERSION OF CONTROL:
 * Il guard non controlla QUANDO viene eseguito.
 * Angular Router decide quando eseguire il guard basandosi
 * sulla navigazione dell'utente.
 * 
 * @param route - La route attivata
 * @param state - Lo stato del router
 * @returns true se l'accesso è consentito, false altrimenti
 */
export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
): boolean => {
  /**
   * FUNCTIONAL DEPENDENCY INJECTION:
   * Usa inject() per ottenere i servizi necessari
   */
  const logger = inject(LoggerService);
  const config = inject(ConfigService);

  logger.log(`🛡️ AuthGuard verificando accesso a: ${state.url}`);

  /**
   * Logica di autenticazione (simulata)
   * In un'app reale, controllerebbe token, sessioni, ecc.
   */
  const isLoggingEnabled = config.get('enableLogging');
  
  // Simuliamo che l'utente è sempre autenticato se il logging è abilitato
  const isAuthenticated = isLoggingEnabled;

  if (isAuthenticated) {
    logger.log('✅ Autenticazione verificata - accesso consentito');
    return true;
  } else {
    logger.error('❌ Autenticazione fallita - accesso negato');
    return false;
  }
};

/**
 * Guard per verificare se l'utente ha un ruolo specifico
 * 
 * PARAMETRIC GUARD FACTORY:
 * Questa è una factory function che crea un guard parametrizzato.
 * Dimostra un pattern avanzato di Dependency Injection.
 * 
 * @param requiredRole - Il ruolo richiesto
 * @returns Guard function
 */
export const roleGuard = (requiredRole: string): CanActivateFn => {
  return (route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean => {
    const logger = inject(LoggerService);
    
    logger.log(`🔐 RoleGuard verificando ruolo '${requiredRole}' per: ${state.url}`);
    
    /**
     * In un'app reale, questo controllerebbe i ruoli dell'utente
     * da un AuthService iniettato
     */
    const userRoles = ['user', 'admin']; // Simulato
    const hasRole = userRoles.includes(requiredRole);
    
    if (hasRole) {
      logger.log(`✅ Ruolo '${requiredRole}' verificato`);
      return true;
    } else {
      logger.error(`❌ Ruolo '${requiredRole}' non trovato`);
      return false;
    }
  };
};
