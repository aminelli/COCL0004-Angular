import { Routes } from '@angular/router';

// Configurazione delle routes dell'applicazione
// In Angular 21, utilizziamo il pattern standalone e lazy loading per ottimizzare le performance
export const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadComponent: () => import('./components/home/home').then(m => m.HomeComponent),
    title: 'Home - Angular Aria Demo'
  },
  {
    path: 'dialog',
    loadComponent: () => import('./components/dialog-demo/dialog-demo').then(m => m.DialogDemoComponent),
    title: 'Dialog Pattern - Angular Aria Demo'
  },
  {
    path: 'tabs',
    loadComponent: () => import('./components/tabs-demo/tabs-demo').then(m => m.TabsDemoComponent),
    title: 'Tabs Pattern - Angular Aria Demo'
  },
  {
    path: 'accordion',
    loadComponent: () => import('./components/accordion-demo/accordion-demo').then(m => m.AccordionDemoComponent),
    title: 'Accordion Pattern - Angular Aria Demo'
  },
  {
    path: 'menu',
    loadComponent: () => import('./components/menu-demo/menu-demo').then(m => m.MenuDemoComponent),
    title: 'Menu Pattern - Angular Aria Demo'
  },
  {
    path: 'form',
    loadComponent: () => import('./components/form-demo/form-demo').then(m => m.FormDemoComponent),
    title: 'Form Accessibility - Angular Aria Demo'
  },
  {
    path: 'live-region',
    loadComponent: () => import('./components/live-region-demo/live-region-demo').then(m => m.LiveRegionDemoComponent),
    title: 'Live Regions - Angular Aria Demo'
  },
  {
    path: 'combobox',
    loadComponent: () => import('./components/combobox-demo/combobox-demo').then(m => m.ComboboxDemoComponent),
    title: 'Combobox Pattern - Angular Aria Demo'
  },
  {
    path: '**',
    redirectTo: 'home'
  }
];
