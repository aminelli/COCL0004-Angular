import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Componente TabsDemo - Dimostra l'implementazione del pattern Tabs
 * 
 * Pattern WAI-ARIA implementato:
 *  - role="tablist" sul contenitore delle tabs
 *  - role="tab" su ogni tab
 *  - role="tabpanel" su ogni pannello
 *  - aria-selected per indicare la tab attiva
 *  - aria-controls per collegare tab e pannelli
 *  - Navigazione con tastiera (frecce sinistra/destra)
 *  - Home/End per andare alla prima/ultima tab
 */
@Component({
  selector: 'app-tabs-demo',
  imports: [CommonModule],
  templateUrl: './tabs-demo.html',
  styleUrl: './tabs-demo.scss',
})
export class TabsDemoComponent {
  // Signal per l'indice della tab attiva
  protected readonly activeTabIndex = signal(0);
  
  // Signal contenente i dati delle tabs
  protected readonly tabs = signal([
    {
      id: 'tab-1',
      panelId: 'panel-1',
      label: 'Introduzione',
      icon: 'bi-book',
      content: `
        <h3>Benvenuto nel pattern Tabs</h3>
        <p>Il pattern Tabs WAI-ARIA consente di organizzare il contenuto in sezioni
        che l'utente può navigare facilmente. Questo pattern è particolarmente utile
        quando si ha molto contenuto correlato che si desidera presentare senza
        sovraccaricare l'interfaccia utente.</p>
        <p><strong>Caratteristiche principali:</strong></p>
        <ul>
          <li>Organizzazione logica del contenuto</li>
          <li>Navigazione intuitiva</li>
          <li>Accessibilità completa con tastiera</li>
          <li>Supporto screen reader</li>
        </ul>
      `
    },
    {
      id: 'tab-2',
      panelId: 'panel-2',
      label: 'Attributi ARIA',
      icon: 'bi-code-square',
      content: `
        <h3>Attributi ARIA Utilizzati</h3>
        <dl>
          <dt><code>role="tablist"</code></dt>
          <dd>Identifica il contenitore delle tabs. Indica agli screen reader che
          questi elementi funzionano come un gruppo di tabs.</dd>
          
          <dt><code>role="tab"</code></dt>
          <dd>Identifica ogni singola tab. Gli utenti possono selezionare la tab
          per visualizzare il contenuto associato.</dd>
          
          <dt><code>role="tabpanel"</code></dt>
          <dd>Identifica il pannello di contenuto associato a ciascuna tab.</dd>
          
          <dt><code>aria-selected="true/false"</code></dt>
          <dd>Indica quale tab è attualmente selezionata.</dd>
          
          <dt><code>aria-controls</code></dt>
          <dd>Collega ogni tab al suo pannello corrispondente tramite ID.</dd>
          
          <dt><code>aria-labelledby</code></dt>
          <dd>Sul tabpanel, fa riferimento all'ID della tab per collegare il contenuto all'etichetta.</dd>
        </dl>
      `
    },
    {
      id: 'tab-3',
      panelId: 'panel-3',
      label: 'Navigazione Tastiera',
      icon: 'bi-keyboard',
      content: `
        <h3>Navigazione da Tastiera</h3>
        <p>Il pattern Tabs implementa una navigazione completa da tastiera seguendo
        le specifiche WAI-ARIA:</p>
        
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Tasto</th>
              <th>Azione</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><kbd>Tab</kbd></td>
              <td>Sposta il focus nella tablist. Se il focus è già su una tab,
              lo sposta al contenuto del tabpanel attivo.</td>
            </tr>
            <tr>
              <td><kbd>→</kbd> (Freccia Destra)</td>
              <td>Sposta il focus sulla tab successiva. Se il focus è sull'ultima tab,
              torna alla prima.</td>
            </tr>
            <tr>
              <td><kbd>←</kbd> (Freccia Sinistra)</td>
              <td>Sposta il focus sulla tab precedente. Se il focus è sulla prima tab,
              va all'ultima.</td>
            </tr>
            <tr>
              <td><kbd>Home</kbd></td>
              <td>Sposta il focus sulla prima tab.</td>
            </tr>
            <tr>
              <td><kbd>End</kbd></td>
              <td>Sposta il focus sull'ultima tab.</td>
            </tr>
          </tbody>
        </table>
      `
    },
    {
      id: 'tab-4',
      panelId: 'panel-4',
      label: 'Best Practices',
      icon: 'bi-star',
      content: `
        <h3>Best Practices per Tabs Accessibili</h3>
        
        <h4>1. Etichette Chiare e Descrittive</h4>
        <p>Le etichette delle tabs devono essere brevi ma descrittive del contenuto
        che rappresentano.</p>
        
        <h4>2. Gestione del Focus</h4>
        <p>Quando una tab viene selezionata, il focus deve rimanere sulla tab stessa.
        L'utente può poi usare Tab per spostarsi nel contenuto del pannello.</p>
        
        <h4>3. Indicatori Visivi</h4>
        <p>La tab attiva deve avere un indicatore visivo chiaro (colore, bordo, ecc.)
        e lo stato di focus deve essere ben visibile.</p>
        
        <h4>4. Contenuto Nascosto</h4>
        <p>I tabpanel non visualizzati dovrebbero avere <code>hidden</code> applicato
        per nasconderli completamente agli screen reader.</p>
        
        <h4>5. Orientamento</h4>
        <p>Usare <code>aria-orientation="horizontal"</code> o <code>"vertical"</code>
        sulla tablist per indicare l'orientamento.</p>
      `
    }
  ]);
  
  /**
   * Seleziona una tab specificata dall'indice
   */
  selectTab(index: number): void {
    this.activeTabIndex.set(index);
  }
  
  /**
   * Gestisce la navigazione da tastiera nelle tabs
   */
  handleKeyboardNavigation(event: KeyboardEvent, currentIndex: number): void {
    const tabsCount = this.tabs().length;
    let newIndex = currentIndex;
    
    switch (event.key) {
      case 'ArrowRight':
        // Vai alla tab successiva (loop alla prima se siamo sull'ultima)
        event.preventDefault();
        newIndex = (currentIndex + 1) % tabsCount;
        this.selectTab(newIndex);
        this.focusTab(newIndex);
        break;
        
      case 'ArrowLeft':
        // Vai alla tab precedente (loop all'ultima se siamo sulla prima)
        event.preventDefault();
        newIndex = currentIndex === 0 ? tabsCount - 1 : currentIndex - 1;
        this.selectTab(newIndex);
        this.focusTab(newIndex);
        break;
        
      case 'Home':
        // Vai alla prima tab
        event.preventDefault();
        this.selectTab(0);
        this.focusTab(0);
        break;
        
      case 'End':
        // Vai all'ultima tab
        event.preventDefault();
        this.selectTab(tabsCount - 1);
        this.focusTab(tabsCount - 1);
        break;
    }
  }
  
  /**
   * Sposta il focus sulla tab specificata
   */
  private focusTab(index: number): void {
    setTimeout(() => {
      const tab = document.getElementById(this.tabs()[index].id);
      tab?.focus();
    }, 10);
  }
}
