import { Component, signal, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

/**
 * Interfaccia per un elemento del menu
 */
interface MenuItem {
  id: string;
  label: string;
  icon?: string;
  shortcut?: string;
  disabled?: boolean;
  separator?: boolean;
  submenu?: MenuItem[];
}

/**
 * Componente dimostrativo del pattern Menu & Dropdown
 * 
 * Implementa un menu accessibile con:
 * - Menu principale orizzontale
 * - Dropdown con sottomenu
 * - Navigazione completa da tastiera
 * - Focus management
 * - ARIA roles e properties
 * 
 * Conforme alle specifiche WAI-ARIA per menu pattern.
 */
@Component({
  selector: 'app-menu-demo',
  imports: [CommonModule],
  templateUrl: './menu-demo.html',
  styleUrl: './menu-demo.scss',
})
export class MenuDemoComponent {
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);

  /**
   * Signal per il menu attualmente aperto (null se nessuno)
   */
  protected readonly openMenuId = signal<string | null>(null);

  /**
   * Signal per l'indice dell'item focalizzato nel menu aperto
   */
  protected readonly focusedItemIndex = signal<number>(0);

  /**
   * Signal per mostrare/nascondere la demo del dropdown
   */
  protected readonly showDropdownDemo = signal(true);

  /**
   * Struttura del menu principale
   */
  protected readonly menuItems = signal<MenuItem[]>([
    {
      id: 'file',
      label: 'File',
      icon: 'bi-file-earmark',
      submenu: [
        { id: 'new', label: 'Nuovo', icon: 'bi-file-plus', shortcut: 'Ctrl+N' },
        { id: 'open', label: 'Apri', icon: 'bi-folder-open', shortcut: 'Ctrl+O' },
        { id: 'save', label: 'Salva', icon: 'bi-save', shortcut: 'Ctrl+S' },
        { id: 'sep1', label: '', separator: true },
        { id: 'export', label: 'Esporta', icon: 'bi-box-arrow-up-right' },
        { id: 'print', label: 'Stampa', icon: 'bi-printer', shortcut: 'Ctrl+P' },
        { id: 'sep2', label: '', separator: true },
        { id: 'close', label: 'Chiudi', icon: 'bi-x-circle' }
      ]
    },
    {
      id: 'edit',
      label: 'Modifica',
      icon: 'bi-pencil',
      submenu: [
        { id: 'undo', label: 'Annulla', icon: 'bi-arrow-counterclockwise', shortcut: 'Ctrl+Z' },
        { id: 'redo', label: 'Ripeti', icon: 'bi-arrow-clockwise', shortcut: 'Ctrl+Y' },
        { id: 'sep3', label: '', separator: true },
        { id: 'cut', label: 'Taglia', icon: 'bi-scissors', shortcut: 'Ctrl+X' },
        { id: 'copy', label: 'Copia', icon: 'bi-clipboard', shortcut: 'Ctrl+C' },
        { id: 'paste', label: 'Incolla', icon: 'bi-clipboard-plus', shortcut: 'Ctrl+V' },
        { id: 'delete', label: 'Elimina', icon: 'bi-trash', disabled: true }
      ]
    },
    {
      id: 'view',
      label: 'Visualizza',
      icon: 'bi-eye',
      submenu: [
        { id: 'zoom-in', label: 'Zoom Avanti', icon: 'bi-zoom-in', shortcut: 'Ctrl++' },
        { id: 'zoom-out', label: 'Zoom Indietro', icon: 'bi-zoom-out', shortcut: 'Ctrl+-' },
        { id: 'zoom-reset', label: 'Zoom 100%', icon: 'bi-aspect-ratio', shortcut: 'Ctrl+0' },
        { id: 'sep4', label: '', separator: true },
        { id: 'fullscreen', label: 'Schermo Intero', icon: 'bi-arrows-fullscreen', shortcut: 'F11' }
      ]
    },
    {
      id: 'help',
      label: 'Aiuto',
      icon: 'bi-question-circle',
      submenu: [
        { id: 'docs', label: 'Documentazione', icon: 'bi-book' },
        { id: 'shortcuts', label: 'Scorciatoie', icon: 'bi-keyboard' },
        { id: 'sep5', label: '', separator: true },
        { id: 'about', label: 'Info', icon: 'bi-info-circle' }
      ]
    }
  ]);

  /**
   * Signal per i messaggi di azione
   */
  protected readonly actionMessage = signal<string>('');

  /**
   * Toggle apertura/chiusura menu
   */
  toggleMenu(menuId: string): void {
    const currentMenuId = this.openMenuId();
    if (currentMenuId === menuId) {
      this.closeMenu();
    } else {
      this.openMenuId.set(menuId);
      this.focusedItemIndex.set(0);
      this.focusFirstItem(menuId);
    }
  }

  /**
   * Apre un menu specifico
   */
  openMenu(menuId: string): void {
    this.openMenuId.set(menuId);
    this.focusedItemIndex.set(0);
    setTimeout(() => this.focusFirstItem(menuId), 50);
  }

  /**
   * Chiude il menu aperto
   */
  closeMenu(): void {
    this.openMenuId.set(null);
    this.focusedItemIndex.set(0);
  }

  /**
   * Gestisce il clic su un menu item
   */
  handleMenuItemClick(item: MenuItem): void {
    if (item.disabled || item.separator) return;
    
    this.actionMessage.set(`Azione: ${item.label}`);
    this.closeMenu();
    
    // Rimuovi il messaggio dopo 3 secondi
    setTimeout(() => this.actionMessage.set(''), 3000);
  }

  /**
   * Gestisce la navigazione da tastiera nel menu
   */
  handleMenuKeydown(event: KeyboardEvent, menuId: string): void {
    const menu = this.menuItems().find(m => m.id === menuId);
    if (!menu?.submenu) return;

    const items = menu.submenu.filter(item => !item.separator && !item.disabled);
    const currentIndex = this.focusedItemIndex();

    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        const nextIndex = (currentIndex + 1) % items.length;
        this.focusedItemIndex.set(nextIndex);
        this.focusMenuItem(items[nextIndex].id);
        break;

      case 'ArrowUp':
        event.preventDefault();
        const prevIndex = currentIndex === 0 ? items.length - 1 : currentIndex - 1;
        this.focusedItemIndex.set(prevIndex);
        this.focusMenuItem(items[prevIndex].id);
        break;

      case 'Home':
        event.preventDefault();
        this.focusedItemIndex.set(0);
        this.focusMenuItem(items[0].id);
        break;

      case 'End':
        event.preventDefault();
        this.focusedItemIndex.set(items.length - 1);
        this.focusMenuItem(items[items.length - 1].id);
        break;

      case 'Escape':
        event.preventDefault();
        this.closeMenu();
        this.focusMenuButton(menuId);
        break;

      case 'Enter':
      case ' ':
        event.preventDefault();
        this.handleMenuItemClick(items[currentIndex]);
        break;
    }
  }

  /**
   * Sposta il focus sul primo item del menu
   */
  private focusFirstItem(menuId: string): void {
    if (!this.isBrowser) return;
    const menu = this.menuItems().find(m => m.id === menuId);
    const firstItem = menu?.submenu?.find(item => !item.separator && !item.disabled);
    if (firstItem) {
      this.focusMenuItem(firstItem.id);
    }
  }

  /**
   * Sposta il focus su un menu item specifico
   */
  private focusMenuItem(itemId: string): void {
    if (!this.isBrowser) return;
    setTimeout(() => {
      const item = document.getElementById(`menu-item-${itemId}`);
      item?.focus();
    }, 10);
  }

  /**
   * Sposta il focus sul bottone del menu
   */
  private focusMenuButton(menuId: string): void {
    if (!this.isBrowser) return;
    setTimeout(() => {
      const button = document.getElementById(`menu-button-${menuId}`);
      button?.focus();
    }, 10);
  }

  /**
   * Chiude il menu quando si clicca fuori
   */
  handleClickOutside(event: MouseEvent): void {
    if (!this.isBrowser) return;
    const target = event.target as HTMLElement;
    if (!target.closest('.menu-container')) {
      this.closeMenu();
    }
  }
}
