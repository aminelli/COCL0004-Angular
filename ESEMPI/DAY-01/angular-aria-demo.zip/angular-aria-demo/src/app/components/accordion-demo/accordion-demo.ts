import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Interfaccia per un elemento dell'accordion
 */
interface AccordionItem {
  id: string;
  headerId: string;
  panelId: string;
  title: string;
  content: string;
  isExpanded: boolean;
}

/**
 * Componente dimostrativo del pattern Accordion
 * 
 * Il pattern Accordion permette di organizzare contenuti correlati in sezioni collassabili.
 * Solo una sezione (o più, a seconda della configurazione) può essere espansa alla volta.
 * 
 * Caratteristiche principali:
 * - Ogni header è un bottone con aria-expanded
 * - Ogni pannello ha role="region" e aria-labelledby
 * - Navigazione da tastiera con frecce su/giù
 * - Focus management corretto
 * - Animazioni smooth per apertura/chiusura
 */
@Component({
  selector: 'app-accordion-demo',
  imports: [CommonModule],
  templateUrl: './accordion-demo.html',
  styleUrl: './accordion-demo.scss',
})
export class AccordionDemoComponent {
  /**
   * Signal che contiene gli item dell'accordion
   * Ogni item ha il proprio stato isExpanded
   */
  protected readonly accordionItems = signal<AccordionItem[]>([
    {
      id: 'item-1',
      headerId: 'accordion-header-1',
      panelId: 'accordion-panel-1',
      title: 'Cos\'è WAI-ARIA?',
      content: 'WAI-ARIA (Web Accessibility Initiative - Accessible Rich Internet Applications) è una specifica tecnica che definisce un modo per rendere il contenuto web e le applicazioni web più accessibili alle persone con disabilità. ARIA fornisce un framework per aggiungere attributi che identificano funzionalità per l\'interazione dell\'utente, come i ruoli, le proprietà e gli stati degli elementi.',
      isExpanded: false
    },
    {
      id: 'item-2',
      headerId: 'accordion-header-2',
      panelId: 'accordion-panel-2',
      title: 'Quando usare un Accordion?',
      content: 'Gli accordion sono utili quando hai molte informazioni da mostrare in uno spazio limitato. Permettono agli utenti di scansionare rapidamente i titoli delle sezioni e aprire solo quelle di interesse. Sono particolarmente efficaci per FAQ, contenuti di help, descrizioni di prodotti con più caratteristiche, o qualsiasi contenuto che può essere organizzato in categorie logiche.',
      isExpanded: false
    },
    {
      id: 'item-3',
      headerId: 'accordion-header-3',
      panelId: 'accordion-panel-3',
      title: 'Attributi ARIA per Accordion',
      content: '<strong>aria-expanded:</strong> Indica se la sezione è aperta (true) o chiusa (false).<br><strong>aria-controls:</strong> Collega il bottone header al pannello che controlla.<br><strong>aria-labelledby:</strong> Sul pannello, riferisce l\'header che lo descrive.<br><strong>role="region":</strong> Identifica il pannello come una regione significativa della pagina.<br><strong>aria-disabled:</strong> Opzionale, indica se un header può essere attivato.',
      isExpanded: false
    },
    {
      id: 'item-4',
      headerId: 'accordion-header-4',
      panelId: 'accordion-panel-4',
      title: 'Navigazione da Tastiera',
      content: '<strong>Tab:</strong> Sposta il focus tra i bottoni header dell\'accordion.<br><strong>Enter o Space:</strong> Apre/chiude la sezione focalizzata.<br><strong>Freccia Giù:</strong> Sposta il focus all\'header successivo (opzionale ma raccomandato).<br><strong>Freccia Su:</strong> Sposta il focus all\'header precedente (opzionale ma raccomandato).<br><strong>Home:</strong> Sposta il focus al primo header (opzionale).<br><strong>End:</strong> Sposta il focus all\'ultimo header (opzionale).',
      isExpanded: false
    },
    {
      id: 'item-5',
      headerId: 'accordion-header-5',
      panelId: 'accordion-panel-5',
      title: 'Best Practices',
      content: 'Usa heading appropriati (h2, h3, etc.) per gli header. Assicurati che il contenuto del pannello sia accessibile quando espanso. Fornisci indicatori visivi chiari dello stato (icone, colori). Implementa animazioni smooth ma non troppo lente. Considera se permettere più pannelli aperti simultaneamente o solo uno (questo esempio permette multipli). Testa con screen reader per verificare l\'esperienza utente.',
      isExpanded: false
    }
  ]);

  /**
   * Signal per controllare se permettere solo un pannello aperto alla volta
   * Impostato a false per permettere multipli pannelli aperti
   */
  protected readonly allowMultiple = signal(true);

  /**
   * Toggle dello stato expanded di un item
   * 
   * @param index - Indice dell'item da toggleare
   */
  toggleItem(index: number): void {
    const items = this.accordionItems();
    const currentItem = items[index];

    // Se non permettiamo multipli pannelli aperti, chiudiamo tutti gli altri
    if (!this.allowMultiple() && !currentItem.isExpanded) {
      items.forEach((item, i) => {
        if (i !== index) {
          item.isExpanded = false;
        }
      });
    }

    // Toggle dello stato dell'item corrente
    currentItem.isExpanded = !currentItem.isExpanded;

    // Aggiorna il signal (importante per il change detection)
    this.accordionItems.set([...items]);
  }

  /**
   * Espande tutti i pannelli
   */
  expandAll(): void {
    const items = this.accordionItems();
    items.forEach(item => item.isExpanded = true);
    this.accordionItems.set([...items]);
  }

  /**
   * Collassa tutti i pannelli
   */
  collapseAll(): void {
    const items = this.accordionItems();
    items.forEach(item => item.isExpanded = false);
    this.accordionItems.set([...items]);
  }

  /**
   * Toggle della modalità "solo uno aperto"
   */
  toggleAllowMultiple(): void {
    this.allowMultiple.update(value => !value);
    
    // Se passiamo a "solo uno", chiudiamo tutti tranne il primo aperto
    if (!this.allowMultiple()) {
      const items = this.accordionItems();
      let foundFirst = false;
      items.forEach(item => {
        if (item.isExpanded && !foundFirst) {
          foundFirst = true;
        } else if (item.isExpanded) {
          item.isExpanded = false;
        }
      });
      this.accordionItems.set([...items]);
    }
  }

  /**
   * Gestisce la navigazione da tastiera tra gli header dell'accordion
   * Implementa le raccomandazioni WAI-ARIA per la navigazione con frecce
   * 
   * @param event - Evento tastiera
   * @param currentIndex - Indice dell'header corrente
   */
  handleKeyboardNavigation(event: KeyboardEvent, currentIndex: number): void {
    const itemsCount = this.accordionItems().length;
    let targetIndex = currentIndex;

    switch (event.key) {
      case 'ArrowDown':
        // Sposta il focus all'header successivo
        event.preventDefault();
        targetIndex = (currentIndex + 1) % itemsCount;
        this.focusHeader(targetIndex);
        break;

      case 'ArrowUp':
        // Sposta il focus all'header precedente
        event.preventDefault();
        targetIndex = currentIndex === 0 ? itemsCount - 1 : currentIndex - 1;
        this.focusHeader(targetIndex);
        break;

      case 'Home':
        // Sposta il focus al primo header
        event.preventDefault();
        this.focusHeader(0);
        break;

      case 'End':
        // Sposta il focus all'ultimo header
        event.preventDefault();
        this.focusHeader(itemsCount - 1);
        break;

      // Enter e Space sono gestiti nativamente dal bottone
    }
  }

  /**
   * Sposta il focus all'header specificato
   * 
   * @param index - Indice dell'header da focalizzare
   */
  private focusHeader(index: number): void {
    const items = this.accordionItems();
    const headerId = items[index].headerId;
    
    // Usiamo setTimeout per permettere al DOM di aggiornarsi
    setTimeout(() => {
      const headerButton = document.getElementById(headerId);
      headerButton?.focus();
    }, 10);
  }
}
