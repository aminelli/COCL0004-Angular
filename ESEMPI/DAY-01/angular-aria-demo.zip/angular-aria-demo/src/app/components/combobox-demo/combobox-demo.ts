import { Component, signal, computed, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';

/**
 * Interfaccia per un'opzione del combobox
 */
interface ComboboxOption {
  id: string;
  label: string;
  category?: string;
  disabled?: boolean;
}

/**
 * Componente dimostrativo per Combobox & Autocomplete Pattern
 * 
 * Implementa un combobox accessibile con:
 * - Filtraggio in tempo reale
 * - Navigazione da tastiera completa
 * - aria-autocomplete="list"
 * - aria-expanded per stato dropdown
 * - aria-activedescendant per focus virtuale
 * - role="combobox" e role="listbox"
 * - Supporto per categorie
 * - Evidenziazione match di ricerca
 * 
 * Conforme alle specifiche WAI-ARIA per combobox pattern.
 */
@Component({
  selector: 'app-combobox-demo',
  imports: [CommonModule, FormsModule],
  templateUrl: './combobox-demo.html',
  styleUrl: './combobox-demo.scss',
})
export class ComboboxDemoComponent {
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);

  /**
   * Signal per il valore dell'input
   */
  protected readonly searchValue = signal('');

  /**
   * Signal per lo stato aperto/chiuso del dropdown
   */
  protected readonly isExpanded = signal(false);

  /**
   * Signal per l'indice dell'opzione attiva
   */
  protected readonly activeOptionIndex = signal(-1);

  /**
   * Signal per l'opzione selezionata
   */
  protected readonly selectedOption = signal<ComboboxOption | null>(null);

  /**
   * Dataset completo di linguaggi di programmazione
   */
  protected readonly allOptions = signal<ComboboxOption[]>([
    // Frontend
    { id: 'js', label: 'JavaScript', category: 'Frontend' },
    { id: 'ts', label: 'TypeScript', category: 'Frontend' },
    { id: 'html', label: 'HTML', category: 'Frontend' },
    { id: 'css', label: 'CSS', category: 'Frontend' },
    { id: 'react', label: 'React', category: 'Frontend' },
    { id: 'angular', label: 'Angular', category: 'Frontend' },
    { id: 'vue', label: 'Vue.js', category: 'Frontend' },
    
    // Backend
    { id: 'java', label: 'Java', category: 'Backend' },
    { id: 'python', label: 'Python', category: 'Backend' },
    { id: 'csharp', label: 'C#', category: 'Backend' },
    { id: 'php', label: 'PHP', category: 'Backend' },
    { id: 'ruby', label: 'Ruby', category: 'Backend' },
    { id: 'go', label: 'Go', category: 'Backend' },
    { id: 'rust', label: 'Rust', category: 'Backend' },
    { id: 'kotlin', label: 'Kotlin', category: 'Backend' },
    
    // Database
    { id: 'sql', label: 'SQL', category: 'Database' },
    { id: 'nosql', label: 'NoSQL', category: 'Database' },
    { id: 'mongodb', label: 'MongoDB', category: 'Database' },
    { id: 'postgres', label: 'PostgreSQL', category: 'Database' },
    
    // Mobile
    { id: 'swift', label: 'Swift', category: 'Mobile' },
    { id: 'objectivec', label: 'Objective-C', category: 'Mobile' },
    { id: 'dart', label: 'Dart', category: 'Mobile' },
  ]);

  /**
   * Opzioni filtrate basate sulla ricerca
   */
  protected readonly filteredOptions = computed(() => {
    const search = this.searchValue().toLowerCase().trim();
    if (!search) {
      return this.allOptions();
    }

    return this.allOptions().filter(option => 
      option.label.toLowerCase().includes(search) ||
      option.category?.toLowerCase().includes(search)
    );
  });

  /**
   * ID dell'opzione attiva per aria-activedescendant
   */
  protected readonly activeDescendant = computed(() => {
    const index = this.activeOptionIndex();
    const options = this.filteredOptions();
    return index >= 0 && index < options.length 
      ? `option-${options[index].id}` 
      : '';
  });

  /**
   * Gestisce il cambiamento del valore di input
   */
  onInputChange(value: string): void {
    this.searchValue.set(value);
    this.isExpanded.set(true);
    this.activeOptionIndex.set(-1);
  }

  /**
   * Gestisce il focus sull'input
   */
  onInputFocus(): void {
    if (this.searchValue().trim() || this.filteredOptions().length > 0) {
      this.isExpanded.set(true);
    }
  }

  /**
   * Gestisce la navigazione da tastiera
   */
  onKeyDown(event: KeyboardEvent): void {
    const options = this.filteredOptions();
    const currentIndex = this.activeOptionIndex();

    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        if (!this.isExpanded()) {
          this.isExpanded.set(true);
          this.activeOptionIndex.set(0);
        } else {
          const nextIndex = Math.min(currentIndex + 1, options.length - 1);
          this.activeOptionIndex.set(nextIndex);
          this.scrollToOption(nextIndex);
        }
        break;

      case 'ArrowUp':
        event.preventDefault();
        if (this.isExpanded()) {
          const prevIndex = Math.max(currentIndex - 1, 0);
          this.activeOptionIndex.set(prevIndex);
          this.scrollToOption(prevIndex);
        }
        break;

      case 'Enter':
        event.preventDefault();
        if (this.isExpanded() && currentIndex >= 0) {
          this.selectOption(options[currentIndex]);
        }
        break;

      case 'Escape':
        event.preventDefault();
        this.isExpanded.set(false);
        this.activeOptionIndex.set(-1);
        break;

      case 'Home':
        if (this.isExpanded()) {
          event.preventDefault();
          this.activeOptionIndex.set(0);
          this.scrollToOption(0);
        }
        break;

      case 'End':
        if (this.isExpanded()) {
          event.preventDefault();
          this.activeOptionIndex.set(options.length - 1);
          this.scrollToOption(options.length - 1);
        }
        break;
    }
  }

  /**
   * Seleziona un'opzione
   */
  selectOption(option: ComboboxOption): void {
    if (option.disabled) return;
    
    this.selectedOption.set(option);
    this.searchValue.set(option.label);
    this.isExpanded.set(false);
    this.activeOptionIndex.set(-1);
  }

  /**
   * Resetta la selezione
   */
  clearSelection(): void {
    this.selectedOption.set(null);
    this.searchValue.set('');
    this.isExpanded.set(false);
    this.activeOptionIndex.set(-1);
    
    // Sposta il focus sull'input
    if (this.isBrowser) {
      setTimeout(() => {
        const input = document.getElementById('combobox-input') as HTMLInputElement;
        input?.focus();
      }, 10);
    }
  }

  /**
   * Scrolla per rendere visibile l'opzione
   */
  private scrollToOption(index: number): void {
    if (!this.isBrowser) return;
    
    setTimeout(() => {
      const options = this.filteredOptions();
      const optionId = `option-${options[index]?.id}`;
      const optionElement = document.getElementById(optionId);
      
      if (optionElement) {
        optionElement.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }, 10);
  }

  /**
   * Gestisce il click fuori dal combobox
   */
  handleClickOutside(event: MouseEvent): void {
    if (!this.isBrowser) return;
    
    const target = event.target as HTMLElement;
    if (!target.closest('.combobox-container')) {
      this.isExpanded.set(false);
      this.activeOptionIndex.set(-1);
    }
  }

  /**
   * Ottiene le categorie uniche dalle opzioni filtrate
   */
  getCategories(): string[] {
    const categories = new Set<string>();
    this.filteredOptions().forEach(option => {
      if (option.category) {
        categories.add(option.category);
      }
    });
    return Array.from(categories).sort();
  }

  /**
   * Ottiene le opzioni per una categoria
   */
  getOptionsByCategory(category: string): ComboboxOption[] {
    return this.filteredOptions().filter(opt => opt.category === category);
  }

  /**
   * Evidenzia il match nella label
   */
  highlightMatch(label: string): string {
    const search = this.searchValue().trim();
    if (!search) return label;

    const regex = new RegExp(`(${search})`, 'gi');
    return label.replace(regex, '<mark>$1</mark>');
  }
}
