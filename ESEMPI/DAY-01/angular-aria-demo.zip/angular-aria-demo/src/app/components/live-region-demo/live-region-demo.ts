import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Tipi di notifica supportati
 */
type NotificationType = 'success' | 'error' | 'warning' | 'info';

/**
 * Livello di priorità della live region
 */
type LivePriority = 'polite' | 'assertive' | 'off';

/**
 * Interfaccia per una notifica
 */
interface Notification {
  id: number;
  type: NotificationType;
  message: string;
  priority: LivePriority;
  timestamp: Date;
  autoHide: boolean;
}

/**
 * Componente dimostrativo per Live Regions
 * 
 * Le Live Regions sono aree della pagina che annunciano dinamicamente
 * cambiamenti agli utenti di screen reader senza spostare il focus.
 * 
 * Implementa:
 * - aria-live con priorità polite e assertive
 * - role="status" e role="alert"
 * - aria-atomic per controllare cosa viene annunciato
 * - Notifiche con auto-hide
 * - Log di eventi persistente
 */
@Component({
  selector: 'app-live-region-demo',
  imports: [CommonModule],
  templateUrl: './live-region-demo.html',
  styleUrl: './live-region-demo.scss',
})
export class LiveRegionDemoComponent {
  /**
   * Signal per le notifiche attive
   */
  protected readonly notifications = signal<Notification[]>([]);

  /**
   * Signal per il log degli eventi
   */
  protected readonly eventLog = signal<string[]>([]);

  /**
   * Signal per il contatore di operazioni in corso
   */
  protected readonly loadingCount = signal(0);

  /**
   * Signal per il messaggio di stato corrente
   */
  protected readonly statusMessage = signal('');

  /**
   * Contatore per ID univoci
   */
  private nextNotificationId = 1;

  /**
   * Aggiunge una notifica
   */
  addNotification(
    type: NotificationType,
    message: string,
    priority: LivePriority = 'polite',
    autoHide: boolean = true
  ): void {
    const notification: Notification = {
      id: this.nextNotificationId++,
      type,
      message,
      priority,
      timestamp: new Date(),
      autoHide
    };

    this.notifications.update(notifications => [...notifications, notification]);
    
    // Aggiungi al log
    this.addToLog(`[${type.toUpperCase()}] ${message}`);

    // Auto-hide dopo 5 secondi se richiesto
    if (autoHide) {
      setTimeout(() => {
        this.removeNotification(notification.id);
      }, 5000);
    }
  }

  /**
   * Rimuove una notifica
   */
  removeNotification(id: number): void {
    this.notifications.update(notifications =>
      notifications.filter(n => n.id !== id)
    );
  }

  /**
   * Rimuove tutte le notifiche
   */
  clearNotifications(): void {
    this.notifications.set([]);
  }

  /**
   * Aggiunge un messaggio al log
   */
  private addToLog(message: string): void {
    const timestamp = new Date().toLocaleTimeString('it-IT');
    this.eventLog.update(log => [
      `[${timestamp}] ${message}`,
      ...log
    ].slice(0, 50)); // Mantieni solo gli ultimi 50 eventi
  }

  /**
   * Pulisce il log
   */
  clearLog(): void {
    this.eventLog.set([]);
    this.addToLog('Log pulito');
  }

  /**
   * Simula operazione di salvataggio
   */
  simulateSave(): void {
    this.loadingCount.update(c => c + 1);
    this.statusMessage.set('Salvataggio in corso...');
    
    setTimeout(() => {
      this.loadingCount.update(c => c - 1);
      this.statusMessage.set('Salvataggio completato');
      this.addNotification('success', 'File salvato con successo!');
      
      setTimeout(() => this.statusMessage.set(''), 2000);
    }, 2000);
  }

  /**
   * Simula operazione di caricamento
   */
  simulateLoad(): void {
    this.loadingCount.update(c => c + 1);
    this.statusMessage.set('Caricamento dati...');
    
    setTimeout(() => {
      this.loadingCount.update(c => c - 1);
      this.statusMessage.set('Dati caricati');
      this.addNotification('info', '125 elementi caricati dal server');
      
      setTimeout(() => this.statusMessage.set(''), 2000);
    }, 1500);
  }

  /**
   * Simula errore di rete
   */
  simulateError(): void {
    this.addNotification(
      'error',
      'Errore di connessione al server. Riprova più tardi.',
      'assertive',
      false // Non auto-hide per gli errori
    );
  }

  /**
   * Simula warning
   */
  simulateWarning(): void {
    this.addNotification(
      'warning',
      'Attenzione: stai modificando un file di sistema',
      'polite'
    );
  }

  /**
   * Simula validazione form
   */
  simulateValidation(): void {
    this.statusMessage.set('Validazione in corso...');
    
    setTimeout(() => {
      const random = Math.random();
      if (random > 0.5) {
        this.statusMessage.set('Validazione superata');
        this.addNotification('success', 'Tutti i campi sono validi ✓');
      } else {
        this.statusMessage.set('Errori di validazione');
        this.addNotification(
          'error',
          'Trovati 3 errori nel form. Controlla i campi evidenziati.',
          'assertive',
          false
        );
      }
      
      setTimeout(() => this.statusMessage.set(''), 2000);
    }, 1000);
  }

  /**
   * Simula progresso upload
   */
  simulateUpload(): void {
    this.loadingCount.update(c => c + 1);
    let progress = 0;
    
    const interval = setInterval(() => {
      progress += 20;
      this.statusMessage.set(`Upload in corso: ${progress}%`);
      
      if (progress >= 100) {
        clearInterval(interval);
        this.loadingCount.update(c => c - 1);
        this.statusMessage.set('Upload completato');
        this.addNotification('success', 'File caricato con successo!');
        
        setTimeout(() => this.statusMessage.set(''), 2000);
      }
    }, 500);
  }

  /**
   * Ottiene la classe CSS per il tipo di notifica
   */
  getNotificationClass(type: NotificationType): string {
    const baseClass = 'alert';
    const typeMap = {
      success: 'alert-success',
      error: 'alert-danger',
      warning: 'alert-warning',
      info: 'alert-info'
    };
    return `${baseClass} ${typeMap[type]}`;
  }

  /**
   * Ottiene l'icona per il tipo di notifica
   */
  getNotificationIcon(type: NotificationType): string {
    const iconMap = {
      success: 'bi-check-circle-fill',
      error: 'bi-exclamation-circle-fill',
      warning: 'bi-exclamation-triangle-fill',
      info: 'bi-info-circle-fill'
    };
    return iconMap[type];
  }
}
