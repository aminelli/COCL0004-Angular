import { Component, signal, effect, PLATFORM_ID, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';

/**
 * Componente DialogDemo - Dimostra l'implementazione del pattern Dialog (Modal)
 * 
 * Pattern WAI-ARIA implementato:
 *  - role="dialog" sul contenitore del dialogo
 *  - aria-modal="true" per indicare che è modale
 *  - aria-labelledby per associare il titolo
 *  - aria-describedby per associare la descrizione
 *  - Focus trap: il focus rimane all'interno del dialog
 *  - Gestione ESC per chiudere il dialog
 *  - Ripristino del focus all'elemento che ha aperto il dialog
 */
@Component({
  selector: 'app-dialog-demo',
  imports: [CommonModule],
  templateUrl: './dialog-demo.html',
  styleUrl: './dialog-demo.scss',
})
export class DialogDemoComponent {
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);
  
  // Signal per controllare la visibilità del dialog
  protected readonly isDialogOpen = signal(false);
  
  // Signal per il tipo di dialog (informativo, conferma, alert)
  protected readonly dialogType = signal<'info' | 'confirm' | 'alert'>('info');
  
  // Signal per il risultato dell'azione dell'utente
  protected readonly userAction = signal<string>('');
  
  // Riferimento all'elemento che ha aperto il dialog (per il ripristino del focus)
  private triggerElement: HTMLElement | null = null;
  
  constructor() {
    // Effect per gestire il focus trap quando il dialog è aperto
    effect(() => {
      if (this.isBrowser && this.isDialogOpen()) {
        this.trapFocus();
        this.addEscapeListener();
      } else if (this.isBrowser) {
        this.removeEscapeListener();
      }
    });
  }
  
  /**
   * Apre il dialog di tipo specificato
   */
  openDialog(type: 'info' | 'confirm' | 'alert', event: Event): void {
    this.dialogType.set(type);
    this.triggerElement = event.target as HTMLElement;
    this.isDialogOpen.set(true);
  }
  
  /**
   * Chiude il dialog e ripristina il focus
   */
  closeDialog(action?: string): void {
    if (action) {
      this.userAction.set(action);
    }
    this.isDialogOpen.set(false);
    
    // Ripristina il focus all'elemento che ha aperto il dialog
    if (this.isBrowser) {
      setTimeout(() => {
        this.triggerElement?.focus();
      }, 100);
    }
  }
  
  /**
   * Gestisce il focus trap all'interno del dialog
   */
  private trapFocus(): void {
    if (!this.isBrowser) return;
    
    setTimeout(() => {
      const dialog = document.querySelector('[role="dialog"]');
      if (dialog) {
        const focusableElements = dialog.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;
        
        // Sposta il focus sul primo elemento focusable
        firstElement?.focus();
        
        // Gestisce il tab per mantenere il focus all'interno del dialog
        dialog.addEventListener('keydown', (e: Event) => {
          const event = e as KeyboardEvent;
          if (event.key === 'Tab') {
            if (event.shiftKey && document.activeElement === firstElement) {
              event.preventDefault();
              lastElement?.focus();
            } else if (!event.shiftKey && document.activeElement === lastElement) {
              event.preventDefault();
              firstElement?.focus();
            }
          }
        });
      }
    }, 100);
  }
  
  /**
   * Aggiunge il listener per il tasto ESC
   */
  private addEscapeListener(): void {
    if (!this.isBrowser) return;
    document.addEventListener('keydown', this.handleEscape);
  }
  
  /**
   * Rimuove il listener per il tasto ESC
   */
  private removeEscapeListener(): void {
    if (!this.isBrowser) return;
    document.removeEventListener('keydown', this.handleEscape);
  }
  
  /**
   * Gestisce la pressione del tasto ESC per chiudere il dialog
   */
  private handleEscape = (event: KeyboardEvent): void => {
    if (event.key === 'Escape') {
      this.closeDialog('cancelled');
    }
  };
}
