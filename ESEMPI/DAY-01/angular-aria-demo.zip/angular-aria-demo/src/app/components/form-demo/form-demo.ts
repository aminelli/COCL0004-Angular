import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

/**
 * Componente dimostrativo per Form Accessibili
 * 
 * Implementa un form completo con:
 * - Validazione in tempo reale
 * - Messaggi di errore accessibili
 * - aria-describedby per collegare errori e istruzioni
 * - aria-invalid per indicare campi non validi
 * - aria-required per campi obbligatori
 * - Focus management su errori
 * - Live regions per feedback
 * 
 * Conforme alle WCAG 2.1 Level AA.
 */
@Component({
  selector: 'app-form-demo',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './form-demo.html',
  styleUrl: './form-demo.scss',
})
export class FormDemoComponent {
  /**
   * Form group reattivo
   */
  protected readonly registrationForm: FormGroup;

  /**
   * Signal per tracciare il submit
   */
  protected readonly submitted = signal(false);

  /**
   * Signal per il messaggio di successo
   */
  protected readonly successMessage = signal('');

  /**
   * Signal per mostrare/nascondere la password
   */
  protected readonly showPassword = signal(false);

  /**
   * Signal per il paese selezionato
   */
  protected readonly selectedCountry = signal('');

  /**
   * Lista paesi disponibili
   */
  protected readonly countries = [
    { code: 'IT', name: 'Italia' },
    { code: 'US', name: 'Stati Uniti' },
    { code: 'UK', name: 'Regno Unito' },
    { code: 'FR', name: 'Francia' },
    { code: 'DE', name: 'Germania' },
    { code: 'ES', name: 'Spagna' }
  ];

  /**
   * Computed per validare se il form è valido
   */
  protected readonly isFormValid = computed(() => {
    return this.registrationForm.valid;
  });

  constructor(private fb: FormBuilder) {
    // Inizializza il form con validatori
    this.registrationForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      phone: ['', [Validators.pattern(/^[0-9]{10}$/)]],
      country: ['', [Validators.required]],
      acceptTerms: [false, [Validators.requiredTrue]],
      newsletter: [false]
    });
  }

  /**
   * Controlla se un campo è invalido e deve mostrare l'errore
   */
  isFieldInvalid(fieldName: string): boolean {
    const field = this.registrationForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched || this.submitted()));
  }

  /**
   * Ottiene il messaggio di errore per un campo
   */
  getErrorMessage(fieldName: string): string {
    const field = this.registrationForm.get(fieldName);
    if (!field || !field.errors) return '';

    if (field.errors['required']) {
      return 'Questo campo è obbligatorio';
    }
    if (field.errors['minlength']) {
      const minLength = field.errors['minlength'].requiredLength;
      return `Deve contenere almeno ${minLength} caratteri`;
    }
    if (field.errors['email']) {
      return 'Inserisci un indirizzo email valido';
    }
    if (field.errors['pattern']) {
      if (fieldName === 'phone') {
        return 'Il numero deve contenere esattamente 10 cifre';
      }
    }

    return 'Valore non valido';
  }

  /**
   * Ottiene gli ID dei messaggi descrittivi per un campo
   */
  getAriaDescribedBy(fieldName: string): string {
    const parts: string[] = [];
    
    // Aggiungi l'help text se esiste
    const helpId = `${fieldName}-help`;
    parts.push(helpId);
    
    // Aggiungi l'errore se il campo è invalido
    if (this.isFieldInvalid(fieldName)) {
      parts.push(`${fieldName}-error`);
    }
    
    return parts.join(' ');
  }

  /**
   * Toggle visibilità password
   */
  togglePasswordVisibility(): void {
    this.showPassword.update(value => !value);
  }

  /**
   * Gestisce il submit del form
   */
  onSubmit(): void {
    this.submitted.set(true);

    if (this.registrationForm.valid) {
      // Simula invio al server
      this.successMessage.set('Registrazione completata con successo! ✅');
      
      // Reset form dopo successo
      setTimeout(() => {
        this.registrationForm.reset();
        this.submitted.set(false);
        this.successMessage.set('');
      }, 5000);
    } else {
      // Sposta il focus sul primo campo con errore
      this.focusFirstInvalidField();
    }
  }

  /**
   * Sposta il focus sul primo campo invalido
   */
  private focusFirstInvalidField(): void {
    setTimeout(() => {
      const firstInvalid = document.querySelector('[aria-invalid="true"]') as HTMLElement;
      if (firstInvalid) {
        firstInvalid.focus();
        // Annuncia agli screen reader
        const errorCount = Object.keys(this.registrationForm.controls)
          .filter(key => this.isFieldInvalid(key)).length;
        console.log(`Trovati ${errorCount} errori nel form`);
      }
    }, 100);
  }

  /**
   * Reset del form
   */
  resetForm(): void {
    this.registrationForm.reset();
    this.submitted.set(false);
    this.successMessage.set('');
    this.showPassword.set(false);
  }
}
