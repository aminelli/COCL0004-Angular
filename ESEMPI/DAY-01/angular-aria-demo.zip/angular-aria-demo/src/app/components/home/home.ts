import { Component, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

/**
 * Componente Home - Pagina principale dell'applicazione
 * 
 * Questo componente fornisce una panoramica completa di tutti i WAI-ARIA patterns
 * implementati nell'applicazione, con descrizioni dettagliate e link alle demo.
 * 
 * Utilizza signals di Angular 21 per la gestione dello stato reattivo.
 */
@Component({
  selector: 'app-home',
  imports: [CommonModule, RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.scss',
})
export class HomeComponent {
  // Signal contenente il titolo della pagina
  protected readonly pageTitle = signal('Benvenuto in Angular Aria Demo');
  
  // Signal contenente la descrizione della pagina
  protected readonly pageDescription = signal(
    'Questa applicazione dimostra l\'implementazione dei WAI-ARIA (Web Accessibility Initiative - Accessible Rich Internet Applications) ' +
    'patterns in Angular 21, seguendo le best practices per creare applicazioni web accessibili.'
  );
  
  // Signal contenente l'array dei patterns WAI-ARIA implementati
  protected readonly ariaPatterns = signal([
    {
      id: 'dialog',
      title: 'Dialog (Modal)',
      icon: 'bi-window',
      description: 'Implementa dialog modali accessibili con gestione del focus, trap del focus, chiusura con ESC, e attributi ARIA come role="dialog", aria-modal, aria-labelledby e aria-describedby.',
      route: '/dialog',
      wcagLevel: 'A',
      ariaRoles: ['dialog', 'alertdialog'],
      ariaProperties: ['aria-modal', 'aria-labelledby', 'aria-describedby']
    },
    {
      id: 'tabs',
      title: 'Tabs',
      icon: 'bi-folder',
      description: 'Implementa tabs accessibili con navigazione da tastiera (frecce), gestione di aria-selected, aria-controls, role="tablist", role="tab", e role="tabpanel".',
      route: '/tabs',
      wcagLevel: 'A',
      ariaRoles: ['tablist', 'tab', 'tabpanel'],
      ariaProperties: ['aria-selected', 'aria-controls', 'aria-labelledby']
    },
    {
      id: 'accordion',
      title: 'Accordion',
      icon: 'bi-menu-button-wide',
      description: 'Implementa accordion accessibili con gestione di aria-expanded, aria-controls, navigazione da tastiera, e possibilità di espandere/collassare pannelli multipli.',
      route: '/accordion',
      wcagLevel: 'A',
      ariaRoles: ['region'],
      ariaProperties: ['aria-expanded', 'aria-controls', 'aria-labelledby']
    },
    {
      id: 'menu',
      title: 'Menu & Dropdown',
      icon: 'bi-list',
      description: 'Implementa menu dropdown accessibili con role="menu", role="menuitem", navigazione da tastiera, sottomenu, e gestione del focus.',
      route: '/menu',
      wcagLevel: 'A',
      ariaRoles: ['menu', 'menubar', 'menuitem', 'menuitemcheckbox', 'menuitemradio'],
      ariaProperties: ['aria-haspopup', 'aria-expanded']
    },
    {
      id: 'form',
      title: 'Form Accessibili',
      icon: 'bi-input-cursor-text',
      description: 'Implementa form accessibili con label corrette, messaggi di errore accessibili, aria-required, aria-invalid, aria-describedby per le istruzioni.',
      route: '/form',
      wcagLevel: 'A',
      ariaRoles: ['form', 'group'],
      ariaProperties: ['aria-required', 'aria-invalid', 'aria-describedby', 'aria-errormessage']
    },
    {
      id: 'live-region',
      title: 'Live Regions',
      icon: 'bi-broadcast',
      description: 'Implementa live regions ARIA per notifiche dinamiche accessibili con aria-live, aria-atomic, role="alert", role="status", e role="log".',
      route: '/live-region',
      wcagLevel: 'A',
      ariaRoles: ['alert', 'status', 'log', 'timer'],
      ariaProperties: ['aria-live', 'aria-atomic', 'aria-relevant']
    },
    {
      id: 'combobox',
      title: 'Combobox & Autocomplete',
      icon: 'bi-ui-checks',
      description: 'Implementa combobox accessibili con autocomplete, role="combobox", aria-autocomplete, aria-expanded, gestione della navigazione da tastiera nei risultati.',
      route: '/combobox',
      wcagLevel: 'AA',
      ariaRoles: ['combobox', 'listbox', 'option'],
      ariaProperties: ['aria-autocomplete', 'aria-expanded', 'aria-activedescendant', 'aria-owns']
    }
  ]);
  
  // Signal per le caratteristiche principali di Angular 21
  protected readonly angular21Features = signal([
    {
      title: 'Zoneless',
      icon: 'bi-lightning-charge',
      description: 'Applicazione zoneless per migliori performance senza zone.js'
    },
    {
      title: 'Signals',
      icon: 'bi-arrow-repeat',
      description: 'Gestione dello stato reattiva con i Signals di Angular'
    },
    {
      title: 'Standalone Components',
      icon: 'bi-box',
      description: 'Architettura modulare senza NgModule'
    },
    {
      title: 'Server-Side Rendering',
      icon: 'bi-server',
      description: 'SSR abilitato per migliore SEO e performance iniziali'
    }
  ]);
  
  // Signal per le linee guida WCAG implementate
  protected readonly wcagGuidelines = signal([
    {
      level: 'A',
      title: 'Livello A',
      description: 'Requisiti minimi di accessibilità',
      color: 'success'
    },
    {
      level: 'AA',
      title: 'Livello AA',
      description: 'Obiettivo raccomandato per la maggior parte dei siti',
      color: 'info'
    },
    {
      level: 'AAA',
      title: 'Livello AAA',
      description: 'Massimo livello di accessibilità',
      color: 'warning'
    }
  ]);
}
