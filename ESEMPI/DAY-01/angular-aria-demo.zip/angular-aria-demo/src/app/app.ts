import { Component, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

/**
 * Componente principale dell'applicazione Angular Aria Demo
 * 
 * Questo componente implementa il layout principale dell'applicazione seguendo
 * le best practices di Angular 21:
 * - Utilizzo di signals per la gestione dello stato reattivo
 * - Componente standalone (niente NgModule)
 * - Zoneless (senza zone.js)
 * - Server-Side Rendering (SSR) abilitato
 * 
 * Caratteristiche di accessibilità implementate:
 * - Navigazione con attributi ARIA appropriati
 * - Skip links per navigazione rapida
 * - Landmark regions (header, nav, main, footer)
 * - Focus management
 */
@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    RouterOutlet, 
    RouterLink, 
    RouterLinkActive
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  // Signal per il titolo dell'applicazione
  protected readonly title = signal('Angular Aria Demo');
  
  // Signal per controllare lo stato del menu mobile (collapsed/expanded)
  protected readonly isMobileMenuOpen = signal(false);
  
  // Array delle voci di navigazione con informazioni per l'accessibilità
  protected readonly navigationItems = signal([
    { 
      path: '/home', 
      label: 'Home', 
      icon: 'bi-house-door',
      ariaLabel: 'Vai alla pagina principale' 
    },
    { 
      path: '/dialog', 
      label: 'Dialog', 
      icon: 'bi-window',
      ariaLabel: 'Esempi di Dialog accessibili con WAI-ARIA' 
    },
    { 
      path: '/tabs', 
      label: 'Tabs', 
      icon: 'bi-folder',
      ariaLabel: 'Esempi di Tabs accessibili con WAI-ARIA' 
    },
    { 
      path: '/accordion', 
      label: 'Accordion', 
      icon: 'bi-menu-button-wide',
      ariaLabel: 'Esempi di Accordion accessibili con WAI-ARIA' 
    },
    { 
      path: '/menu', 
      label: 'Menu', 
      icon: 'bi-list',
      ariaLabel: 'Esempi di Menu accessibili con WAI-ARIA' 
    },
    { 
      path: '/form', 
      label: 'Forms', 
      icon: 'bi-input-cursor-text',
      ariaLabel: 'Esempi di Form accessibili' 
    },
    { 
      path: '/live-region', 
      label: 'Live Regions', 
      icon: 'bi-broadcast',
      ariaLabel: 'Esempi di Live Regions ARIA' 
    },
    { 
      path: '/combobox', 
      label: 'Combobox', 
      icon: 'bi-ui-checks',
      ariaLabel: 'Esempi di Combobox accessibili con WAI-ARIA' 
    }
  ]);
  
  /**
   * Toggle del menu mobile
   * Aggiorna il signal che controlla la visibilità del menu
   */
  toggleMobileMenu(): void {
    this.isMobileMenuOpen.update(value => !value);
  }
  
  /**
   * Chiude il menu mobile
   * Utilizzato quando l'utente seleziona una voce di navigazione
   */
  closeMobileMenu(): void {
    this.isMobileMenuOpen.set(false);
  }
  
  /**
   * Metodo per saltare al contenuto principale
   * Implementa il pattern "Skip to main content" per l'accessibilità
   */
  skipToMainContent(event: Event): void {
    event.preventDefault();
    const mainContent = document.getElementById('main-content');
    if (mainContent) {
      mainContent.focus();
      mainContent.scrollIntoView();
    }
  }
}
