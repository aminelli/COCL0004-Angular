# Guida Tecnica WAI-ARIA Patterns - Angular 21

## Indice
1. [Introduzione ai WAI-ARIA Patterns](#introduzione)
2. [Dialog Pattern](#dialog-pattern)
3. [Tabs Pattern](#tabs-pattern)
4. [Accordion Pattern](#accordion-pattern)
5. [Menu Pattern](#menu-pattern)
6. [Form Accessibili](#form-accessibili)
7. [Live Regions](#live-regions)
8. [Combobox Pattern](#combobox-pattern)
9. [Best Practices Generali](#best-practices-generali)
10. [Testing e Validazione](#testing-e-validazione)

---

## Introduzione

### Cos'è WAI-ARIA?

**WAI-ARIA (Web Accessibility Initiative - Accessible Rich Internet Applications)** è una specifica W3C che definisce un modo per rendere il contenuto web e le applicazioni web più accessibili alle persone con disabilità.

ARIA fornisce:
- **Roles**: Definiscono cosa fa un elemento (es. `role="dialog"`, `role="tab"`)
- **Properties**: Descrivono le caratteristiche degli elementi (es. `aria-required`, `aria-label`)
- **States**: Descrivono lo stato corrente degli elementi (es. `aria-expanded`, `aria-selected`)

### Quando Usare ARIA?

**Prima regola di ARIA**: Non usare ARIA se puoi usare un elemento HTML nativo.

```html
<!-- ❌ NON FARE QUESTO -->
<div role="button" onclick="...">Clicca</div>

<!-- ✅ FAI QUESTO -->
<button onclick="...">Clicca</button>
```

Usa ARIA quando:
- Non esiste un elemento HTML nativo appropriato
- Devi implementare pattern complessi (dialog, tabs, etc.)
- Devi fornire informazioni aggiuntive agli screen reader

---

## Dialog Pattern

### Struttura Base HTML

```html
<!-- Overlay per indicare che il contenuto sottostante è inerte -->
<div class="dialog-overlay" aria-hidden="true"></div>

<!-- Dialog modale -->
<div 
  role="dialog" 
  aria-modal="true"
  aria-labelledby="dialog-title"
  aria-describedby="dialog-description">
  
  <!-- Header -->
  <div class="dialog-header">
    <h2 id="dialog-title">Titolo del Dialog</h2>
    <button aria-label="Chiudi dialog">X</button>
  </div>
  
  <!-- Body -->
  <div class="dialog-body">
    <p id="dialog-description">
      Descrizione del contenuto del dialog.
    </p>
  </div>
  
  <!-- Footer -->
  <div class="dialog-footer">
    <button>Annulla</button>
    <button>Conferma</button>
  </div>
</div>
```

### Implementazione Angular con Signals

```typescript
import { Component, signal, effect, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({...})
export class DialogComponent {
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);
  
  // Signal per controllare la visibilità
  protected readonly isOpen = signal(false);
  
  // Riferimento all'elemento trigger
  private triggerElement: HTMLElement | null = null;
  
  constructor() {
    // Effect per gestire il focus quando il dialog si apre/chiude
    effect(() => {
      if (this.isBrowser && this.isOpen()) {
        this.trapFocus();
        this.addEscapeListener();
      } else if (this.isBrowser) {
        this.removeEscapeListener();
        this.restoreFocus();
      }
    });
  }
  
  open(triggerElement: HTMLElement): void {
    this.triggerElement = triggerElement;
    this.isOpen.set(true);
  }
  
  close(): void {
    this.isOpen.set(false);
  }
  
  private trapFocus(): void {
    // Implementazione del focus trap
    setTimeout(() => {
      const dialog = document.querySelector('[role="dialog"]');
      if (dialog) {
        const focusableElements = dialog.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        
        const firstElement = focusableElements[0] as HTMLElement;
        const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;
        
        // Sposta il focus sul primo elemento
        firstElement?.focus();
        
        // Gestisce il Tab per mantenere il focus nel dialog
        dialog.addEventListener('keydown', (e: Event) => {
          const event = e as KeyboardEvent;
          if (event.key === 'Tab') {
            if (event.shiftKey && document.activeElement === firstElement) {
              event.preventDefault();
              lastElement?.focus();
            } else if (!event.shiftKey && document.activeElement === lastElement) {
              event.preventDefault();
              firstElement?.focus();
            }
          }
        });
      }
    }, 100);
  }
  
  private addEscapeListener(): void {
    if (!this.isBrowser) return;
    document.addEventListener('keydown', this.handleEscape);
  }
  
  private removeEscapeListener(): void {
    if (!this.isBrowser) return;
    document.removeEventListener('keydown', this.handleEscape);
  }
  
  private handleEscape = (event: KeyboardEvent): void => {
    if (event.key === 'Escape') {
      this.close();
    }
  };
  
  private restoreFocus(): void {
    setTimeout(() => {
      this.triggerElement?.focus();
    }, 100);
  }
}
```

### Checklist Dialog

✅ `role="dialog"` sul contenitore principale
✅ `aria-modal="true"` per indicare che è modale
✅ `aria-labelledby` collega il titolo
✅ `aria-describedby` collega la descrizione
✅ Focus trap implementato correttamente
✅ ESC chiude il dialog
✅ Focus ripristinato all'elemento trigger
✅ Overlay visivo per contenuto inerte
✅ Almeno un elemento focusabile nel dialog

---

## Tabs Pattern

### Struttura Base HTML

```html
<!-- Tablist container -->
<div 
  role="tablist" 
  aria-label="Descrizione delle tabs">
  
  <!-- Tab 1 (attiva) -->
  <button
    id="tab-1"
    role="tab"
    aria-selected="true"
    aria-controls="panel-1"
    tabindex="0">
    Tab 1
  </button>
  
  <!-- Tab 2 (inattiva) -->
  <button
    id="tab-2"
    role="tab"
    aria-selected="false"
    aria-controls="panel-2"
    tabindex="-1">
    Tab 2
  </button>
</div>

<!-- Tab Panels -->
<div 
  id="panel-1"
  role="tabpanel"
  aria-labelledby="tab-1"
  tabindex="0">
  Contenuto panel 1
</div>

<div 
  id="panel-2"
  role="tabpanel"
  aria-labelledby="tab-2"
  tabindex="0"
  hidden>
  Contenuto panel 2
</div>
```

### Implementazione Angular

```typescript
import { Component, signal } from '@angular/core';

interface Tab {
  id: string;
  panelId: string;
  label: string;
  content: string;
}

@Component({...})
export class TabsComponent {
  // Signal per la tab attiva
  protected readonly activeTabIndex = signal(0);
  
  // Array delle tabs
  protected readonly tabs = signal<Tab[]>([
    {
      id: 'tab-1',
      panelId: 'panel-1',
      label: 'Prima Tab',
      content: 'Contenuto della prima tab...'
    },
    {
      id: 'tab-2',
      panelId: 'panel-2',
      label: 'Seconda Tab',
      content: 'Contenuto della seconda tab...'
    }
  ]);
  
  selectTab(index: number): void {
    this.activeTabIndex.set(index);
  }
  
  handleKeyboardNavigation(event: KeyboardEvent, currentIndex: number): void {
    const tabsCount = this.tabs().length;
    let newIndex = currentIndex;
    
    switch (event.key) {
      case 'ArrowRight':
        event.preventDefault();
        newIndex = (currentIndex + 1) % tabsCount;
        this.selectTab(newIndex);
        this.focusTab(newIndex);
        break;
        
      case 'ArrowLeft':
        event.preventDefault();
        newIndex = currentIndex === 0 ? tabsCount - 1 : currentIndex - 1;
        this.selectTab(newIndex);
        this.focusTab(newIndex);
        break;
        
      case 'Home':
        event.preventDefault();
        this.selectTab(0);
        this.focusTab(0);
        break;
        
      case 'End':
        event.preventDefault();
        this.selectTab(tabsCount - 1);
        this.focusTab(tabsCount - 1);
        break;
    }
  }
  
  private focusTab(index: number): void {
    setTimeout(() => {
      const tab = document.getElementById(this.tabs()[index].id);
      tab?.focus();
    }, 10);
  }
}
```

### Template Angular

```html
<!-- Tablist -->
<div role="tablist" aria-label="Tabs dimostrative">
  @for (tab of tabs(); track tab.id; let i = $index) {
    <button
      [id]="tab.id"
      role="tab"
      [attr.aria-selected]="activeTabIndex() === i"
      [attr.aria-controls]="tab.panelId"
      [tabindex]="activeTabIndex() === i ? 0 : -1"
      (click)="selectTab(i)"
      (keydown)="handleKeyboardNavigation($event, i)">
      {{ tab.label }}
    </button>
  }
</div>

<!-- Tab Panels -->
@for (tab of tabs(); track tab.id; let i = $index) {
  <div
    [id]="tab.panelId"
    role="tabpanel"
    [attr.aria-labelledby]="tab.id"
    [hidden]="activeTabIndex() !== i"
    tabindex="0">
    {{ tab.content }}
  </div>
}
```

### Navigazione da Tastiera - Tabs

| Tasto | Azione |
|-------|--------|
| `Tab` | Sposta il focus nella tablist. Se già in una tab, va al tabpanel attivo |
| `→` | Tab successiva (loop alla prima se sull'ultima) |
| `←` | Tab precedente (loop all'ultima se sulla prima) |
| `Home` | Prima tab |
| `End` | Ultima tab |

### Checklist Tabs

✅ `role="tablist"` sul contenitore
✅ `role="tab"` su ogni tab
✅ `role="tabpanel"` su ogni pannello
✅ `aria-selected` correttamente impostato
✅ `aria-controls` collega tab e pannello
✅ `aria-labelledby` sul pannello
✅ `tabindex="0"` solo sulla tab attiva
✅ `hidden` sui pannelli non attivi
✅ Navigazione frecce implementata
✅ Home/End funzionanti

---

## Form Accessibili

### Label Corrette

```html
<!-- ✅ CORRETTO: Label esplicita -->
<label for="nome">Nome:</label>
<input type="text" id="nome" name="nome">

<!-- ✅ CORRETTO: Label implicita -->
<label>
  Nome:
  <input type="text" name="nome">
</label>

<!-- ✅ CORRETTO: Label nascosta visivamente ma presente per screen reader -->
<label for="search" class="sr-only">Cerca nel sito</label>
<input type="search" id="search" placeholder="Cerca...">
```

### Campi Obbligatori

```html
<label for="email">
  Email 
  <span aria-hidden="true">*</span>
  <span class="sr-only">(obbligatorio)</span>
</label>
<input 
  type="email" 
  id="email" 
  name="email"
  required
  aria-required="true">
```

### Validazione e Errori

```html
<label for="password">Password</label>
<input 
  type="password" 
  id="password" 
  name="password"
  aria-describedby="password-requirements password-error"
  aria-invalid="false">

<div id="password-requirements" class="help-text">
  La password deve contenere almeno 8 caratteri
</div>

<div id="password-error" class="error-message" hidden>
  <!-- Questo diventa visibile quando c'è un errore -->
</div>
```

### Implementazione Angular Reactive Forms

```typescript
import { Component, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({...})
export class AccessibleFormComponent {
  private fb = inject(FormBuilder);
  
  form: FormGroup;
  submitted = signal(false);
  
  constructor() {
    this.form = this.fb.group({
      nome: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }
  
  get nomeInvalid(): boolean {
    const control = this.form.get('nome');
    return !!(control && control.invalid && (control.dirty || this.submitted()));
  }
  
  get emailInvalid(): boolean {
    const control = this.form.get('email');
    return !!(control && control.invalid && (control.dirty || this.submitted()));
  }
  
  onSubmit(): void {
    this.submitted.set(true);
    
    if (this.form.valid) {
      // Procedi con l'invio
      console.log('Form valido:', this.form.value);
    } else {
      // Sposta il focus sul primo campo con errore
      this.focusFirstInvalidField();
    }
  }
  
  private focusFirstInvalidField(): void {
    const firstInvalid = document.querySelector('[aria-invalid="true"]') as HTMLElement;
    firstInvalid?.focus();
  }
}
```

### Template Form Accessibile

```html
<form [formGroup]="form" (ngSubmit)="onSubmit()">
  <!-- Campo Nome -->
  <div class="form-group">
    <label for="nome">
      Nome
      <span aria-hidden="true">*</span>
    </label>
    <input 
      type="text" 
      id="nome" 
      formControlName="nome"
      [attr.aria-invalid]="nomeInvalid"
      [attr.aria-describedby]="nomeInvalid ? 'nome-error' : null"
      class="form-control">
    
    @if (nomeInvalid) {
      <div id="nome-error" class="error-message" role="alert">
        Il nome è obbligatorio e deve contenere almeno 2 caratteri
      </div>
    }
  </div>
  
  <!-- Campo Email -->
  <div class="form-group">
    <label for="email">
      Email
      <span aria-hidden="true">*</span>
    </label>
    <input 
      type="email" 
      id="email" 
      formControlName="email"
      [attr.aria-invalid]="emailInvalid"
      [attr.aria-describedby]="emailInvalid ? 'email-error' : null"
      class="form-control">
    
    @if (emailInvalid) {
      <div id="email-error" class="error-message" role="alert">
        Inserisci un indirizzo email valido
      </div>
    }
  </div>
  
  <button type="submit" class="btn btn-primary">
    Invia
  </button>
</form>
```

### Checklist Form Accessibili

✅ Ogni input ha una label associata
✅ Campi obbligatori indicati con `aria-required`
✅ Errori collegati con `aria-describedby`
✅ Stato di errore indicato con `aria-invalid`
✅ Messaggi di errore con `role="alert"`
✅ Focus spostato al primo errore dopo submit
✅ Istruzioni collegate agli input
✅ Gruppi di campi usano `<fieldset>` e `<legend>`

---

## Live Regions

### Tipi di Live Regions

```html
<!-- Polite: Annuncia quando l'utente è inattivo -->
<div aria-live="polite" aria-atomic="true">
  Messaggio di stato
</div>

<!-- Assertive: Annuncia immediatamente -->
<div aria-live="assertive" aria-atomic="true">
  Errore critico!
</div>

<!-- Alert: Equivalente a aria-live="assertive" -->
<div role="alert">
  Attenzione: azione richiesta!
</div>

<!-- Status: Equivalente a aria-live="polite" -->
<div role="status">
  Caricamento completato
</div>

<!-- Log: Per messaggi che si aggiungono nel tempo -->
<div role="log" aria-live="polite" aria-atomic="false">
  <div>Messaggio 1</div>
  <div>Messaggio 2</div>
</div>
```

### Implementazione Angular

```typescript
import { Component, signal } from '@angular/core';

interface Notification {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}

@Component({...})
export class LiveRegionComponent {
  protected readonly notifications = signal<Notification[]>([]);
  private nextId = 1;
  
  addNotification(type: 'success' | 'error' | 'info', message: string): void {
    const notification: Notification = {
      id: this.nextId++,
      type,
      message
    };
    
    this.notifications.update(notifications => [...notifications, notification]);
    
    // Rimuovi automaticamente dopo 5 secondi
    setTimeout(() => {
      this.removeNotification(notification.id);
    }, 5000);
  }
  
  removeNotification(id: number): void {
    this.notifications.update(notifications => 
      notifications.filter(n => n.id !== id)
    );
  }
  
  // Metodi helper
  showSuccess(message: string): void {
    this.addNotification('success', message);
  }
  
  showError(message: string): void {
    this.addNotification('error', message);
  }
  
  showInfo(message: string): void {
    this.addNotification('info', message);
  }
}
```

### Template Live Regions

```html
<!-- Contenitore per le notifiche -->
<div class="notifications-container">
  @for (notification of notifications(); track notification.id) {
    <div 
      [class]="'alert alert-' + notification.type"
      [attr.role]="notification.type === 'error' ? 'alert' : 'status'"
      [attr.aria-live]="notification.type === 'error' ? 'assertive' : 'polite'"
      aria-atomic="true">
      {{ notification.message }}
      <button 
        type="button"
        (click)="removeNotification(notification.id)"
        aria-label="Chiudi notifica">
        ×
      </button>
    </div>
  }
</div>

<!-- Bottoni per testare -->
<button (click)="showSuccess('Operazione completata con successo!')">
  Mostra Successo
</button>
<button (click)="showError('Si è verificato un errore!')">
  Mostra Errore
</button>
<button (click)="showInfo('Informazione importante')">
  Mostra Info
</button>
```

### Best Practices Live Regions

✅ Usa `aria-live="polite"` per la maggior parte degli aggiornamenti
✅ Usa `aria-live="assertive"` solo per errori critici
✅ Usa `role="alert"` per errori e avvisi
✅ Usa `role="status"` per aggiornamenti di stato
✅ Usa `aria-atomic="true"` per leggere l'intero contenuto
✅ Usa `aria-atomic="false"` per log e feed
✅ Evita aggiornamenti troppo frequenti
✅ Limita la lunghezza dei messaggi

---

## Best Practices Generali

### 1. Landmark Regions

```html
<!-- Header con role="banner" -->
<header role="banner">
  <nav role="navigation" aria-label="Navigazione principale">
    <!-- Menu -->
  </nav>
</header>

<!-- Main content -->
<main role="main" id="main-content" tabindex="-1">
  <!-- Contenuto principale -->
  
  <aside role="complementary" aria-label="Contenuti correlati">
    <!-- Sidebar -->
  </aside>
</main>

<!-- Footer -->
<footer role="contentinfo">
  <!-- Info footer -->
</footer>
```

### 2. Skip Links

```html
<a href="#main-content" class="skip-link">
  Salta al contenuto principale
</a>

<!-- CSS -->
<style>
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  background: #000;
  color: #fff;
  padding: 8px;
  z-index: 100;
}

.skip-link:focus {
  top: 0;
}
</style>
```

### 3. Icone Decorative

```html
<!-- Icona puramente decorativa -->
<i class="bi bi-star" aria-hidden="true"></i>

<!-- Icona con significato -->
<button>
  <i class="bi bi-trash" aria-hidden="true"></i>
  <span class="sr-only">Elimina</span>
</button>
```

### 4. Classe Screen Reader Only

```css
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
```

---

## Testing e Validazione

### Tool Automatici

1. **axe DevTools** - Extension browser
2. **WAVE** - Web Accessibility Evaluation Tool
3. **Lighthouse** - Audit integrato in Chrome DevTools
4. **Pa11y** - Command line tool

### Test Manuali Essenziali

1. **Navigazione da Tastiera**
   - Prova a navigare usando solo Tab, Shift+Tab, Enter, Space, Frecce
   - Verifica che il focus sia sempre visibile
   - Controlla che non ci siano trappole di tastiera
   
2. **Screen Reader**
   - NVDA (Windows, gratuito)
   - JAWS (Windows, commerciale)
   - VoiceOver (macOS/iOS, integrato)
   - TalkBack (Android, integrato)
   
3. **Zoom e Ingrandimento**
   - Testa fino al 200% di zoom
   - Verifica che tutto il contenuto sia accessibile
   - Controlla che non ci sia scroll orizzontale

4. **Contrasto Colori**
   - Usa strumenti come Contrast Checker
   - Minimo 4.5:1 per testo normale (WCAG AA)
   - Minimo 3:1 per testo grande e componenti UI

### Checklist Completa Accessibilità

**HTML Semantico**
- [ ] Uso corretto di heading (h1, h2, h3...)
- [ ] Landmark regions presenti
- [ ] Liste per contenuti correlati
- [ ] Table solo per dati tabulari

**Tastiera**
- [ ] Tutto accessibile da tastiera
- [ ] Ordine di tab logico
- [ ] Focus visibile
- [ ] Nessuna trappola di tastiera
- [ ] Scorciatoie non in conflitto

**ARIA**
- [ ] Roles corretti
- [ ] Properties appropriate
- [ ] States aggiornati dinamicamente
- [ ] Label su tutti i controlli
- [ ] Descrizioni dove necessario

**Form**
- [ ] Label su tutti gli input
- [ ] Errori accessibili
- [ ] Istruzioni chiare
- [ ] Validazione in tempo reale
- [ ] Feedback positivo

**Multimedia**
- [ ] Testo alternativo per immagini
- [ ] Trascrizioni per audio
- [ ] Sottotitoli per video
- [ ] Controlli accessibili

**Visual**
- [ ] Contrasto sufficiente
- [ ] Testo ridimensionabile
- [ ] Responsive design
- [ ] Nessuna dipendenza dal colore solo

---

## Conclusione

L'implementazione corretta dei WAI-ARIA patterns richiede:

1. **Comprensione** - Studio delle specifiche e best practices
2. **Implementazione** - Codice corretto e testato
3. **Testing** - Verifica con tool automatici e manuali
4. **Manutenzione** - Aggiornamento continuo

Questo progetto fornisce esempi pratici e funzionanti di tutti i pattern principali. Usa questi esempi come riferimento per i tuoi progetti e ricorda sempre di testare con utenti reali quando possibile.

**L'accessibilità non è opzionale, è essenziale!** 🌟
