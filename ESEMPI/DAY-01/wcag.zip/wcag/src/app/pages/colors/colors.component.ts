/**
 * Colors Page Component
 * 
 * Dimostra l'importanza del contrasto colori secondo WCAG:
 * - Rapporti di contrasto AA (4.5:1 per testo normale)
 * - Rapporti di contrasto AAA (7:1 per testo normale)
 * - Contrasto per testo grande (3:1 AA, 4.5:1 AAA)
 * - Esempi di colori conformi e non conformi
 * 
 * WCAG Guidelines:
 * - 1.4.3 Contrast (Minimum) - AA
 * - 1.4.6 Contrast (Enhanced) - AAA
 * - 1.4.11 Non-text Contrast
 */

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

interface ColorExample {
  title: string;
  background: string;
  foreground: string;
  contrast: number;
  level: 'AAA' | 'AA' | 'Fail';
  description: string;
}

@Component({
  selector: 'app-colors',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid py-5">
      <h1 class="mb-4">Contrasto Colori e Accessibilità</h1>
      
      <p class="lead mb-5">
        Il contrasto tra testo e sfondo è fondamentale per l'accessibilità.
        WCAG definisce rapporti minimi per garantire la leggibilità.
      </p>
      
      <!-- Livelli di conformità -->
      <section class="mb-5" aria-labelledby="levels-title">
        <h2 id="levels-title" class="h3 mb-3">Livelli di Conformità WCAG</h2>
        
        <div class="row g-4">
          <div class="col-md-4">
            <div class="card h-100">
              <div class="card-body">
                <h3 class="h5 text-success">✓ Livello AA (Raccomandato)</h3>
                <ul class="mb-0">
                  <li>Testo normale: <strong>4.5:1</strong></li>
                  <li>Testo grande (18pt+): <strong>3:1</strong></li>
                  <li>Componenti UI: <strong>3:1</strong></li>
                </ul>
              </div>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="card h-100">
              <div class="card-body">
                <h3 class="h5 text-primary">✓✓ Livello AAA (Enhanced)</h3>
                <ul class="mb-0">
                  <li>Testo normale: <strong>7:1</strong></li>
                  <li>Testo grande (18pt+): <strong>4.5:1</strong></li>
                  <li>Standard più rigoroso</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div class="col-md-4">
            <div class="card h-100 border-danger">
              <div class="card-body">
                <h3 class="h5 text-danger">✗ Non Conforme</h3>
                <ul class="mb-0">
                  <li>Contrasto &lt; 4.5:1</li>
                  <li>Difficile da leggere</li>
                  <li>Non accessibile</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <!-- Esempi pratici -->
      <section class="mb-5" aria-labelledby="examples-title">
        <h2 id="examples-title" class="h3 mb-3">Esempi di Contrasto</h2>
        
        <div class="row g-4">
          @for (example of colorExamples(); track example.title) {
            <div class="col-md-6">
              <article class="color-example">
                <div 
                  class="color-sample"
                  [style.background-color]="example.background"
                  [style.color]="example.foreground"
                >
                  <div class="sample-text">
                    <h3 class="h5">{{ example.title }}</h3>
                    <p class="mb-0">
                      Questo è un esempio di testo con contrasto 
                      {{ example.contrast }}:1
                    </p>
                  </div>
                </div>
                
                <div class="color-details">
                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="badge"
                      [class.bg-success]="example.level === 'AAA'"
                      [class.bg-primary]="example.level === 'AA'"
                      [class.bg-danger]="example.level === 'Fail'"
                    >
                      {{ example.level }}
                    </span>
                    <span class="contrast-ratio">
                      Contrasto: <strong>{{ example.contrast }}:1</strong>
                    </span>
                  </div>
                  <p class="small mb-0 text-muted">
                    {{ example.description }}
                  </p>
                  <div class="color-codes mt-2">
                    <code class="small">BG: {{ example.background }}</code>
                    <code class="small">FG: {{ example.foreground }}</code>
                  </div>
                </div>
              </article>
            </div>
          }
        </div>
      </section>
      
      <!-- Palette colori accessibili -->
      <section class="mb-5" aria-labelledby="palette-title">
        <h2 id="palette-title" class="h3 mb-3">Palette Colori Accessibili</h2>
        
        <div class="row g-3">
          <!-- Primari -->
          <div class="col-12">
            <h3 class="h6">Colori Primari (su sfondo bianco)</h3>
          </div>
          
          @for (color of primaryColors(); track color.name) {
            <div class="col-md-2 col-sm-4 col-6">
              <div class="color-swatch" [style.background-color]="color.hex">
                <div class="swatch-name" [style.color]="color.textColor">
                  {{ color.name }}
                </div>
                <div class="swatch-info">
                  <code class="small">{{ color.hex }}</code>
                  <span class="badge bg-secondary small">
                    {{ color.contrast }}:1
                  </span>
                </div>
              </div>
            </div>
          }
          
          <!-- Grigi accessibili -->
          <div class="col-12 mt-4">
            <h3 class="h6">Scala di Grigi Accessibili</h3>
          </div>
          
          @for (gray of grayScale(); track gray.name) {
            <div class="col-md-2 col-sm-4 col-6">
              <div class="color-swatch" [style.background-color]="gray.hex">
                <div class="swatch-name" [style.color]="gray.textColor">
                  {{ gray.name }}
                </div>
                <div class="swatch-info">
                  <code class="small">{{ gray.hex }}</code>
                </div>
              </div>
            </div>
          }
        </div>
      </section>
      
      <!-- Strumenti e risorse -->
      <section aria-labelledby="tools-title">
        <h2 id="tools-title" class="h3 mb-3">Strumenti per Verificare il Contrasto</h2>
        <div class="card">
          <div class="card-body">
            <h3 class="h6">Strumenti Consigliati:</h3>
            <ul>
              <li>
                <a 
                  href="https://webaim.org/resources/contrastchecker/" 
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  WebAIM Contrast Checker
                  <span class="sr-only">(Si apre in una nuova finestra)</span>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.tpgi.com/color-contrast-checker/" 
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  TPGi Colour Contrast Analyser
                  <span class="sr-only">(Si apre in una nuova finestra)</span>
                </a>
              </li>
              <li>
                Browser DevTools - axe DevTools extension
              </li>
              <li>
                Lighthouse (integrato in Chrome DevTools)
              </li>
            </ul>
            
            <h3 class="h6 mt-3">Best Practices:</h3>
            <ul class="mb-0">
              <li>Non fare affidamento solo sul colore per trasmettere informazioni</li>
              <li>Usare icone o testo aggiuntivo insieme ai colori</li>
              <li>Testare con simulatori di daltonismo</li>
              <li>Verificare in diverse condizioni di illuminazione</li>
              <li>Considerare il contrasto anche in dark mode</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .color-example {
      border: 1px solid #dee2e6;
      border-radius: 0.5rem;
      overflow: hidden;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    
    .color-sample {
      padding: 2rem;
      min-height: 150px;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      flex: 1;
    }
    
    .sample-text {
      max-width: 100%;
    }
    
    .color-details {
      background: #f8f9fa;
      padding: 1rem;
      border-top: 1px solid #dee2e6;
    }
    
    .contrast-ratio {
      font-size: 0.875rem;
    }
    
    .color-codes {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
      
      code {
        background: white;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.75rem;
        border: 1px solid #dee2e6;
      }
    }
    
    /* Color swatches */
    .color-swatch {
      border-radius: 0.5rem;
      overflow: hidden;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      transition: transform 0.2s;
      
      &:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
      }
    }
    
    .swatch-name {
      padding: 2rem 1rem;
      font-weight: 600;
      text-align: center;
      min-height: 100px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .swatch-info {
      background: white;
      padding: 0.75rem;
      text-align: center;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      
      code {
        font-size: 0.75rem;
      }
    }
    
    /* Screen reader only */
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
    
    /* Links accessibili */
    a {
      color: #0d6efd;
      text-decoration: underline;
      
      &:hover {
        color: #0a58ca;
      }
      
      &:focus {
        outline: 3px solid #0d6efd;
        outline-offset: 2px;
      }
    }
    
    /* Rispetta le preferenze reduced motion */
    @media (prefers-reduced-motion: reduce) {
      .color-swatch {
        transition: none;
        
        &:hover {
          transform: none;
        }
      }
    }
  `]
})
export class ColorsComponent {
  // Esempi di contrasto
  colorExamples = signal<ColorExample[]>([
    {
      title: 'Eccellente (AAA)',
      background: '#ffffff',
      foreground: '#000000',
      contrast: 21,
      level: 'AAA',
      description: 'Contrasto massimo - ideale per tutti gli utenti'
    },
    {
      title: 'Ottimo (AAA)',
      background: '#0d6efd',
      foreground: '#ffffff',
      contrast: 8.6,
      level: 'AAA',
      description: 'Supera sia AA che AAA - eccellente accessibilità'
    },
    {
      title: 'Buono (AA)',
      background: '#198754',
      foreground: '#ffffff',
      contrast: 4.8,
      level: 'AA',
      description: 'Conforme WCAG AA - accessibile per la maggior parte degli utenti'
    },
    {
      title: 'Sufficiente (AA Large)',
      background: '#ffc107',
      foreground: '#000000',
      contrast: 3.5,
      level: 'AA',
      description: 'OK per testo grande (18pt+), non sufficiente per testo normale'
    },
    {
      title: 'Insufficiente',
      background: '#ffc107',
      foreground: '#ffffff',
      contrast: 1.8,
      level: 'Fail',
      description: 'Non conforme - difficile da leggere per molti utenti'
    },
    {
      title: 'Scarso',
      background: '#e9ecef',
      foreground: '#d3d3d3',
      contrast: 1.3,
      level: 'Fail',
      description: 'Contrasto molto basso - evitare assolutamente'
    }
  ]);
  
  // Colori primari accessibili
  primaryColors = signal([
    { name: 'Blu', hex: '#0d6efd', textColor: '#ffffff', contrast: 8.6 },
    { name: 'Indigo', hex: '#6610f2', textColor: '#ffffff', contrast: 8.3 },
    { name: 'Viola', hex: '#6f42c1', textColor: '#ffffff', contrast: 7.1 },
    { name: 'Rosso', hex: '#dc3545', textColor: '#ffffff', contrast: 5.9 },
    { name: 'Arancio', hex: '#fd7e14', textColor: '#000000', contrast: 4.7 },
    { name: 'Verde', hex: '#198754', textColor: '#ffffff', contrast: 4.8 }
  ]);
  
  // Scala di grigi
  grayScale = signal([
    { name: 'Gray 900', hex: '#212529', textColor: '#ffffff' },
    { name: 'Gray 800', hex: '#343a40', textColor: '#ffffff' },
    { name: 'Gray 700', hex: '#495057', textColor: '#ffffff' },
    { name: 'Gray 600', hex: '#6c757d', textColor: '#ffffff' },
    { name: 'Gray 500', hex: '#adb5bd', textColor: '#000000' },
    { name: 'Gray 400', hex: '#ced4da', textColor: '#000000' },
    { name: 'Gray 300', hex: '#dee2e6', textColor: '#000000' },
    { name: 'Gray 200', hex: '#e9ecef', textColor: '#000000' },
    { name: 'Gray 100', hex: '#f8f9fa', textColor: '#000000' }
  ]);
}
