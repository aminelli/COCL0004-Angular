/**
 * Multimedia Page Component
 * 
 * Dimostra contenuti multimediali accessibili:
 * - Video con sottotitoli
 * - Audio con trascrizione
 * - Controlli accessibili
 * - Alternative testuali
 * 
 * WCAG Guidelines:
 * - 1.1.1 Non-text Content (alternative testuali)
 * - 1.2.1 Audio-only and Video-only (alternative)
 * - 1.2.2 Captions (sottotitoli)
 * - 1.2.3 Audio Description (descrizione audio)
 * - 1.2.5 Audio Description (preregistrato)
 * - 2.1.1 Keyboard (controlli da tastiera)
 */

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-multimedia',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid py-5">
      <h1 class="mb-4">Contenuti Multimediali Accessibili</h1>
      
      <p class="lead mb-5">
        Esempi di video e audio accessibili con sottotitoli, trascrizioni
        e controlli completamente utilizzabili da tastiera.
      </p>
      
      <!-- Video con sottotitoli -->
      <section class="mb-5" aria-labelledby="video-title">
        <h2 id="video-title" class="h3 mb-3">Video con Sottotitoli</h2>
        
        <div class="media-container">
          <!-- 
            Video placeholder (in produzione, usa un video reale)
            Attributi importanti:
            - controls: mostra controlli nativi accessibili
            - crossorigin: necessario per sottotitoli da dominio diverso
          -->
          <div class="video-placeholder" role="img" aria-label="Placeholder video dimostrativo">
            <div class="placeholder-content">
              <svg width="100" height="100" viewBox="0 0 100 100" fill="none" aria-hidden="true">
                <circle cx="50" cy="50" r="40" stroke="currentColor" stroke-width="2"/>
                <polygon points="40,30 40,70 70,50" fill="currentColor"/>
              </svg>
              <p class="mt-3">Video Placeholder</p>
            </div>
          </div>
          
          <!-- 
            In un'applicazione reale, usare:
            <video controls crossorigin="anonymous">
              <source src="video.mp4" type="video/mp4">
              <track kind="captions" src="captions-it.vtt" srclang="it" label="Italiano" default>
              <track kind="descriptions" src="descriptions-it.vtt" srclang="it" label="Descrizione audio">
              Il tuo browser non supporta il tag video.
            </video>
          -->
          
          <!-- Trascrizione del video -->
          <details class="transcript mt-3">
            <summary>Trascrizione video</summary>
            <div class="transcript-content">
              <h3 class="h6">Trascrizione completa:</h3>
              <p>
                [0:00] Benvenuti a questo tutorial sull'accessibilità web.
              </p>
              <p>
                [0:05] Oggi parleremo dell'importanza di rendere i contenuti
                multimediali accessibili a tutti.
              </p>
              <p>
                [0:12] I sottotitoli aiutano le persone sorde o con problemi
                di udito a comprendere il contenuto audio.
              </p>
              <p>
                [0:20] Le descrizioni audio forniscono informazioni visive
                alle persone non vedenti o ipovedenti.
              </p>
            </div>
          </details>
        </div>
      </section>
      
      <!-- Audio con trascrizione -->
      <section class="mb-5" aria-labelledby="audio-title">
        <h2 id="audio-title" class="h3 mb-3">Audio con Trascrizione</h2>
        
        <div class="media-container">
          <!-- Audio placeholder -->
          <div class="audio-placeholder" role="img" aria-label="Placeholder audio dimostrativo">
            <div class="placeholder-content">
              <svg width="80" height="80" viewBox="0 0 80 80" fill="none" aria-hidden="true">
                <path d="M20 25 L20 55 L35 55 L50 65 L50 15 L35 25 Z" fill="currentColor"/>
                <path d="M55 30 Q65 40 55 50" stroke="currentColor" stroke-width="3" fill="none"/>
                <path d="M60 22 Q75 40 60 58" stroke="currentColor" stroke-width="3" fill="none"/>
              </svg>
              <p class="mt-3">Audio Placeholder</p>
            </div>
          </div>
          
          <!--
            In un'applicazione reale, usare:
            <audio controls>
              <source src="audio.mp3" type="audio/mpeg">
              Il tuo browser non supporta il tag audio.
            </audio>
          -->
          
          <!-- Trascrizione dell'audio -->
          <details class="transcript mt-3" open>
            <summary>Trascrizione audio</summary>
            <div class="transcript-content">
              <h3 class="h6">Trascrizione completa:</h3>
              <p>
                <strong>Speaker:</strong> L'accessibilità web è un diritto fondamentale.
                Rendere i contenuti accessibili significa garantire che tutte le persone,
                indipendentemente dalle loro abilità, possano accedere alle informazioni
                e ai servizi online.
              </p>
              <p class="mt-2">
                Le linee guida WCAG forniscono un framework completo per creare
                esperienze web inclusive. Seguire queste linee guida non solo
                migliora l'accessibilità, ma anche l'usabilità generale del sito.
              </p>
            </div>
          </details>
        </div>
      </section>
      
      <!-- Controlli personalizzati -->
      <section class="mb-5" aria-labelledby="controls-title">
        <h2 id="controls-title" class="h3 mb-3">Controlli Media Personalizzati</h2>
        
        <div class="custom-player">
          <div class="player-screen" aria-label="Schermo del player">
            <span class="player-status">
              {{ isPlaying() ? '▶ In riproduzione' : '⏸ In pausa' }}
            </span>
          </div>
          
          <!-- Controlli accessibili -->
          <div class="player-controls" role="group" aria-label="Controlli media">
            <!-- Play/Pause -->
            <button
              type="button"
              class="btn btn-primary"
              (click)="togglePlay()"
              [attr.aria-label]="isPlaying() ? 'Pausa' : 'Riproduci'"
            >
              {{ isPlaying() ? '⏸' : '▶' }}
              <span class="sr-only">{{ isPlaying() ? 'Pausa' : 'Riproduci' }}</span>
            </button>
            
            <!-- Volume -->
            <div class="volume-control">
              <label for="volume" class="sr-only">Volume</label>
              <input
                type="range"
                id="volume"
                class="form-range"
                min="0"
                max="100"
                [value]="volume()"
                (input)="onVolumeChange($event)"
                aria-label="Regola volume"
                aria-valuemin="0"
                aria-valuemax="100"
                [attr.aria-valuenow]="volume()"
                [attr.aria-valuetext]="'Volume ' + volume() + ' percento'"
              >
              <output for="volume" class="volume-value">
                {{ volume() }}%
              </output>
            </div>
            
            <!-- Sottotitoli toggle -->
            <button
              type="button"
              class="btn btn-outline-secondary"
              (click)="toggleCaptions()"
              [attr.aria-pressed]="captionsEnabled()"
            >
              <span aria-hidden="true">CC</span>
              <span class="sr-only">
                {{ captionsEnabled() ? 'Disattiva' : 'Attiva' }} sottotitoli
              </span>
            </button>
            
            <!-- Schermo intero -->
            <button
              type="button"
              class="btn btn-outline-secondary"
              (click)="toggleFullscreen()"
              aria-label="Schermo intero"
            >
              ⛶
              <span class="sr-only">Schermo intero</span>
            </button>
          </div>
        </div>
      </section>
      
      <!-- Best practices -->
      <section aria-labelledby="best-practices-title">
        <h2 id="best-practices-title" class="h3 mb-3">Best Practices WCAG</h2>
        <div class="card">
          <div class="card-body">
            <ul class="mb-0">
              <li>
                <strong>Alternative testuali:</strong> Fornire trascrizioni complete
                per contenuti audio e video
              </li>
              <li>
                <strong>Sottotitoli (CC):</strong> Includere sottotitoli sincronizzati
                per tutti i contenuti audio
              </li>
              <li>
                <strong>Descrizioni audio:</strong> Fornire narrazioni delle azioni
                visive importanti
              </li>
              <li>
                <strong>Controlli accessibili:</strong> Tutti i controlli devono essere
                utilizzabili da tastiera
              </li>
              <li>
                <strong>Stato dei controlli:</strong> Usare aria-pressed, aria-label
                per comunicare lo stato
              </li>
              <li>
                <strong>Auto-play limitato:</strong> Non avviare automaticamente
                contenuti audio/video senza consenso
              </li>
              <li>
                <strong>Pause/Stop:</strong> Permettere agli utenti di controllare
                la riproduzione
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .media-container {
      max-width: 800px;
    }
    
    /* Placeholder per video/audio */
    .video-placeholder,
    .audio-placeholder {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 300px;
    }
    
    .audio-placeholder {
      min-height: 150px;
    }
    
    .placeholder-content {
      text-align: center;
    }
    
    /* Trascrizione */
    .transcript {
      border: 1px solid #dee2e6;
      border-radius: 0.25rem;
      padding: 1rem;
      background: #f8f9fa;
      
      summary {
        cursor: pointer;
        font-weight: 600;
        user-select: none;
        
        &:hover {
          color: #0d6efd;
        }
        
        &:focus {
          outline: 3px solid #0d6efd;
          outline-offset: 2px;
        }
      }
    }
    
    .transcript-content {
      margin-top: 1rem;
      padding-top: 1rem;
      border-top: 1px solid #dee2e6;
    }
    
    /* Player personalizzato */
    .custom-player {
      max-width: 600px;
      border: 1px solid #dee2e6;
      border-radius: 0.5rem;
      overflow: hidden;
    }
    
    .player-screen {
      background: #212529;
      color: white;
      min-height: 200px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
    }
    
    .player-controls {
      background: #f8f9fa;
      padding: 1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
      flex-wrap: wrap;
    }
    
    .volume-control {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      flex: 1;
      min-width: 150px;
    }
    
    .form-range {
      flex: 1;
      
      &:focus {
        outline: 3px solid #0d6efd;
        outline-offset: 2px;
      }
    }
    
    .volume-value {
      min-width: 3rem;
      text-align: right;
      font-size: 0.875rem;
      color: #6c757d;
    }
    
    /* Screen reader only */
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
    
    /* Button focus visibile */
    button:focus {
      outline: 3px solid #0d6efd;
      outline-offset: 2px;
    }
    
    button[aria-pressed="true"] {
      background-color: #0d6efd;
      color: white;
      border-color: #0d6efd;
    }
  `]
})
export class MultimediaComponent {
  // Stato del player
  isPlaying = signal(false);
  volume = signal(70);
  captionsEnabled = signal(false);
  
  /**
   * Toggle riproduzione
   */
  togglePlay(): void {
    this.isPlaying.update(playing => !playing);
  }
  
  /**
   * Aggiorna volume
   */
  onVolumeChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.volume.set(parseInt(target.value));
  }
  
  /**
   * Toggle sottotitoli
   */
  toggleCaptions(): void {
    this.captionsEnabled.update(enabled => !enabled);
  }
  
  /**
   * Toggle schermo intero
   */
  toggleFullscreen(): void {
    // In un'applicazione reale, implementare fullscreen API
    console.log('Toggling fullscreen...');
  }
}
