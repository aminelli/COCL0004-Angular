/**
 * Modals Page Component
 * 
 * Dimostra dialog e modali accessibili:
 * - Focus trap (il focus rimane nella modal)
 * - Gestione ESC per chiudere
 * - Ripristino focus dopo chiusura
 * - Attributi ARIA appropriati
 * 
 * WCAG Guidelines:
 * - 2.1.2 No Keyboard Trap (eccetto modali)
 * - 2.4.3 Focus Order (ordine logico)
 * - 4.1.2 Name, Role, Value (ARIA dialog)
 * - 4.1.3 Status Messages (annunci)
 */

import { Component, signal, inject, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FocusManagementService } from '../../services/focus-management.service';
import { LiveRegionService } from '../../services/live-region.service';

@Component({
  selector: 'app-modals',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid py-5">
      <h1 class="mb-4">Dialog e Modali Accessibili</h1>
      
      <p class="lead mb-5">
        Esempi di dialog conformi WCAG con focus trap, gestione ESC
        e attributi ARIA appropriati.
      </p>
      
      <!-- Pulsanti per aprire modali -->
      <section class="mb-5" aria-labelledby="examples-title">
        <h2 id="examples-title" class="h3 mb-3">Esempi di Dialog</h2>
        
        <div class="d-flex gap-3 flex-wrap">
          <button
            type="button"
            class="btn btn-primary"
            (click)="openModal('info')"
          >
            Dialog Informativo
          </button>
          
          <button
            type="button"
            class="btn btn-warning"
            (click)="openModal('confirm')"
          >
            Dialog di Conferma
          </button>
          
          <button
            type="button"
            class="btn btn-danger"
            (click)="openModal('alert')"
          >
            Dialog di Alert
          </button>
        </div>
      </section>
      
      <!-- Modal Info -->
      @if (isModalOpen() && modalType() === 'info') {
        <div
          class="modal-backdrop"
          (click)="closeModal()"
          aria-hidden="true"
        ></div>
        
        <div
          class="modal-container"
          role="dialog"
          aria-modal="true"
          aria-labelledby="info-modal-title"
          aria-describedby="info-modal-desc"
          (keydown.escape)="closeModal()"
        >
          <div class="modal-content">
            <div class="modal-header">
              <h2 id="info-modal-title" class="modal-title">
                Informazioni
              </h2>
              <button
                type="button"
                class="btn-close"
                (click)="closeModal()"
                aria-label="Chiudi dialog"
              >
                ×
              </button>
            </div>
            
            <div class="modal-body" id="info-modal-desc">
              <p>
                Questo è un dialog informativo accessibile. Caratteristiche:
              </p>
              <ul>
                <li>Il focus è intrappolato all'interno del dialog</li>
                <li>Premere ESC chiude il dialog</li>
                <li>Clicare fuori dal dialog lo chiude</li>
                <li>Il focus viene ripristinato dopo la chiusura</li>
              </ul>
              <p>
                Prova a navigare con Tab per verificare che il focus
                rimanga all'interno del dialog.
              </p>
            </div>
            
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-primary"
                (click)="closeModal()"
              >
                Ho capito
              </button>
            </div>
          </div>
        </div>
      }
      
      <!-- Modal Confirm -->
      @if (isModalOpen() && modalType() === 'confirm') {
        <div
          class="modal-backdrop"
          (click)="closeModal()"
          aria-hidden="true"
        ></div>
        
        <div
          class="modal-container"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="confirm-modal-title"
          aria-describedby="confirm-modal-desc"
          (keydown.escape)="closeModal()"
        >
          <div class="modal-content">
            <div class="modal-header">
              <h2 id="confirm-modal-title" class="modal-title">
                Conferma Azione
              </h2>
              <button
                type="button"
                class="btn-close"
                (click)="closeModal()"
                aria-label="Chiudi dialog"
              >
                ×
              </button>
            </div>
            
            <div class="modal-body" id="confirm-modal-desc">
              <p>
                Sei sicuro di voler procedere con questa azione?
              </p>
              <p class="text-muted">
                Questa operazione non può essere annullata.
              </p>
            </div>
            
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-outline-secondary"
                (click)="closeModal()"
              >
                Annulla
              </button>
              <button
                type="button"
                class="btn btn-warning"
                (click)="confirmAction()"
              >
                Conferma
              </button>
            </div>
          </div>
        </div>
      }
      
      <!-- Modal Alert -->
      @if (isModalOpen() && modalType() === 'alert') {
        <div
          class="modal-backdrop"
          aria-hidden="true"
        ></div>
        
        <div
          class="modal-container alert-modal"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="alert-modal-title"
          aria-describedby="alert-modal-desc"
          (keydown.escape)="closeModal()"
        >
          <div class="modal-content">
            <div class="modal-header bg-danger text-white">
              <h2 id="alert-modal-title" class="modal-title">
                ⚠ Attenzione
              </h2>
              <button
                type="button"
                class="btn-close btn-close-white"
                (click)="closeModal()"
                aria-label="Chiudi dialog"
              >
                ×
              </button>
            </div>
            
            <div class="modal-body" id="alert-modal-desc">
              <p class="fw-bold">
                Si è verificato un errore critico!
              </p>
              <p>
                Questo dialog utilizza <code>role="alertdialog"</code> per
                comunicare l'urgenza agli screen reader.
              </p>
              <p class="mb-0 text-muted">
                Gli alertdialog vengono annunciati immediatamente agli
                utenti di screen reader.
              </p>
            </div>
            
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-danger"
                (click)="closeModal()"
              >
                Chiudi
              </button>
            </div>
          </div>
        </div>
      }
      
      <!-- Best practices -->
      <section aria-labelledby="practices-title">
        <h2 id="practices-title" class="h3 mb-3">Best Practices Implementate</h2>
        <div class="card">
          <div class="card-body">
            <h3 class="h6">Attributi ARIA:</h3>
            <ul>
              <li>
                <code>role="dialog"</code> o <code>role="alertdialog"</code>
                per identificare il tipo di dialog
              </li>
              <li>
                <code>aria-modal="true"</code> indica che il contenuto
                sottostante è inerte
              </li>
              <li>
                <code>aria-labelledby</code> riferisce all'ID del titolo
              </li>
              <li>
                <code>aria-describedby</code> riferisce alla descrizione
              </li>
            </ul>
            
            <h3 class="h6 mt-3">Gestione Focus:</h3>
            <ul>
              <li>Focus spostato sul dialog all'apertura</li>
              <li>Focus intrappolato all'interno del dialog (Tab cycling)</li>
              <li>Focus ripristinato sull'elemento trigger alla chiusura</li>
            </ul>
            
            <h3 class="h6 mt-3">Navigazione da Tastiera:</h3>
            <ul>
              <li><kbd>ESC</kbd>: Chiude il dialog</li>
              <li><kbd>Tab</kbd>: Naviga tra gli elementi focalizzabili</li>
              <li><kbd>Shift+Tab</kbd>: Naviga all'indietro</li>
            </ul>
            
            <h3 class="h6 mt-3">Distinzione Dialog/AlertDialog:</h3>
            <ul class="mb-0">
              <li>
                <strong>Dialog:</strong> Contenuto informativo o form,
                non richiede azione immediata
              </li>
              <li>
                <strong>AlertDialog:</strong> Richiede attenzione immediata,
                annunciato assertivamente agli screen reader
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    /* Backdrop */
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 1040;
      animation: fadeIn 0.2s;
    }
    
    /* Container modal */
    .modal-container {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 1050;
      max-width: 90%;
      width: 500px;
      max-height: 90vh;
      overflow-y: auto;
      animation: slideIn 0.3s;
      
      /* Focus sul container per gestire ESC */
      outline: none;
    }
    
    .modal-content {
      background: white;
      border-radius: 0.5rem;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    }
    
    .modal-header {
      padding: 1.5rem;
      border-bottom: 1px solid #dee2e6;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .modal-title {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
    }
    
    .btn-close {
      background: none;
      border: none;
      font-size: 2rem;
      line-height: 1;
      cursor: pointer;
      padding: 0;
      width: 2rem;
      height: 2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 0.25rem;
      
      &:hover {
        background: rgba(0, 0, 0, 0.1);
      }
      
      &:focus {
        outline: 3px solid #0d6efd;
        outline-offset: 2px;
      }
    }
    
    .btn-close-white {
      color: white;
      
      &:hover {
        background: rgba(255, 255, 255, 0.2);
      }
    }
    
    .modal-body {
      padding: 1.5rem;
      
      code {
        background: #f8f9fa;
        padding: 0.2rem 0.4rem;
        border-radius: 0.2rem;
        font-size: 0.875em;
      }
    }
    
    .modal-footer {
      padding: 1rem 1.5rem;
      border-top: 1px solid #dee2e6;
      display: flex;
      gap: 0.5rem;
      justify-content: flex-end;
    }
    
    /* Animazioni */
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    
    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translate(-50%, -48%);
      }
      to {
        opacity: 1;
        transform: translate(-50%, -50%);
      }
    }
    
    /* Rispetta le preferenze reduced motion */
    @media (prefers-reduced-motion: reduce) {
      .modal-backdrop,
      .modal-container {
        animation: none;
      }
    }
    
    /* Stili specifici per alert modal */
    .alert-modal .modal-content {
      border: 3px solid #dc3545;
    }
    
    kbd {
      background-color: #212529;
      color: #fff;
      padding: 0.2rem 0.4rem;
      border-radius: 0.2rem;
      font-size: 0.875em;
      font-family: monospace;
    }
  `]
})
export class ModalsComponent {
  private focusService = inject(FocusManagementService);
  private liveRegionService = inject(LiveRegionService);
  
  // Stato modali
  isModalOpen = signal(false);
  modalType = signal<'info' | 'confirm' | 'alert'>('info');
  
  // Cleanup function per focus trap
  private cleanupFocusTrap: (() => void) | null = null;
  
  constructor() {
    // Effect per gestire focus trap quando modal si apre/chiude
    effect(() => {
      if (this.isModalOpen()) {
        // Modal aperta - salva focus e crea trap
        this.focusService.saveFocus();
        
        setTimeout(() => {
          const modalContainer = document.querySelector('.modal-container') as HTMLElement;
          if (modalContainer) {
            this.cleanupFocusTrap = this.focusService.trapFocus(modalContainer);
            modalContainer.focus();
          }
        }, 0);
      } else {
        // Modal chiusa - ripristina focus
        if (this.cleanupFocusTrap) {
          this.cleanupFocusTrap();
          this.cleanupFocusTrap = null;
        }
        this.focusService.restoreFocus();
      }
    });
  }
  
  /**
   * Apre una modal
   */
  openModal(type: 'info' | 'confirm' | 'alert'): void {
    this.modalType.set(type);
    this.isModalOpen.set(true);
    
    // Annuncia apertura agli screen reader
    const messages = {
      info: 'Dialog informativo aperto',
      confirm: 'Dialog di conferma aperto',
      alert: 'Alert dialog aperto'
    };
    
    this.liveRegionService.announce(messages[type]);
  }
  
  /**
   * Chiude la modal
   */
  closeModal(): void {
    this.isModalOpen.set(false);
    this.liveRegionService.announce('Dialog chiuso');
  }
  
  /**
   * Conferma azione
   */
  confirmAction(): void {
    this.liveRegionService.announce('Azione confermata');
    this.closeModal();
  }
}
