/**
 * Forms Page Component
 *
 * Pagina dimostrativa per form accessibili secondo WCAG 2.x
 *
 * WCAG Guidelines implementate:
 * - 1.3.1 Info and Relationships (label associati)
 * - 1.3.5 Identify Input Purpose (autocomplete)
 * - 2.4.6 Headings and Labels (etichette descrittive)
 * - 3.2.2 On Input (nessun cambio di contesto imprevisto)
 * - 3.3.1 Error Identification (identificazione errori)
 * - 3.3.2 Labels or Instructions (istruzioni chiare)
 * - 3.3.3 Error Suggestion (suggerimenti per correggere)
 * - 3.3.4 Error Prevention (conferma per azioni importanti)
 * - 4.1.3 Status Messages (live regions per feedback)
 */

import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { LiveRegionService } from '../../services/live-region.service';

@Component({
  selector: 'app-forms',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './forms.component.html',
  styleUrl: './forms.component.scss'
})
export class FormsComponent {
  private fb = inject(FormBuilder);
  private liveRegionService = inject(LiveRegionService);

  // Signal per tracciare se il form è stato sottomesso
  submitted = signal(false);
  successMessage = signal('');

  // Form reattivo con validatori
  registrationForm: FormGroup = this.fb.group({
    firstName: ['', [Validators.required, Validators.minLength(2)]],
    lastName: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    birthDate: ['', Validators.required],
    country: ['', Validators.required],
    terms: [false, Validators.requiredTrue],
    newsletter: [false]
  });

  /**
   * Verifica se un campo è invalido e dovrebbe mostrare l'errore
   */
  isFieldInvalid(fieldName: string): boolean {
    const field = this.registrationForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched || this.submitted()));
  }

  /**
   * Gestisce l'invio del form
   */
  onSubmit(): void {
    this.submitted.set(true);

    if (this.registrationForm.valid) {
      // Form valido - mostra messaggio di successo
      this.successMessage.set('Registrazione completata con successo!');

      // Annuncia il successo agli screen reader
      this.liveRegionService.announce(
        'Registrazione completata con successo!',
        5000
      );

      // Simula l'invio dei dati
      console.log('Dati form:', this.registrationForm.value);

      // Reset del form dopo 2 secondi
      setTimeout(() => this.resetForm(), 2000);
    } else {
      // Form non valido - annuncia gli errori
      this.liveRegionService.announceAlert(
        'Il form contiene errori. Controlla i campi evidenziati.',
        5000
      );

      // Sposta il focus sul primo campo con errore
      this.focusFirstError();
    }
  }

  /**
   * Reset del form
   */
  resetForm(): void {
    this.registrationForm.reset();
    this.submitted.set(false);
    this.successMessage.set('');
    this.liveRegionService.announce('Form reimpostato');
  }

  /**
   * Sposta il focus sul primo campo con errore
   */
  private focusFirstError(): void {
    const firstErrorField = Object.keys(this.registrationForm.controls)
      .find(key => this.registrationForm.get(key)?.invalid);

    if (firstErrorField) {
      const element = document.getElementById(firstErrorField);
      element?.focus();
    }
  }
}
