/**
 * Not Found (404) Component
 * 
 * Pagina di errore 404 accessibile con link utili
 * per aiutare l'utente a trovare ciò che cerca.
 */

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container-fluid py-5">
      <div class="error-container">
        <!-- Messaggio di errore principale -->
        <div role="alert" aria-live="polite">
          <h1 class="error-code" aria-label="Errore 404">404</h1>
          <h2 class="error-title">Pagina Non Trovata</h2>
          <p class="error-description">
            Spiacenti, la pagina che stai cercando non esiste o è stata spostata.
          </p>
        </div>
        
        <!-- Link utili per la navigazione -->
        <nav class="error-nav" aria-label="Navigazione dalla pagina di errore">
          <h3 class="h5 mb-3">Dove vuoi andare?</h3>
          <ul class="error-links">
            <li>
              <a routerLink="/" class="btn btn-primary">
                Torna alla Home
              </a>
            </li>
            <li>
              <a routerLink="/forms" class="btn btn-outline-primary">
                Form Accessibili
              </a>
            </li>
            <li>
              <a routerLink="/navigation" class="btn btn-outline-primary">
                Navigazione
              </a>
            </li>
          </ul>
        </nav>
        
        <!-- Informazioni aggiuntive -->
        <aside class="error-help" aria-labelledby="help-title">
          <h3 id="help-title" class="h6">Hai bisogno di aiuto?</h3>
          <p>
            Se ritieni che questa sia un'errore, puoi:
          </p>
          <ul>
            <li>Verificare l'URL nella barra degli indirizzi</li>
            <li>Utilizzare il menu di navigazione per trovare ciò che cerchi</li>
            <li>Tornare alla pagina precedente usando il pulsante indietro del browser</li>
          </ul>
        </aside>
      </div>
    </div>
  `,
  styles: [`
    .error-container {
      max-width: 600px;
      margin: 0 auto;
      text-align: center;
      padding: 2rem 0;
    }
    
    .error-code {
      font-size: 6rem;
      font-weight: 700;
      color: #dc3545;
      margin-bottom: 1rem;
      line-height: 1;
    }
    
    .error-title {
      font-size: 2rem;
      font-weight: 600;
      color: #212529;
      margin-bottom: 1rem;
    }
    
    .error-description {
      font-size: 1.125rem;
      color: #6c757d;
      margin-bottom: 2rem;
    }
    
    .error-nav {
      margin: 3rem 0;
    }
    
    .error-links {
      list-style: none;
      padding: 0;
      display: flex;
      flex-direction: column;
      gap: 1rem;
      align-items: center;
      
      li {
        width: 100%;
        max-width: 300px;
      }
      
      a {
        width: 100%;
        
        &:focus {
          outline: 3px solid #0d6efd;
          outline-offset: 2px;
        }
      }
    }
    
    .error-help {
      margin-top: 3rem;
      padding: 1.5rem;
      background: #f8f9fa;
      border-radius: 0.5rem;
      text-align: left;
      
      ul {
        margin-bottom: 0;
      }
    }
    
    @media (max-width: 767px) {
      .error-code {
        font-size: 4rem;
      }
      
      .error-title {
        font-size: 1.5rem;
      }
    }
  `]
})
export class NotFoundComponent {}
