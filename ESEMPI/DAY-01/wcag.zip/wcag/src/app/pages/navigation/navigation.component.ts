/**
 * Navigation Page Component
 * 
 * Dimostra best practices per navigazione accessibile:
 * - Breadcrumb navigation
 * - Tablist pattern (tabs)
 * - Menu dropdown
 * - Accordion
 * 
 * WCAG Guidelines:
 * - 2.1.1 Keyboard (navigazione da tastiera completa)
 * - 2.4.1 Bypass Blocks (skip links)
 * - 2.4.3 Focus Order (ordine logico)
 * - 2.4.7 Focus Visible (focus sempre visibile)
 * - 4.1.2 Name, Role, Value (ARIA appropriato)
 */

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Tab {
  id: string;
  label: string;
  content: string;
}

interface AccordionItem {
  id: string;
  title: string;
  content: string;
  expanded: boolean;
}

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid py-5">
      <h1 class="mb-4">Navigazione Accessibile</h1>
      
      <p class="lead mb-5">
        Esempi di componenti di navigazione conformi WCAG con supporto completo
        per tastiera e screen reader.
      </p>
      
      <!-- Breadcrumb -->
      <section class="mb-5" aria-labelledby="breadcrumb-title">
        <h2 id="breadcrumb-title" class="h3 mb-3">Breadcrumb Navigation</h2>
        
        <nav aria-label="Breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#" (click)="$event.preventDefault()">Home</a>
            </li>
            <li class="breadcrumb-item">
              <a href="#" (click)="$event.preventDefault()">Esempi</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
              Navigazione
            </li>
          </ol>
        </nav>
      </section>
      
      <!-- Tabs -->
      <section class="mb-5" aria-labelledby="tabs-title">
        <h2 id="tabs-title" class="h3 mb-3">Tabs (Schede)</h2>
        
        <div class="tabs-container">
          <!-- Tab list -->
          <div role="tablist" aria-label="Esempio di tabs" class="nav nav-tabs">
            @for (tab of tabs(); track tab.id) {
              <button
                role="tab"
                [id]="tab.id"
                [attr.aria-selected]="activeTab() === tab.id"
                [attr.aria-controls]="tab.id + '-panel'"
                [tabindex]="activeTab() === tab.id ? 0 : -1"
                [class.active]="activeTab() === tab.id"
                class="nav-link"
                (click)="selectTab(tab.id)"
                (keydown)="handleTabKeydown($event, $index)"
              >
                {{ tab.label }}
              </button>
            }
          </div>
          
          <!-- Tab panels -->
          @for (tab of tabs(); track tab.id) {
            <div
              role="tabpanel"
              [id]="tab.id + '-panel'"
              [attr.aria-labelledby]="tab.id"
              [hidden]="activeTab() !== tab.id"
              [tabindex]="0"
              class="tab-panel"
            >
              {{ tab.content }}
            </div>
          }
        </div>
      </section>
      
      <!-- Accordion -->
      <section class="mb-5" aria-labelledby="accordion-title">
        <h2 id="accordion-title" class="h3 mb-3">Accordion</h2>
        
        <div class="accordion">
          @for (item of accordionItems(); track item.id) {
            <div class="accordion-item">
              <h3 class="accordion-header">
                <button
                  class="accordion-button"
                  [class.collapsed]="!item.expanded"
                  type="button"
                  [attr.aria-expanded]="item.expanded"
                  [attr.aria-controls]="item.id + '-content'"
                  (click)="toggleAccordion(item.id)"
                >
                  {{ item.title }}
                </button>
              </h3>
              <div
                [id]="item.id + '-content'"
                class="accordion-collapse"
                [class.show]="item.expanded"
                role="region"
                [attr.aria-labelledby]="item.id"
              >
                <div class="accordion-body">
                  {{ item.content }}
                </div>
              </div>
            </div>
          }
        </div>
      </section>
      
      <!-- Indicazioni d'uso -->
      <section aria-labelledby="usage-title">
        <h2 id="usage-title" class="h3 mb-3">Navigazione da Tastiera</h2>
        <div class="card">
          <div class="card-body">
            <h3 class="h6">Tabs (Schede):</h3>
            <ul>
              <li><kbd>Tab</kbd>: Sposta il focus nella lista delle schede</li>
              <li><kbd>←</kbd> <kbd>→</kbd>: Naviga tra le schede</li>
              <li><kbd>Home</kbd>: Vai alla prima scheda</li>
              <li><kbd>End</kbd>: Vai all'ultima scheda</li>
            </ul>
            
            <h3 class="h6 mt-3">Accordion:</h3>
            <ul>
              <li><kbd>Tab</kbd>: Sposta il focus al prossimo header</li>
              <li><kbd>Enter</kbd> o <kbd>Spazio</kbd>: Espandi/contrai la sezione</li>
            </ul>
            
            <h3 class="h6 mt-3">Breadcrumb:</h3>
            <ul>
              <li><kbd>Tab</kbd>: Naviga tra i link</li>
              <li><kbd>Enter</kbd>: Segui il link</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .breadcrumb {
      background-color: #f8f9fa;
      padding: 0.75rem 1rem;
      border-radius: 0.25rem;
    }
    
    .nav-tabs {
      border-bottom: 2px solid #dee2e6;
      margin-bottom: 0;
      
      .nav-link {
        background: none;
        border: none;
        border-bottom: 3px solid transparent;
        color: #495057;
        padding: 0.75rem 1rem;
        cursor: pointer;
        transition: all 0.2s;
        
        &:hover {
          border-bottom-color: #0d6efd;
          color: #0d6efd;
        }
        
        &:focus {
          outline: 3px solid #0d6efd;
          outline-offset: 2px;
          z-index: 1;
        }
        
        &.active {
          border-bottom-color: #0d6efd;
          color: #0d6efd;
          font-weight: 600;
        }
      }
    }
    
    .tab-panel {
      padding: 1.5rem;
      background: #f8f9fa;
      border: 1px solid #dee2e6;
      border-top: none;
      border-radius: 0 0 0.25rem 0.25rem;
      
      &:focus {
        outline: 3px solid #0d6efd;
        outline-offset: -3px;
      }
    }
    
    .accordion-item {
      border: 1px solid #dee2e6;
      margin-bottom: 0.5rem;
      border-radius: 0.25rem;
      overflow: hidden;
    }
    
    .accordion-header {
      margin: 0;
    }
    
    .accordion-button {
      width: 100%;
      padding: 1rem;
      background: #f8f9fa;
      border: none;
      text-align: left;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 500;
      transition: background-color 0.2s;
      position: relative;
      
      &::after {
        content: '▼';
        position: absolute;
        right: 1rem;
        transition: transform 0.2s;
      }
      
      &:hover {
        background: #e9ecef;
      }
      
      &:focus {
        outline: 3px solid #0d6efd;
        outline-offset: -3px;
        z-index: 1;
      }
      
      &.collapsed::after {
        transform: rotate(-90deg);
      }
    }
    
    .accordion-collapse {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease;
      
      &.show {
        max-height: 500px;
      }
    }
    
    .accordion-body {
      padding: 1rem;
      background: #fff;
    }
    
    kbd {
      background-color: #212529;
      color: #fff;
      padding: 0.2rem 0.4rem;
      border-radius: 0.2rem;
      font-size: 0.875em;
      font-family: monospace;
    }
    
    /* Rispetta le preferenze reduced motion */
    @media (prefers-reduced-motion: reduce) {
      .nav-link,
      .accordion-button,
      .accordion-collapse {
        transition: none;
      }
      
      .accordion-button::after {
        transition: none;
      }
    }
  `]
})
export class NavigationComponent {
  // Tabs
  tabs = signal<Tab[]>([
    { id: 'tab1', label: 'Primo', content: 'Contenuto della prima scheda. Questa scheda mostra un esempio di pattern tab accessibile.' },
    { id: 'tab2', label: 'Secondo', content: 'Contenuto della seconda scheda. Le tabs permettono di organizzare il contenuto in modo efficiente.' },
    { id: 'tab3', label: 'Terzo', content: 'Contenuto della terza scheda. Ogni tab è accessibile da tastiera e screen reader.' }
  ]);
  
  activeTab = signal('tab1');
  
  // Accordion
  accordionItems = signal<AccordionItem[]>([
    { 
      id: 'acc1', 
      title: 'Cos\'è WCAG?', 
      content: 'WCAG (Web Content Accessibility Guidelines) sono linee guida internazionali per rendere i contenuti web accessibili a tutti.', 
      expanded: false 
    },
    { 
      id: 'acc2', 
      title: 'Livelli di conformità', 
      content: 'WCAG definisce tre livelli di conformità: A (minimo), AA (raccomandato), AAA (massimo).', 
      expanded: false 
    },
    { 
      id: 'acc3', 
      title: 'Importanza dell\'accessibilità', 
      content: 'L\'accessibilità web garantisce che tutti possano accedere e utilizzare i contenuti digitali, indipendentemente dalle loro abilità.', 
      expanded: false 
    }
  ]);
  
  /**
   * Seleziona una tab
   */
  selectTab(tabId: string): void {
    this.activeTab.set(tabId);
  }
  
  /**
   * Gestisce la navigazione da tastiera nelle tabs
   * Arrow left/right, Home, End
   */
  handleTabKeydown(event: KeyboardEvent, currentIndex: number): void {
    const tabs = this.tabs();
    let nextIndex = currentIndex;
    
    switch (event.key) {
      case 'ArrowLeft':
        event.preventDefault();
        nextIndex = currentIndex > 0 ? currentIndex - 1 : tabs.length - 1;
        break;
      case 'ArrowRight':
        event.preventDefault();
        nextIndex = currentIndex < tabs.length - 1 ? currentIndex + 1 : 0;
        break;
      case 'Home':
        event.preventDefault();
        nextIndex = 0;
        break;
      case 'End':
        event.preventDefault();  
        nextIndex = tabs.length - 1;
        break;
      default:
        return;
    }
    
    // Sposta il focus e attiva la tab
    this.selectTab(tabs[nextIndex].id);
    
    // Focus sulla nuova tab
    setTimeout(() => {
      const element = document.getElementById(tabs[nextIndex].id);
      element?.focus();
    }, 0);
  }
  
  /**
   * Toggle accordion item
   */
  toggleAccordion(itemId: string): void {
    this.accordionItems.update(items => 
      items.map(item => 
        item.id === itemId 
          ? { ...item, expanded: !item.expanded } 
          : item
      )
    );
  }
}
