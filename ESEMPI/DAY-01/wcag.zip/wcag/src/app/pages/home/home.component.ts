/**
 * Home Page Component
 *
 * Pagina iniziale dell'applicazione che presenta
 * le best practices WCAG implementate nel progetto.
 */

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent {}
