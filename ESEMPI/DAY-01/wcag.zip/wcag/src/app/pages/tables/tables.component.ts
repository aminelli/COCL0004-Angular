/**
 * Tables Page Component
 * 
 * Dimostra tabelle dati accessibili secondo WCAG:
 * - Headers appropriati con scope
 * - Caption descrittiva
 * - Struttura semantica corretta
 * - Navigazione ottimizzata per screen reader
 * 
 * WCAG Guidelines:
 * - 1.3.1 Info and Relationships (struttura semantica)
 * - 2.4.6 Headings and Labels (caption e headers)
 * - 4.1.1 Parsing (HTML valido)
 */

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

interface User {
  id: number;
  nome: string;
  cognome: string;
  email: string;
  ruolo: string;
  stato: 'attivo' | 'inattivo';
}

@Component({
  selector: 'app-tables',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container-fluid py-5">
      <h1 class="mb-4">Tabelle Accessibili</h1>
      
      <p class="lead mb-5">
        Esempi di tabelle dati conformi WCAG con headers, caption e
        navigazione ottimizzata per screen reader.
      </p>
      
      <!-- Tabella semplice -->
      <section class="mb-5" aria-labelledby="simple-table-title">
        <h2 id="simple-table-title" class="h3 mb-3">Tabella Semplice</h2>
        
        <div class="table-responsive">
          <!-- 
            Caption: fornisce un riepilogo della tabella per screen reader
            Visivamente nascosta ma accessibile
          -->
          <table class="table table-striped table-hover">
            <caption class="sr-only">
              Elenco utenti con informazioni di contatto e stato
            </caption>
            
            <!-- 
              thead: raggruppa le celle di intestazione
              th: celle di intestazione con scope="col" per colonne
            -->
            <thead class="table-dark">
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Cognome</th>
                <th scope="col">Email</th>
                <th scope="col">Ruolo</th>
                <th scope="col">Stato</th>
              </tr>
            </thead>
            
            <!-- tbody: raggruppa le righe di dati -->
            <tbody>
              @for (user of users(); track user.id) {
                <tr>
                  <!-- th con scope="row" per la prima cella (header di riga) -->
                  <th scope="row">{{ user.id }}</th>
                  <td>{{ user.nome }}</td>
                  <td>{{ user.cognome }}</td>
                  <td>{{ user.email }}</td>
                  <td>{{ user.ruolo }}</td>
                  <td>
                    <span 
                      class="badge"
                      [class.bg-success]="user.stato === 'attivo'"
                      [class.bg-secondary]="user.stato === 'inattivo'"
                    >
                      {{ user.stato }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
      
      <!-- Tabella con colonne raggruppate -->
      <section class="mb-5" aria-labelledby="complex-table-title">
        <h2 id="complex-table-title" class="h3 mb-3">Tabella con Colonne Raggruppate</h2>
        
        <div class="table-responsive">
          <table class="table table-bordered">
            <caption class="caption-top">
              Statistiche mensili per trimestre
            </caption>
            
            <thead class="table-light">
              <tr>
                <th scope="col" rowspan="2">Mese</th>
                <!-- colgroup: raggruppa colonne con colspan -->
                <th scope="colgroup" colspan="2">Primo Trimestre</th>
                <th scope="colgroup" colspan="2">Secondo Trimestre</th>
              </tr>
              <tr>
                <th scope="col">Vendite</th>
                <th scope="col">Profitti</th>
                <th scope="col">Vendite</th>
                <th scope="col">Profitti</th>
              </tr>
            </thead>
            
            <tbody>
              <tr>
                <th scope="row">Gennaio</th>
                <td>€ 10.000</td>
                <td>€ 2.000</td>
                <td>-</td>
                <td>-</td>
              </tr>
              <tr>
                <th scope="row">Febbraio</th>
                <td>€ 12.000</td>
                <td>€ 2.400</td>
                <td>-</td>
                <td>-</td>
              </tr>
              <tr>
                <th scope="row">Marzo</th>
                <td>€ 15.000</td>
                <td>€ 3.000</td>
                <td>-</td>
                <td>-</td>
              </tr>
              <tr>
                <th scope="row">Aprile</th>
                <td>-</td>
                <td>-</td>
                <td>€ 14.000</td>
                <td>€ 2.800</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
      
      <!-- Tabella con ordinamento -->
      <section class="mb-5" aria-labelledby="sortable-table-title">
        <h2 id="sortable-table-title" class="h3 mb-3">Tabella Ordinabile</h2>
        
        <div class="table-responsive">
          <table class="table">
            <caption class="sr-only">
              Elenco prodotti ordinabili per nome, prezzo o categoria
            </caption>
            
            <thead>
              <tr>
                <th scope="col">
                  <button 
                    class="sort-button"
                    (click)="sortBy('nome')"
                    [attr.aria-pressed]="sortColumn() === 'nome'"
                  >
                    Prodotto
                    @if (sortColumn() === 'nome') {
                      <span aria-hidden="true">
                        {{ sortDirection() === 'asc' ? '▲' : '▼' }}
                      </span>
                    }
                    <span class="sr-only">
                      @if (sortColumn() === 'nome') {
                        , ordinato {{ sortDirection() === 'asc' ? 'crescente' : 'decrescente' }}
                      } @else {
                        , non ordinato
                      }
                    </span>
                  </button>
                </th>
                <th scope="col">
                  <button 
                    class="sort-button"
                    (click)="sortBy('prezzo')"
                    [attr.aria-pressed]="sortColumn() === 'prezzo'"
                  >
                    Prezzo
                    @if (sortColumn() === 'prezzo') {
                      <span aria-hidden="true">
                        {{ sortDirection() === 'asc' ? '▲' : '▼' }}
                      </span>
                    }
                    <span class="sr-only">
                      @if (sortColumn() === 'prezzo') {
                        , ordinato {{ sortDirection() === 'asc' ? 'crescente' : 'decrescente' }}
                      } @else {
                        , non ordinato
                      }
                    </span>
                  </button>
                </th>
                <th scope="col">Categoria</th>
              </tr>
            </thead>
            
            <tbody>
              @for (item of sortedProducts(); track item.nome) {
                <tr>
                  <th scope="row">{{ item.nome }}</th>
                  <td>€ {{ item.prezzo }}</td>
                  <td>{{ item.categoria }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </section>
      
      <!-- Linee guida -->
      <section aria-labelledby="guidelines-title">
        <h2 id="guidelines-title" class="h3 mb-3">Best Practices Implementate</h2>
        <div class="card">
          <div class="card-body">
            <ul class="mb-0">
              <li>
                <strong>Caption:</strong> Ogni tabella ha una caption che descrive
                il contenuto (può essere visivamente nascosta)
              </li>
              <li>
                <strong>Headers (th):</strong> Utilizzo di &lt;th&gt; per le celle
                di intestazione invece di &lt;td&gt;
              </li>
              <li>
                <strong>Scope:</strong> Attributo scope="col" per colonne e scope="row"
                per righe per indicare la relazione
              </li>
              <li>
                <strong>Struttura semantica:</strong> Uso di thead, tbody e tfoot
                per raggruppare logicamente le righe
              </li>
              <li>
                <strong>Ordinamento accessibile:</strong> Pulsanti con aria-pressed
                e annuncio dello stato di ordinamento
              </li>
              <li>
                <strong>Responsive:</strong> Tabelle avvolte in .table-responsive
                per scroll orizzontale su schermi piccoli
              </li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .table-responsive {
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }
    
    /* Caption visivamente nascosto ma accessibile */
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
    
    .caption-top {
      caption-side: top;
      padding: 0.5rem 0;
      font-weight: 600;
      color: #212529;
    }
    
    .sort-button {
      background: none;
      border: none;
      padding: 0;
      font: inherit;
      font-weight: 600;
      color: inherit;
      cursor: pointer;
      text-align: left;
      width: 100%;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      
      &:hover {
        color: #0d6efd;
      }
      
      &:focus {
        outline: 3px solid #0d6efd;
        outline-offset: 2px;
      }
      
      &[aria-pressed="true"] {
        color: #0d6efd;
      }
    }
    
    /* Miglioramenti visivi per accessibilità */
    .table {
      th, td {
        vertical-align: middle;
      }
      
      /* Focus visibile per celle con contenuto interattivo */
      a:focus,
      button:focus {
        outline: 3px solid #0d6efd;
        outline-offset: 2px;
      }
    }
    
    /* Strisce alternate per migliore leggibilità */
    .table-striped > tbody > tr:nth-of-type(odd) > * {
      background-color: rgba(0, 0, 0, 0.02);
    }
    
    /* Hover per evidenziare la riga */
    .table-hover > tbody > tr:hover > * {
      background-color: rgba(0, 0, 0, 0.05);
    }
  `]
})
export class TablesComponent {
  // Dati utenti
  users = signal<User[]>([
    { id: 1, nome: 'Mario', cognome: 'Rossi', email: 'mario.rossi@example.com', ruolo: 'Admin', stato: 'attivo' },
    { id: 2, nome: 'Laura', cognome: 'Bianchi', email: 'laura.bianchi@example.com', ruolo: 'Editor', stato: 'attivo' },
    { id: 3, nome: 'Giuseppe', cognome: 'Verdi', email: 'giuseppe.verdi@example.com', ruolo: 'Viewer', stato: 'inattivo' },
    { id: 4, nome: 'Anna', cognome: 'Neri', email: 'anna.neri@example.com', ruolo: 'Editor', stato: 'attivo' },
    { id: 5, nome: 'Paolo', cognome: 'Ferrari', email: 'paolo.ferrari@example.com', ruolo: 'Admin', stato: 'attivo' }
  ]);
  
  // Dati prodotti per tabella ordinabile
  private products = signal([
    { nome: 'Laptop', prezzo: 899, categoria: 'Elettronica' },
    { nome: 'Mouse', prezzo: 25, categoria: 'Accessori' },
    { nome: 'Tastiera', prezzo: 75, categoria: 'Accessori' },
    { nome: 'Monitor', prezzo: 250, categoria: 'Elettronica' },
    { nome: 'Webcam', prezzo: 60, categoria: 'Elettronica' }
  ]);
  
  // Stato ordinamento
  sortColumn = signal<string>('');
  sortDirection = signal<'asc' | 'desc'>('asc');
  
  // Prodotti ordinati
  sortedProducts = signal(this.products());
  
  /**
   * Ordina tabella per colonna
   */
  sortBy(column: string): void {
    // Se stessa colonna, inverti direzione
    if (this.sortColumn() === column) {
      this.sortDirection.update(dir => dir === 'asc' ? 'desc' : 'asc');
    } else {
      // Nuova colonna, ordine ascendente
      this.sortColumn.set(column);
      this.sortDirection.set('asc');
    }
    
    // Ordina i prodotti
    const sorted = [...this.products()].sort((a, b) => {
      const aVal = a[column as keyof typeof a];
      const bVal = b[column as keyof typeof b];
      
      if (aVal < bVal) return this.sortDirection() === 'asc' ? -1 : 1;
      if (aVal > bVal) return this.sortDirection() === 'asc' ? 1 : -1;
      return 0;
    });
    
    this.sortedProducts.set(sorted);
  }
}
