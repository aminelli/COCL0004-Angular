/**
 * Definizione delle route dell'applicazione
 *
 * Tutte le route sono lazy-loaded per ottimizzare il bundle size
 * Ogni route ha un titolo per accessibilità e SEO
 */

import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/home/home.component').then(m => m.HomeComponent),
    title: 'Home - WCAG Angular 21'
  },
  {
    path: 'forms',
    loadComponent: () => import('./pages/forms/forms.component').then(m => m.FormsComponent),
    title: 'Form Accessibili - WCAG Angular 21'
  },
  {
    path: 'navigation',
    loadComponent: () => import('./pages/navigation/navigation.component').then(m => m.NavigationComponent),
    title: 'Navigazione Accessibile - WCAG Angular 21'
  },
  {
    path: 'multimedia',
    loadComponent: () => import('./pages/multimedia/multimedia.component').then(m => m.MultimediaComponent),
    title: 'Contenuti Multimediali - WCAG Angular 21'
  },
  {
    path: 'tables',
    loadComponent: () => import('./pages/tables/tables.component').then(m => m.TablesComponent),
    title: 'Tabelle Accessibili - WCAG Angular 21'
  },
  {
    path: 'modals',
    loadComponent: () => import('./pages/modals/modals.component').then(m => m.ModalsComponent),
    title: 'Modali Accessibili - WCAG Angular 21'
  },
  {
    path: 'colors',
    loadComponent: () => import('./pages/colors/colors.component').then(m => m.ColorsComponent),
    title: 'Contrasto Colori - WCAG Angular 21'
  },
  {
    // 404 - Not Found
    path: '**',
    loadComponent: () => import('./pages/not-found/not-found.component').then(m => m.NotFoundComponent),
    title: 'Pagina Non Trovata - WCAG Angular 21'
  }
];
