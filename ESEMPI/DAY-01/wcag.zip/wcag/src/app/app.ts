/**
 * Root Component dell'applicazione Angular 21
 *
 * Questo componente standalone rappresenta la radice dell'applicazione.
 * Include:
 * - Header con navigazione accessibile
 * - Skip links per navigazione da tastiera
 * - Router outlet per le pagine
 * - Footer accessibile
 * - Live region per annunci agli screen reader
 */


import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SkipLinksComponent } from './components/skip-links/skip-links.component';
import { LiveRegionComponent } from './components/live-region/live-region.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent, SkipLinksComponent, LiveRegionComponent],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
    // Questo componente usa il template e non necessita di logica aggiuntiva
    // I dati e lo stato sono gestiti dai componenti figli e dai servizi
}
