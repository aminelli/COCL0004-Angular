/**
 * Componente Footer
 * 
 * WCAG Principles:
 * - Landmark contentinfo (role="contentinfo" implicito in <footer>)
 * - Link accessibili con contrasto appropriato
 * - Informazioni di copyright e contatto
 */

import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  template: `
    <footer class="app-footer" id="footer">
      <div class="container-fluid">
        <div class="row">
          <!-- Informazioni progetto -->
          <div class="col-md-6">
            <h2 class="footer-title">WCAG Angular 21</h2>
            <p class="footer-description">
              Progetto dimostrativo per best practices di accessibilità web
              secondo gli standard WCAG 2.x in Angular 21.
            </p>
          </div>
          
          <!-- Link utili -->
          <div class="col-md-3">
            <h3 class="footer-subtitle">Risorse</h3>
            <ul class="footer-links">
              <li>
                <a 
                  href="https://www.w3.org/WAI/WCAG22/quickref/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  class="footer-link">
                  WCAG 2.2 Guidelines
                  <span class="sr-only">(Si apre in una nuova finestra)</span>
                </a>
              </li>
              <li>
                <a 
                  href="https://angular.dev/best-practices/a11y" 
                  target="_blank"
                  rel="noopener noreferrer"
                  class="footer-link">
                  Angular Accessibility
                  <span class="sr-only">(Si apre in una nuova finestra)</span>
                </a>
              </li>
              <li>
                <a 
                  href="https://www.w3.org/WAI/ARIA/apg/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  class="footer-link">
                  ARIA Authoring Practices
                  <span class="sr-only">(Si apre in una nuova finestra)</span>
                </a>
              </li>
            </ul>
          </div>
          
          <!-- Conformità WCAG -->
          <div class="col-md-3">
            <h3 class="footer-subtitle">Conformità</h3>
            <p class="wcag-badge">
              <strong>WCAG 2.2</strong><br>
              Livello AA
            </p>
            <p class="footer-text">
              Questo sito è progettato per essere conforme agli standard
              di accessibilità WCAG 2.2 livello AA.
            </p>
          </div>
        </div>
        
        <!-- Copyright -->
        <div class="row">
          <div class="col-12">
            <hr class="footer-divider">
            <p class="copyright">
              © {{ currentYear }} WCAG Angular 21 - Progetto Educativo
            </p>
          </div>
        </div>
      </div>
    </footer>
  `,
  styles: [`
    .app-footer {
      background-color: #212529;
      color: #f8f9fa;
      padding: 3rem 0 1rem;
      margin-top: 4rem;
    }
    
    .footer-title {
      font-size: 1.5rem;
      font-weight: 700;
      color: #fff;
      margin-bottom: 1rem;
    }
    
    .footer-subtitle {
      font-size: 1.25rem;
      font-weight: 600;
      color: #fff;
      margin-bottom: 1rem;
    }
    
    .footer-description,
    .footer-text {
      color: #adb5bd;
      line-height: 1.6;
      margin-bottom: 1rem;
    }
    
    .footer-links {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .footer-link {
      color: #0dcaf0;
      text-decoration: none;
      display: inline-block;
      margin-bottom: 0.5rem;
      
      /* Contrasto per link su sfondo scuro (WCAG AA) */
      &:hover {
        color: #6edff6;
        text-decoration: underline;
      }
      
      /* Focus visibile */
      &:focus {
        outline: 3px solid #0dcaf0;
        outline-offset: 2px;
      }
    }
    
    /* Screen reader only */
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
    
    .wcag-badge {
      background-color: #0d6efd;
      color: #fff;
      padding: 1rem;
      border-radius: 0.25rem;
      text-align: center;
      margin-bottom: 1rem;
      
      strong {
        font-size: 1.25rem;
        display: block;
        margin-bottom: 0.25rem;
      }
    }
    
    .footer-divider {
      border: 0;
      border-top: 1px solid #495057;
      margin: 2rem 0 1rem;
    }
    
    .copyright {
      text-align: center;
      color: #6c757d;
      margin: 0;
      font-size: 0.875rem;
    }
    
    @media (max-width: 767px) {
      .app-footer {
        padding: 2rem 0 1rem;
      }
      
      .col-md-3,
      .col-md-6 {
        margin-bottom: 2rem;
      }
    }
  `]
})
export class FooterComponent {
  // Anno corrente per il copyright
  currentYear = new Date().getFullYear();
}
