/**
 * Componente Live Region
 * 
 * WCAG 4.1.3 - Status Messages
 * Area live (ARIA live region) per annunciare messaggi dinamici agli screen reader.
 * Utile per notifiche, errori, conferme senza spostare il focus.
 * 
 * Utilizza Angular signals per la reattività.
 */

import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LiveRegionService } from '../../services/live-region.service';

@Component({
  selector: 'app-live-region',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- 
      ARIA live region con politeness level "polite"
      - polite: aspetta che l'utente finisca l'azione corrente
      - assertive: interrompe immediatamente
      
      atomic="true": legge tutto il contenuto anche se cambia solo una parte
    -->
    <div 
      class="sr-only" 
      role="status" 
      aria-live="polite" 
      aria-atomic="true">
      {{ message() }}
    </div>
    
    <!-- Live region per messaggi di errore (assertive) -->
    <div 
      class="sr-only" 
      role="alert" 
      aria-live="assertive" 
      aria-atomic="true">
      {{ alertMessage() }}
    </div>
  `,
  styles: [`
    /* Screen reader only - nasconde visivamente ma mantiene accessibile */
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
  `]
})
export class LiveRegionComponent {
  // Inject del servizio live region
  private liveRegionService = inject(LiveRegionService);
  
  // Signals per messaggi reattivi (Angular 21)
  message = this.liveRegionService.message;
  alertMessage = this.liveRegionService.alertMessage;
}
