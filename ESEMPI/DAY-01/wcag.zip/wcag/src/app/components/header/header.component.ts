/**
 * Componente Header
 * 
 * WCAG Principles implementati:
 * - Landmark navigation (role="banner" implicito in <header>)
 * - Navigazione da tastiera completa
 * - Focus visibile su tutti gli elementi
 * - Contrasto colori conforme AA
 * - Link corrente indicato con aria-current
 */

import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <header class="app-header">
      <div class="container-fluid">
        <div class="row align-items-center">
          <!-- Logo e titolo -->
          <div class="col-md-3">
            <a routerLink="/" class="logo-link" aria-label="Vai alla home page">
              <h1 class="logo">
                <span class="sr-only">WCAG Angular 21 - </span>
                Accessibilità
              </h1>
            </a>
          </div>
          
          <!-- Navigazione principale -->
          <nav class="col-md-9" id="main-nav" aria-label="Navigazione principale">
            <!-- Toggle menu per mobile -->
            <button 
              class="navbar-toggler d-md-none"
              type="button"
              (click)="toggleMenu()"
              [attr.aria-expanded]="isMenuOpen()"
              aria-controls="navbarNav"
              aria-label="Toggle navigation menu">
              <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Menu items -->
            <ul 
              class="nav-list"
              id="navbarNav"
              [class.show]="isMenuOpen()">
              <li class="nav-item">
                <a 
                  routerLink="/" 
                  routerLinkActive="active"
                  [routerLinkActiveOptions]="{exact: true}"
                  class="nav-link"
                  [attr.aria-current]="isHomePage() ? 'page' : null">
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a 
                  routerLink="/forms" 
                  routerLinkActive="active"
                  class="nav-link">
                  Form
                </a>
              </li>
              <li class="nav-item">
                <a 
                  routerLink="/navigation" 
                  routerLinkActive="active"
                  class="nav-link">
                  Navigazione
                </a>
              </li>
              <li class="nav-item">
                <a 
                  routerLink="/multimedia" 
                  routerLinkActive="active"
                  class="nav-link">
                  Multimedia
                </a>
              </li>
              <li class="nav-item">
                <a 
                  routerLink="/tables" 
                  routerLinkActive="active"
                  class="nav-link">
                  Tabelle
                </a>
              </li>
              <li class="nav-item">
                <a 
                  routerLink="/modals" 
                  routerLinkActive="active"
                  class="nav-link">
                  Modali
                </a>
              </li>
              <li class="nav-item">
                <a 
                  routerLink="/colors" 
                  routerLinkActive="active"
                  class="nav-link">
                  Colori
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .app-header {
      background-color: #0d6efd;
      color: #fff;
      padding: 1rem 0;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .logo-link {
      text-decoration: none;
      color: inherit;
      display: block;
      
      &:hover {
        opacity: 0.9;
      }
      
      &:focus {
        outline: 3px solid #fff;
        outline-offset: 2px;
      }
    }
    
    .logo {
      margin: 0;
      font-size: 1.5rem;
      font-weight: 700;
      color: #fff;
    }
    
    /* Screen reader only */
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
    
    /* Navbar toggler per mobile */
    .navbar-toggler {
      background: transparent;
      border: 2px solid #fff;
      color: #fff;
      padding: 0.5rem;
      cursor: pointer;
      
      &:focus {
        outline: 3px solid #fff;
        outline-offset: 2px;
      }
    }
    
    .navbar-toggler-icon {
      display: block;
      width: 24px;
      height: 3px;
      background: #fff;
      position: relative;
      
      &::before,
      &::after {
        content: '';
        display: block;
        width: 24px;
        height: 3px;
        background: #fff;
        position: absolute;
        left: 0;
      }
      
      &::before {
        top: -8px;
      }
      
      &::after {
        bottom: -8px;
      }
    }
    
    /* Lista navigazione */
    .nav-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
      
      @media (max-width: 767px) {
        display: none;
        flex-direction: column;
        
        &.show {
          display: flex;
        }
      }
    }
    
    .nav-item {
      margin: 0;
    }
    
    .nav-link {
      color: #fff;
      text-decoration: none;
      padding: 0.5rem 1rem;
      display: block;
      border-radius: 0.25rem;
      font-weight: 500;
      transition: background-color 0.2s;
      
      /* Contrasto minimo 4.5:1 (WCAG AA) */
      &:hover {
        background-color: rgba(255, 255, 255, 0.1);
        text-decoration: none;
      }
      
      /* Focus visibile (WCAG 2.4.7) */
      &:focus {
        outline: 3px solid #fff;
        outline-offset: 2px;
        background-color: rgba(255, 255, 255, 0.1);
      }
      
      /* Link attivo */
      &.active {
        background-color: rgba(255, 255, 255, 0.2);
        font-weight: 700;
      }
    }
    
    /* Rispetta preferenze reduced motion */
    @media (prefers-reduced-motion: reduce) {
      .nav-link {
        transition: none;
      }
    }
  `]
})
export class HeaderComponent {
  // Signal per stato menu mobile (Angular 21)
  isMenuOpen = signal(false);
  isHomePage = signal(false);
  
  /**
   * Toggle menu per mobile
   */
  toggleMenu(): void {
    this.isMenuOpen.update(value => !value);
  }
}
