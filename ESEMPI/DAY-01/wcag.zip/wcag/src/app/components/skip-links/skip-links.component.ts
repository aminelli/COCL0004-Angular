/**
 * Componente Skip Links
 * 
 * WCAG 2.4.1 - Bypass Blocks
 * Fornisce link per saltare direttamente al contenuto principale e ad altre sezioni,
 * facilitando la navigazione da tastiera per screen reader e utenti con disabilità motorie.
 * 
 * I link sono nascosti visivamente ma appaiono al focus da tastiera.
 */

import { Component } from '@angular/core';

@Component({
  selector: 'app-skip-links',
  standalone: true,
  template: `
    <nav class="skip-links" aria-label="Links di navigazione rapida">
      <!-- Link al contenuto principale -->
      <a href="#main-content" class="skip-link">
        Salta al contenuto principale
      </a>
      
      <!-- Link alla navigazione principale -->
      <a href="#main-nav" class="skip-link">
        Salta alla navigazione
      </a>
      
      <!-- Link al footer -->
      <a href="#footer" class="skip-link">
        Salta al footer
      </a>
    </nav>
  `,
  styles: [`
    .skip-links {
      position: relative;
      z-index: 9999;
    }
    
    .skip-link {
      position: absolute;
      top: -100px;
      left: 0;
      background: #000;
      color: #fff;
      padding: 0.75rem 1rem;
      text-decoration: none;
      font-weight: 600;
      border-radius: 0 0 0.25rem 0;
      transition: top 0.3s;
      
      /* Focus visibile (WCAG 2.4.7) */
      &:focus {
        top: 0;
        outline: 3px solid #0d6efd;
        outline-offset: 2px;
      }
      
      /* Hover state */
      &:hover {
        background: #333;
      }
    }
    
    /* Rispetta le preferenze reduced-motion */
    @media (prefers-reduced-motion: reduce) {
      .skip-link {
        transition: none;
      }
    }
  `]
})
export class SkipLinksComponent {
  // Componente puramente presentazionale, nessuna logica necessaria
}
