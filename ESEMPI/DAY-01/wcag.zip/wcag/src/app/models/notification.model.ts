/**
 * Modello per Notifica
 * Interfaccia per messaggi di notifica e alert
 */

export interface Notification {
  id: string;
  type: NotificationType;
  message: string;
  title?: string;
  duration?: number;
  dismissible?: boolean;
  timestamp: Date;
}

/**
 * Tipi di notifica
 */
export enum NotificationType {
  Success = 'success',
  Info = 'info',
  Warning = 'warning',
  Error = 'error'
}

/**
 * Configurazione per live region
 */
export interface LiveRegionConfig {
  politeness: 'polite' | 'assertive' | 'off';
  atomic: boolean;
  relevant: 'additions' | 'removals' | 'text' | 'all';
}
