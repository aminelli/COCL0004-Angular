/**
 * Modello per Utente
 * Interfaccia TypeScript per rappresentare un utente
 */

export interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  createdAt?: Date;
  updatedAt?: Date;
}

/**
 * Ruoli utente disponibili
 */
export enum UserRole {
  Admin = 'admin',
  Editor = 'editor',
  Viewer = 'viewer'
}

/**
 * Stati utente
 */
export enum UserStatus {
  Active = 'active',
  Inactive = 'inactive',
  Pending = 'pending'
}

/**
 * Form data per registrazione utente
 */
export interface UserRegistrationForm {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  birthDate: string;
  country: string;
  terms: boolean;
  newsletter: boolean;
}
