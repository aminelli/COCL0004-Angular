/**
 * Announce Directive
 * 
 * Direttiva per annunciare cambiamenti agli screen reader.
 * Crea una live region temporanea per annunciare un messaggio.
 * 
 * Uso:
 * <button (click)="announce('Azione completata')">Click</button>
 * 
 * WCAG 4.1.3 - Status Messages
 */

import { Directive, ElementRef, Input } from '@angular/core';
import { LiveRegionService } from '../services/live-region.service';

@Directive({
  selector: '[appAnnounce]',
  standalone: true
})
export class AnnounceDirective {
  @Input() announceMessage = '';
  @Input() announceDelay = 0;
  @Input() announcePoliteness: 'polite' | 'assertive' = 'polite';
  
  constructor(
    private liveRegionService: LiveRegionService
  ) {}
  
  /**
   * Annuncia un messaggio agli screen reader
   */
  announce(message?: string): void {
    const msg = message || this.announceMessage;
    
    setTimeout(() => {
      if (this.announcePoliteness === 'assertive') {
        this.liveRegionService.announceAlert(msg);
      } else {
        this.liveRegionService.announce(msg);
      }
    }, this.announceDelay);
  }
}
