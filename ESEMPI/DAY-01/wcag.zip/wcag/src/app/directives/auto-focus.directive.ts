/**
 * Auto Focus Directive
 * 
 * Direttiva per gestire il focus automatico su un elemento.
 * Utile per modale, form dinamici, etc.
 * 
 * Uso:
 * <input appAutoFocus />
 * <button appAutoFocus [autoFocusDelay]="300">Click me</button>
 * 
 * WCAG 2.4.3 - Focus Order
 */

import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appAutoFocus]',
  standalone: true
})
export class AutoFocusDirective implements OnInit {
  // Delay opzionale prima di settare il focus (in ms)
  @Input() autoFocusDelay = 0;
  
  constructor(private elementRef: ElementRef<HTMLElement>) {}
  
  ngOnInit(): void {
    // Setta il focus sull'elemento dopo il delay specificato
    setTimeout(() => {
      this.elementRef.nativeElement.focus();
    }, this.autoFocusDelay);
  }
}
