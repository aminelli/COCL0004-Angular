/**
 * Configurazione principale dell'applicazione Angular 21
 *
 * Caratteristiche:
 * - Zoneless: usa provideExperimentalZonelessChangeDetection()
 * - Standalone: nessun NgModule
 * - SSR ready: configurato per Server-Side Rendering
 * - Router con preloading strategy
 */

// provideZonelessChangeDetection
import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import {
  provideRouter,
  withInMemoryScrolling,
  withPreloading,
  PreloadAllModules,
  withComponentInputBinding,
} from '@angular/router';

import { routes } from './app.routes';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
// import { provideAnimations } from '@angular/platform-browser/animations';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideClientHydration(withEventReplay()),
  ],
};
