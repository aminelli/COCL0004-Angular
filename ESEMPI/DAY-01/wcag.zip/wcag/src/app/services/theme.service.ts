/**
 * Theme Service
 * 
 * Servizio per gestire il tema dell'applicazione (chiaro/scuro)
 * con supporto per le preferenze utente e accessibilità.
 * 
 * Angular 21: Utilizza signals per la gestione dello stato del tema
 */

import { Injectable, signal, effect } from '@angular/core';

export type Theme = 'light' | 'dark' | 'auto';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  // Signal per il tema corrente
  private readonly STORAGE_KEY = 'wcag-app-theme';
  theme = signal<Theme>(this.getInitialTheme());
  
  // Signal computed per il tema effettivo (considera 'auto')
  effectiveTheme = signal<'light' | 'dark'>('light');
  
  constructor() {
    // Effect per applicare il tema quando cambia
    effect(() => {
      const theme = this.theme();
      this.applyTheme(theme);
    });
    
    // Ascolta i cambiamenti delle preferenze di sistema
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      mediaQuery.addEventListener('change', () => {
        if (this.theme() === 'auto') {
          this.applyTheme('auto');
        }
      });
    }
  }
  
  /**
   * Ottiene il tema iniziale da localStorage o dalle preferenze di sistema
   */
  private getInitialTheme(): Theme {
    if (typeof window === 'undefined') {
      return 'light';
    }
    
    const stored = localStorage.getItem(this.STORAGE_KEY) as Theme;
    return stored || 'auto';
  }
  
  /**
   * Imposta il tema
   */
  setTheme(theme: Theme): void {
    this.theme.set(theme);
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.STORAGE_KEY, theme);
    }
  }
  
  /**
   * Toggle tra tema chiaro e scuro
   */
  toggleTheme(): void {
    const current = this.effectiveTheme();
    this.setTheme(current === 'light' ? 'dark' : 'light');
  }
  
  /**
   * Applica il tema al documento
   */
  private applyTheme(theme: Theme): void {
    if (typeof window === 'undefined') return;
    
    let effectiveTheme: 'light' | 'dark' = 'light';
    
    if (theme === 'auto') {
      // Usa le preferenze di sistema
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      effectiveTheme = prefersDark ? 'dark' : 'light';
    } else {
      effectiveTheme = theme;
    }
    
    // Aggiorna il signal del tema effettivo
    this.effectiveTheme.set(effectiveTheme);
    
    // Applica la classe al body
    document.body.classList.remove('theme-light', 'theme-dark');
    document.body.classList.add(`theme-${effectiveTheme}`);
    
    // Imposta il color-scheme per elementi nativi del browser
    document.documentElement.style.colorScheme = effectiveTheme;
  }
  
  /**
   * Verifica se l'utente preferisce il contrasto elevato
   * (WCAG 1.4.6 - Contrast (Enhanced))
   */
  prefersHighContrast(): boolean {
    if (typeof window === 'undefined') return false;
    return window.matchMedia('(prefers-contrast: high)').matches;
  }
  
  /**
   * Verifica se l'utente preferisce la riduzione delle animazioni
   * (WCAG 2.3.3 - Animation from Interactions)
   */
  prefersReducedMotion(): boolean {
    if (typeof window === 'undefined') return false;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }
}
