/**
 * Focus Management Service
 * 
 * Servizio per gestire il focus programmaticamente in modo accessibile.
 * 
 * WCAG 2.4.3 - Focus Order
 * Il focus deve seguire un ordine logico e prevedibile.
 * Questo servizio aiuta a gestire il focus in situazioni dinamiche
 * come apertura/chiusura modali, navigazione, ecc.
 * 
 * Angular 21: Utilizza signals per tracciare lo stato del focus
 */

import { Injectable, signal, effect } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FocusManagementService {
  // Signal per tracciare l'elemento correntemente focalizzato
  private currentFocusedElement = signal<HTMLElement | null>(null);
  
  // Signal per tracciare l'ultimo elemento focalizzato prima di una modal
  private previousFocusedElement = signal<HTMLElement | null>(null);
  
  constructor() {
    // Effect per monitorare i cambiamenti di focus
    effect(() => {
      const element = this.currentFocusedElement();
      if (element) {
        console.log('Focus spostato su:', element);
      }
    });
  }
  
  /**
   * Sposta il focus su un elemento specifico
   * 
   * @param selector - Selettore CSS dell'elemento
   * @param delay - Delay opzionale in ms (utile per animazioni)
   */
  focusElement(selector: string, delay: number = 0): void {
    setTimeout(() => {
      const element = document.querySelector(selector) as HTMLElement;
      if (element) {
        // Rendi l'elemento focalizzabile se non lo è già
        if (!element.hasAttribute('tabindex')) {
          element.setAttribute('tabindex', '-1');
        }
        element.focus();
        this.currentFocusedElement.set(element);
      }
    }, delay);
  }
  
  /**
   * Salva il focus corrente (utile prima di aprire una modal)
   */
  saveFocus(): void {
    const activeElement = document.activeElement as HTMLElement;
    this.previousFocusedElement.set(activeElement);
  }
  
  /**
   * Ripristina il focus precedentemente salvato
   * (utile dopo la chiusura di una modal)
   */
  restoreFocus(): void {
    const element = this.previousFocusedElement();
    if (element) {
      element.focus();
      this.currentFocusedElement.set(element);
      this.previousFocusedElement.set(null);
    }
  }
  
  /**
   * Crea una focus trap per modali
   * Mantiene il focus all'interno di un container
   * 
   * @param container - Elemento container
   * @returns Funzione per rimuovere la trap
   */
  trapFocus(container: HTMLElement): () => void {
    // Ottieni tutti gli elementi focalizzabili nel container
    const focusableElements = container.querySelectorAll(
      'a[href], button:not([disabled]), textarea:not([disabled]), ' +
      'input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
    );
    
    const firstElement = focusableElements[0] as HTMLElement;
    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;
    
    // Handler per gestire Tab e Shift+Tab
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return;
      
      if (e.shiftKey) {
        // Shift + Tab
        if (document.activeElement === firstElement) {
          e.preventDefault();
          lastElement.focus();
        }
      } else {
        // Tab
        if (document.activeElement === lastElement) {
          e.preventDefault();
          firstElement.focus();
        }
      }
    };
    
    container.addEventListener('keydown', handleKeyDown);
    
    // Focus sul primo elemento
    firstElement?.focus();
    
    // Ritorna funzione per rimuovere la trap
    return () => {
      container.removeEventListener('keydown', handleKeyDown);
    };
  }
}
