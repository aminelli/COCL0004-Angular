/**
 * Live Region Service
 * 
 * Servizio per gestire messaggi dinamici per screen reader
 * utilizzando ARIA live regions.
 * 
 * Angular 21: Utilizza signals per la reattività invece di BehaviorSubject
 */

import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LiveRegionService {
  // Signal per messaggi polite (non urgenti)
  message = signal<string>('');
  
  // Signal per messaggi assertive (urgenti/errori)
  alertMessage = signal<string>('');
  
  /**
   * Annuncia un messaggio agli screen reader (politeness: polite)
   * Il messaggio viene letto dopo che l'utente finisce l'azione corrente
   * 
   * @param message - Il messaggio da annunciare
   * @param duration - Durata in ms prima di cancellare il messaggio (default: 3000)
   */
  announce(message: string, duration: number = 3000): void {
    this.message.set(message);
    
    // Cancella il messaggio dopo la durata specificata
    if (duration > 0) {
      setTimeout(() => {
        this.message.set('');
      }, duration);
    }
  }
  
  /**
   * Annuncia un messaggio di alert urgente (politeness: assertive)
   * Il messaggio interrompe lo screen reader e viene letto immediatamente
   * Usare solo per errori critici o messaggi molto importanti
   * 
   * @param message - Il messaggio di alert da annunciare
   * @param duration - Durata in ms prima di cancellare il messaggio (default: 5000)
   */
  announceAlert(message: string, duration: number = 5000): void {
    this.alertMessage.set(message);
    
    // Cancella il messaggio dopo la durata specificata
    if (duration > 0) {
      setTimeout(() => {
        this.alertMessage.set('');
      }, duration);
    }
  }
  
  /**
   * Cancella tutti i messaggi correnti
   */
  clear(): void {
    this.message.set('');
    this.alertMessage.set('');
  }
}
