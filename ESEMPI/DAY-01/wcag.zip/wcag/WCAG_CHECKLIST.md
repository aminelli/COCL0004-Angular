# Checklist WCAG 2.2 - Livello AA

Usa questa checklist per verificare la conformità WCAG del tuo progetto.

## 1. Percepibile

### 1.1 Alternative Testuali

- [ ] **1.1.1 (A)** Contenuti non testuali hanno alternative testuali
  - [ ] Immagini hanno attributo `alt` appropriato
  - [ ] Immagini decorative hanno `alt=""`
  - [ ] Immagini complesse hanno descrizioni dettagliate
  - [ ] Icone hanno label testuali (visibili o con `aria-label`)

### 1.2 Media Temporali

- [ ] **1.2.1 (A)** Audio e video hanno alternative
- [ ] **1.2.2 (A)** Video hanno sottotitoli
- [ ] **1.2.3 (A)** Video hanno descrizioni audio o trascrizioni
- [ ] **1.2.4 (AA)** Media in diretta hanno sottotitoli
- [ ] **1.2.5 (AA)** Video hanno descrizioni audio

### 1.3 Adattabile

- [ ] **1.3.1 (A)** Informazioni e relazioni trasmesse tramite markup
  - [ ] Headings utilizzati correttamente (h1-h6)
  - [ ] Liste usate per contenuti correlati
  - [ ] Tabelle hanno `<th>` e attributi `scope`
  - [ ] Form hanno `<label>` associati
- [ ] **1.3.2 (A)** Sequenza significativa mantenuta
- [ ] **1.3.3 (A)** Istruzioni non dipendono solo da caratteristiche sensoriali
- [ ] **1.3.4 (AA)** Orientamento non bloccato
- [ ] **1.3.5 (AA)** Input identificano il loro scopo (autocomplete)

### 1.4 Distinguibile

- [ ] **1.4.1 (A)** Colore non è l'unico mezzo per informazioni
- [ ] **1.4.2 (A)** Controllo su audio automatico
- [ ] **1.4.3 (AA)** Contrasto minimo 4.5:1 per testo normale
- [ ] **1.4.4 (AA)** Testo ridimensionabile fino al 200%
- [ ] **1.4.5 (AA)** Immagini di testo evitate (con eccezioni)
- [ ] **1.4.10 (AA)** Reflow senza scroll orizzontale a 320px
- [ ] **1.4.11 (AA)** Contrasto non-testuale minimo 3:1
- [ ] **1.4.12 (AA)** Spaziatura testo personalizzabile
- [ ] **1.4.13 (AA)** Contenuto su hover/focus accessibile

## 2. Utilizzabile

### 2.1 Accessibile da Tastiera

- [ ] **2.1.1 (A)** Tutta la funzionalità accessibile da tastiera
- [ ] **2.1.2 (A)** Nessuna trappola da tastiera
- [ ] **2.1.4 (A)** Scorciatoie da tastiera personalizzabili

### 2.2 Tempo Sufficiente

- [ ] **2.2.1 (A)** Limiti di tempo regolabili
- [ ] **2.2.2 (A)** Pausa, stop, nascondi per contenuto in movimento

### 2.3 Convulsioni

- [ ] **2.3.1 (A)** Nessun flash oltre 3 volte al secondo

### 2.4 Navigabile

- [ ] **2.4.1 (A)** Meccanismo per saltare blocchi (skip links)
- [ ] **2.4.2 (A)** Pagine hanno titoli descrittivi
- [ ] **2.4.3 (A)** Ordine di focus è logico e prevedibile
- [ ] **2.4.4 (A)** Scopo dei link comprensibile dal contesto
- [ ] **2.4.5 (AA)** Più modi per trovare pagine
- [ ] **2.4.6 (AA)** Headings e labels sono descrittivi
- [ ] **2.4.7 (AA)** Focus visibile sempre presente

### 2.5 Modalità di Input

- [ ] **2.5.1 (A)** Gesti complessi hanno alternative semplici
- [ ] **2.5.2 (A)** Cancellazione pointer events
- [ ] **2.5.3 (A)** Label nel nome accessibile
- [ ] **2.5.4 (A)** Attivazione tramite movimento ha controlli

## 3. Comprensibile

### 3.1 Leggibile

- [ ] **3.1.1 (A)** Lingua della pagina dichiarata (`<html lang="">`)
- [ ] **3.1.2 (AA)** Lingua di parti del contenuto dichiarata

### 3.2 Prevedibile

- [ ] **3.2.1 (A)** Focus non causa cambiamenti di contesto
- [ ] **3.2.2 (A)** Input non causa cambiamenti di contesto
- [ ] **3.2.3 (AA)** Navigazione consistente tra pagine
- [ ] **3.2.4 (AA)** Identificazione consistente di componenti

### 3.3 Assistenza Input

- [ ] **3.3.1 (A)** Errori identificati e descritti
- [ ] **3.3.2 (A)** Labels o istruzioni fornite
- [ ] **3.3.3 (AA)** Suggerimenti per correggere errori
- [ ] **3.3.4 (AA)** Prevenzione errori (conferma/verifica/annulla)

## 4. Robusto

### 4.1 Compatibile

- [ ] **4.1.2 (A)** Name, role, value per componenti UI
  - [ ] Elementi interattivi personalizzati hanno ruoli ARIA
  - [ ] Stati e proprietà comunicate tramite ARIA
  - [ ] Widget complessi hanno pattern ARIA appropriati
- [ ] **4.1.3 (AA)** Messaggi di stato annunciati
  - [ ] Live regions per contenuto dinamico
  - [ ] Alert per messaggi di errore
  - [ ] Status per conferme

## Controlli Aggiuntivi

### HTML Validity
- [ ] HTML valida (controlla con W3C Validator)
- [ ] Nessun ID duplicato
- [ ] Attributi usati correttamente

### ARIA Best Practices
- [ ] ARIA usato solo quando necessario
- [ ] HTML semantico privilegiato rispetto ad ARIA
- [ ] Ruoli ARIA non in conflitto con elementi nativi
- [ ] Stati ARIA aggiornati dinamicamente

### Responsive Design
- [ ] Viewport meta tag presente
- [ ] Layout responsive su tutti i dispositivi
- [ ] Touch targets minimo 44x44px
- [ ] Nessuno scroll orizzontale a 320px

### Performance
- [ ] Tempo di caricamento accettabile
- [ ] Nessun layout shift (CLS)
- [ ] Interattività rapida (FID/INP)

## Testing

- [ ] Testato con almeno uno screen reader
  - [ ] NVDA (Windows)
  - [ ] JAWS (Windows)  
  - [ ] VoiceOver (Mac/iOS)
  - [ ] TalkBack (Android)
- [ ] Testato navigazione completa da tastiera
- [ ] Testato con browser diverse
- [ ] Testato con zoom al 200%
- [ ] Verificato contrasti con tool automatici
- [ ] Eseguito audit Lighthouse
- [ ] Eseguito audit axe DevTools

## Note

- **Livello A**: Requisiti minimi
- **Livello AA**: Raccomandato per la maggior parte dei siti
- **Livello AAA**: Massimo livello (non sempre raggiungibile)

**Obiettivo di questo progetto: Conformità AA completa** ✅

---

Data ultimo controllo: __________  
Verificato da: __________  
Risultato: ☐ Conforme AA  ☐ Non conforme  ☐ Parzialmente conforme
