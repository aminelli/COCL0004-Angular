# WCAG Angular 21 - Progetto Dimostrativo

Progetto Angular 21 che dimostra le best practices per l'accessibilità WCAG 2.x.

## 🌟 Caratteristiche

- **Angular 21** con le ultime funzionalità
- **Zoneless** - Nessuna dipendenza da Zone.js per migliori performance
- **Server-Side Rendering (SSR)** - Pre-rendering per SEO e accessibilità
- **Standalone Components** - Niente NgModule, solo componenti standalone
- **Signals** - Gestione dello stato reattiva moderna
- **SCSS** - Styling avanzato e manutenibile
- **Bootstrap 5+** - Design responsive e accessibile
- **WCAG 2.x Compliant** - Conformità agli standard di accessibilità

## 📋 Standard WCAG 2.x Implementati

### Perceivable (Percepibile)
- ✅ Alternative testuali per contenuti non testuali
- ✅ Sottotitoli e trascrizioni per contenuti multimediali
- ✅ Contenuto adattabile e responsivo
- ✅ Contrasto colori adeguato (minimo 4.5:1)

### Operable (Utilizzabile)
- ✅ Navigazione completa da tastiera
- ✅ Skip links per navigazione rapida
- ✅ Focus visibile e gestione del focus
- ✅ Nessun limite di tempo forzato

### Understandable (Comprensibile)
- ✅ Lingua del documento dichiarata
- ✅ Etichette e istruzioni chiare
- ✅ Messaggi di errore descrittivi
- ✅ Navigazione consistente

### Robust (Robusto)
- ✅ Markup HTML5 semantico
- ✅ Compatibilità con screen reader
- ✅ Attributi ARIA appropriati
- ✅ Validazione HTML

## 🚀 Installazione

```bash
# Installa le dipendenze
npm install

# Avvia in modalità sviluppo
npm start

# Build per produzione con SSR
npm run build:ssr

# Serve l'applicazione SSR
npm run serve:ssr
```

## 📁 Struttura del Progetto

```
src/
├── app/
│   ├── components/          # Componenti riutilizzabili accessibili
│   │   ├── header/         # Header con navigazione accessibile
│   │   ├── footer/         # Footer accessibile
│   │   ├── skip-links/     # Skip navigation links
│   │   └── ...
│   ├── pages/              # Pagine dell'applicazione
│   │   ├── home/           # Home page
│   │   ├── forms/          # Esempi di form accessibili
│   │   ├── navigation/     # Esempi di navigazione
│   │   └── multimedia/     # Contenuti multimediali accessibili
│   ├── services/           # Servizi con signals
│   ├── directives/         # Direttive per accessibilità
│   └── models/             # Modelli TypeScript
├── styles/                 # SCSS globali
└── ...
```

## 🎯 Esempi Inclusi

1. **Form Accessibili** - Form con validazione, etichette e messaggi di errore
2. **Navigazione da Tastiera** - Skip links, focus management
3. **Contenuti Multimediali** - Video con sottotitoli, audio con trascrizioni
4. **Tabelle Accessibili** - Tabelle dati con headers appropriati
5. **Modali Accessibili** - Dialog con focus trap e gestione ESC
6. **Notifiche** - Live regions per screen reader
7. **Contrasto Colori** - Palette conforme WCAG AA/AAA

## 🔧 Tecnologie

- Angular 21
- TypeScript 5.6
- Bootstrap 5.3
- SCSS
- RxJS 7.8
- Signals (Angular)

## 📚 Risorse

- [WCAG 2.2 Guidelines](https://www.w3.org/WAI/WCAG22/quickref/)
- [Angular Accessibility](https://angular.dev/best-practices/a11y)
- [Bootstrap Accessibility](https://getbootstrap.com/docs/5.3/getting-started/accessibility/)

## 🧪 Testing Accessibilità

```bash
# Esegui i test
npm test

# Per testare manualmente:
# - Usa solo la tastiera (Tab, Enter, ESC, Arrow keys)
# - Usa uno screen reader (NVDA, JAWS, VoiceOver)
# - Controlla il contrasto con strumenti come axe DevTools
```

## 📝 Licenza

Progetto educativo per dimostrare le best practices WCAG in Angular 21.
