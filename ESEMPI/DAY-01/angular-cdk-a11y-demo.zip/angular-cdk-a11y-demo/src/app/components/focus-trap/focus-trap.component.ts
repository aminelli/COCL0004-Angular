// Componente Focus Trap Demo
// Dimostra l'uso di cdkTrapFocus per confinare il focus all'interno di un elemento

import { Component, signal } from '@angular/core';
import { CdkTrapFocus } from '@angular/cdk/a11y';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-focus-trap',
  imports: [CdkTrapFocus, CommonModule],
  templateUrl: './focus-trap.component.html',
  styleUrl: './focus-trap.component.scss'
})
export class FocusTrapComponent {
  // Signal per controllare lo stato del modal (aperto/chiuso)
  // Usando signals per la reattività senza zone.js
  isModalOpen = signal(false);
  
  // Signal per memorizzare il risultato dell'azione utente
  modalResult = signal<string>('');

  /**
   * Apre il modal e cattura il focus al suo interno
   */
  openModal(): void {
    this.isModalOpen.set(true);
    this.modalResult.set('');
  }

  /**
   * Chiude il modal e rilascia il focus
   * @param result - Il risultato dell'azione (confermato/annullato)
   */
  closeModal(result: string): void {
    this.isModalOpen.set(false);
    this.modalResult.set(result);
  }

  /**
   * Gestisce la chiusura con tasto ESC
   * @param event - Evento tastiera
   */
  handleEscape(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      this.closeModal('annullato premendo ESC');
    }
  }
}
