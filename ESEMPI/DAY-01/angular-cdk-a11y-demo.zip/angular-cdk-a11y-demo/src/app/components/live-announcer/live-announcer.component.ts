// Componente Live Announcer Demo
// Dimostra l'uso di LiveAnnouncer per annunciare messaggi agli screen reader

import { Component, signal } from '@angular/core';
import { LiveAnnouncer, AriaLivePoliteness } from '@angular/cdk/a11y';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-live-announcer',
  imports: [FormsModule, CommonModule],
  templateUrl: './live-announcer.component.html',
  styleUrl: './live-announcer.component.scss'
})
export class LiveAnnouncerComponent {
  // Signal per il messaggio da annunciare
  message = signal('');
  
  // Signal per la politeness level (assertive o polite)
  politeness = signal<AriaLivePoliteness>('polite');
  
  // Signal per lo storico degli annunci
  announcements = signal<Array<{text: string, politeness: AriaLivePoliteness, time: Date}>>([]);

  // Inject del servizio LiveAnnouncer
  constructor(private liveAnnouncer: LiveAnnouncer) {}

  /**
   * Annuncia il messaggio usando LiveAnnouncer
   * Il messaggio viene letto dagli screen reader senza interrompere l'utente
   */
  async announce(): Promise<void> {
    const msg = this.message();
    const pol = this.politeness();
    
    if (!msg.trim()) {
      return;
    }

    try {
      // Annuncia il messaggio con la politeness level selezionata
      await this.liveAnnouncer.announce(msg, pol);
      
      // Aggiungi allo storico
      const currentAnnouncements = this.announcements();
      this.announcements.set([
        {text: msg, politeness: pol, time: new Date()},
        ...currentAnnouncements
      ]);
      
      // Reset del campo messaggio
      this.message.set('');
    } catch (error) {
      console.error('Errore nell\'annuncio:', error);
    }
  }

  /**
   * Pulisce lo storico degli annunci
   */
  clearHistory(): void {
    this.announcements.set([]);
  }

  /**
   * Annuncia un messaggio predefinito
   */
  announcePreset(message: string, politeness: AriaLivePoliteness = 'polite'): void {
    this.message.set(message);
    this.politeness.set(politeness);
    this.announce();
  }
}
