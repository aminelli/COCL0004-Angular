// Componente List Key Manager Demo
// Dimostra l'uso di ActiveDescendantKeyManager per navigazione da tastiera in liste

import { Component, signal, QueryList, ViewChildren, AfterViewInit } from '@angular/core';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';
import { CommonModule } from '@angular/common';
import { ListItemComponent } from './list-item.component';

// Interfaccia per gli elementi della lista
interface MenuItem {
  id: number;
  label: string;
  description: string;
  icon: string;
  disabled?: boolean;
}

@Component({
  selector: 'app-list-key-manager',
  imports: [CommonModule, ListItemComponent],
  templateUrl: './list-key-manager.component.html',
  styleUrl: './list-key-manager.component.scss'
})
export class ListKeyManagerComponent implements AfterViewInit {
  // Items della lista
  menuItems: MenuItem[] = [
    { id: 1, label: 'Dashboard', description: 'Visualizza la dashboard principale', icon: '📊' },
    { id: 2, label: 'Profilo', description: 'Gestisci il tuo profilo utente', icon: '👤' },
    { id: 3, label: 'Impostazioni', description: 'Configura le impostazioni app', icon: '⚙️' },
    { id: 4, label: 'Notifiche', description: 'Visualizza le tue notifiche', icon: '🔔', disabled: true },
    { id: 5, label: 'Messaggi', description: 'Leggi i tuoi messaggi', icon: '💬' },
    { id: 6, label: 'Aiuto', description: 'Ottieni supporto e assistenza', icon: '❓' },
    { id: 7, label: 'Logout', description: 'Esci dall\'applicazione', icon: '🚪' }
  ];

  // Signal per l'elemento attivo
  activeItemIndex = signal<number | null>(null);
  
  // Signal per l'ultimo tasto premuto (per debug)
  lastKeyPressed = signal<string>('');
  
  // Signal per le statistiche
  stats = signal<string>('0/7 (6 abilitati)');

  // Riferimento ai componenti ListItem
  @ViewChildren(ListItemComponent) listItems!: QueryList<ListItemComponent>;

  // Key Manager per gestire la navigazione
  private keyManager!: ActiveDescendantKeyManager<ListItemComponent>;

  ngAfterViewInit(): void {
    // Inizializza il Key Manager
    this.keyManager = new ActiveDescendantKeyManager(this.listItems)
      .withWrap()                    // Wrap: da ultimo a primo e viceversa
      .withHomeAndEnd()              // Supporta Home/End
      .withTypeAhead();              // Supporta ricerca per digitazione

    // Ascolta i cambiamenti dell'item attivo
    this.keyManager.change.subscribe((index: number) => {
      this.activeItemIndex.set(index);
      this.updateStats();
    });
    
    // Aggiorna le statistiche iniziali
    this.updateStats();
  }

  /**
   * Gestisce gli eventi tastiera sulla lista
   * @param event - Evento tastiera
   */
  onKeydown(event: KeyboardEvent): void {
    this.lastKeyPressed.set(event.key);
    
    // Passa l'evento al KeyManager
    this.keyManager.onKeydown(event);

    // Enter per selezionare
    if (event.key === 'Enter') {
      const activeItem = this.keyManager.activeItem;
      if (activeItem && !activeItem.disabled) {
        this.selectItem(activeItem.menuItem);
        event.preventDefault();
      }
    }
  }

  /**
   * Seleziona un elemento della lista
   * @param item - Elemento selezionato
   */
  selectItem(item: MenuItem): void {
    if (!item.disabled) {
      alert(`Selezionato: ${item.label}\n${item.description}`);
    }
  }

  /**
   * Imposta il focus su un elemento specifico
   * @param index - Indice dell'elemento
   */
  setActiveItem(index: number): void {
    this.keyManager.setActiveItem(index);
    this.updateStats();
  }

  /**
   * Reset dell'elemento attivo
   */
  resetActiveItem(): void {
    this.keyManager.setActiveItem(-1);
    this.activeItemIndex.set(null);
    this.updateStats();
  }
  
  /**
   * Aggiorna le statistiche di navigazione
   */
  private updateStats(): void {
    if (!this.keyManager) {
      this.stats.set('0/7 (6 abilitati)');
      return;
    }
    
    const activeIndex = this.keyManager.activeItemIndex;
    const total = this.listItems.length;
    const enabled = this.menuItems.filter(item => !item.disabled).length;
    this.stats.set(`${activeIndex !== null && activeIndex >= 0 ? activeIndex + 1 : 0}/${total} (${enabled} abilitati)`);
  }

  /**
   * Ottieni le statistiche di navigazione
   */
  getStats(): string {
    return this.stats();
  }
}
