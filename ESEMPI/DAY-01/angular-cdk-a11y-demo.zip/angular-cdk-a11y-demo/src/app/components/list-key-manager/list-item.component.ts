// Componente List Item
// Rappresenta un singolo elemento in una lista gestita da ListKeyManager
// Implementa Highlightable per essere compatibile con ActiveDescendantKeyManager

import { Component, Input, HostBinding, HostListener } from '@angular/core';
import { Highlightable } from '@angular/cdk/a11y';

// Interfaccia MenuItem (duplicata per semplicità)
interface MenuItem {
  id: number;
  label: string;
  description: string;
  icon: string;
  disabled?: boolean;
}

@Component({
  selector: 'app-list-item',
  imports: [],
  template: `
    <div class="list-item-content">
      <span class="item-icon" aria-hidden="true">{{ menuItem.icon }}</span>
      <div class="item-text">
        <div class="item-label">{{ menuItem.label }}</div>
        <div class="item-description">{{ menuItem.description }}</div>
      </div>
      @if (menuItem.disabled) {
        <span class="badge bg-secondary ms-auto">Disabilitato</span>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      padding: 0.75rem 1rem;
      cursor: pointer;
      border-bottom: 1px solid #e9ecef;
      transition: all 0.2s ease;
      background-color: white;

      &:hover:not(.disabled) {
        background-color: #f8f9fa;
      }

      &.active {
        background-color: #e7f1ff;
        border-left: 4px solid #0d6efd;
        padding-left: calc(1rem - 4px);
      }

      &.disabled {
        opacity: 0.6;
        cursor: not-allowed;
      }
    }

    .list-item-content {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .item-icon {
      font-size: 1.5rem;
      flex-shrink: 0;
    }

    .item-text {
      flex-grow: 1;
    }

    .item-label {
      font-weight: 600;
      color: #212529;
    }

    .item-description {
      font-size: 0.875rem;
      color: #6c757d;
      margin-top: 0.25rem;
    }

    .badge {
      font-size: 0.75rem;
    }
  `]
})
export class ListItemComponent implements Highlightable {
  @Input() menuItem!: MenuItem;
  @Input() index!: number;

  // Proprietà per Highlightable
  private _isActive = false;

  // HostBinding per applicare la classe 'active' quando l'item è evidenziato
  @HostBinding('class.active')
  get isActive(): boolean {
    return this._isActive;
  }

  // HostBinding per applicare la classe 'disabled'
  @HostBinding('class.disabled')
  get isDisabled(): boolean {
    return this.menuItem?.disabled || false;
  }

  // HostBinding per l'ID dell'elemento (per aria-activedescendant)
  @HostBinding('id')
  get hostId(): string {
    return `list-item-${this.menuItem?.id}`;
  }

  // Proprietà disabled richiesta da Highlightable
  get disabled(): boolean {
    return this.menuItem?.disabled || false;
  }

  /**
   * Implementazione di Highlightable
   * Chiamato quando l'elemento viene evidenziato/de-evidenziato
   */
  setActiveStyles(): void {
    this._isActive = true;
  }

  /**
   * Implementazione di Highlightable
   * Chiamato quando l'elemento perde l'evidenziazione
   */
  setInactiveStyles(): void {
    this._isActive = false;
  }

  /**
   * Metodo opzionale per Highlightable
   * Restituisce la label per il typeahead
   */
  getLabel(): string {
    return this.menuItem?.label || '';
  }
}
