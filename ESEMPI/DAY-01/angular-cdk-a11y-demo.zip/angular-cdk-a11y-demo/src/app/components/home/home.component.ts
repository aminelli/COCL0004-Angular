// Componente Home - Pagina principale dell'applicazione
// Mostra una panoramica delle funzionalit\u00e0 di Angular CDK A11y

import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  // Array di demo disponibili con descrizioni
  demos = [
    {
      title: 'Focus Trap',
      route: '/focus-trap',
      description: 'Cattura il focus all\'interno di un elemento specifico. Utile per modali e dialog accessibili.',
      icon: '🎯'
    },
    {
      title: 'Live Announcer',
      route: '/live-announcer',
      description: 'Annuncia dinamicamente messaggi agli screen reader senza interrompere il flusso dell\'utente.',
      icon: '📢'
    },
    {
      title: 'Focus Monitor',
      route: '/focus-monitor',
      description: 'Monitora e gestisce il focus degli elementi, distinguendo tra mouse, tastiera e touch.',
      icon: '👁️'
    },
    {
      title: 'List Key Manager',
      route: '/list-key-manager',
      description: 'Gestisce la navigazione da tastiera in liste di elementi (frecce, home, end, ecc.).',
      icon: '⌨️'
    }
  ];
}
