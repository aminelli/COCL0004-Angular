// Componente Focus Monitor Demo
// Dimostra l'uso di FocusMonitor per rilevare e gestire il focus

import { Component, signal, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { FocusMonitor, FocusOrigin } from '@angular/cdk/a11y';
import { CommonModule } from '@angular/common';

// Interfaccia per tracciare gli eventi di focus
interface FocusEvent {
  element: string;
  origin: FocusOrigin;
  time: Date;
}

@Component({
  selector: 'app-focus-monitor',
  imports: [CommonModule],
  templateUrl: './focus-monitor.component.html',
  styleUrl: './focus-monitor.component.scss'
})
export class FocusMonitorComponent implements AfterViewInit, OnDestroy {
  // Signal per l'origine del focus corrente
  currentFocusOrigin = signal<FocusOrigin>(null);
  
  // Signal per lo storico degli eventi di focus
  focusHistory = signal<FocusEvent[]>([]);
  
  // Signal per l'elemento attualmente in focus
  currentFocusedElement = signal<string>('nessuno');

  // Riferimenti agli elementi da monitorare
  @ViewChild('button1') button1!: ElementRef<HTMLButtonElement>;
  @ViewChild('button2') button2!: ElementRef<HTMLButtonElement>;
  @ViewChild('input1') input1!: ElementRef<HTMLInputElement>;
  @ViewChild('input2') input2!: ElementRef<HTMLInputElement>;
  @ViewChild('link1') link1!: ElementRef<HTMLAnchorElement>;

  constructor(private focusMonitor: FocusMonitor) {}

  ngAfterViewInit(): void {
    // Monitora ogni elemento e traccia gli eventi di focus
    this.monitorElement(this.button1, 'Pulsante 1');
    this.monitorElement(this.button2, 'Pulsante 2');
    this.monitorElement(this.input1, 'Input 1');
    this.monitorElement(this.input2, 'Input 2');
    this.monitorElement(this.link1, 'Link');
  }

  /**
   * Monitora un elemento e traccia gli eventi di focus
   * @param elementRef - Riferimento all'elemento da monitorare
   * @param label - Etichetta descrittiva dell'elemento
   */
  private monitorElement(elementRef: ElementRef, label: string): void {
    this.focusMonitor
      .monitor(elementRef, true) // true = checkChildren
      .subscribe((origin: FocusOrigin) => {
        if (origin) {
          // Elemento ha ricevuto il focus
          this.currentFocusOrigin.set(origin);
          this.currentFocusedElement.set(label);
          
          // Aggiungi all'istorico
          const history = this.focusHistory();
          this.focusHistory.set([
            { element: label, origin, time: new Date() },
            ...history.slice(0, 9) // Mantieni solo gli ultimi 10
          ]);
        } else {
          // Elemento ha perso il focus
          if (this.currentFocusedElement() === label) {
            this.currentFocusedElement.set('nessuno');
            this.currentFocusOrigin.set(null);
          }
        }
      });
  }

  /**
   * Restituisce un'icona basata sull'origine del focus
   */
  getOriginIcon(origin: FocusOrigin): string {
    switch (origin) {
      case 'mouse': return '🖱️';
      case 'keyboard': return '⌨️';
      case 'touch': return '👆';
      case 'program': return '💻';
      default: return '❓';
    }
  }

  /**
   * Restituisce una descrizione dell'origine del focus
   */
  getOriginDescription(origin: FocusOrigin): string {
    switch (origin) {
      case 'mouse': return 'Click del mouse';
      case 'keyboard': return 'Navigazione da tastiera (Tab)';
      case 'touch': return 'Touch su dispositivo mobile';
      case 'program': return 'Focus impostato programmaticamente';
      default: return 'Nessun focus';
    }
  }

  /**
   * Imposta il focus programmaticamente su un elemento
   */
  focusProgrammatically(element: 'button1' | 'button2' | 'input1' | 'input2'): void {
    const elementMap = {
      button1: this.button1,
      button2: this.button2,
      input1: this.input1,
      input2: this.input2
    };
    
    // Usa focusVia per impostare il focus con origine 'program'
    this.focusMonitor.focusVia(elementMap[element], 'program');
  }

  /**
   * Pulisce lo storico
   */
  clearHistory(): void {
    this.focusHistory.set([]);
  }

  ngOnDestroy(): void {
    // Importante: stopMonitoring per evitare memory leaks
    this.focusMonitor.stopMonitoring(this.button1);
    this.focusMonitor.stopMonitoring(this.button2);
    this.focusMonitor.stopMonitoring(this.input1);
    this.focusMonitor.stopMonitoring(this.input2);
    this.focusMonitor.stopMonitoring(this.link1);
  }
}
