import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';

// Configurazione dell'applicazione Angular 21
// - provideZonelessChangeDetection: abilita la detection zoneless (Angular 21)
// - provideRouter: fornisce il routing dell'applicazione
// - provideClientHydration: abilita l'idratazione client per SSR con replay degli eventi
export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(), // Abilita change detection senza zone.js
    provideRouter(routes), 
    provideClientHydration(withEventReplay())
  ]
};
