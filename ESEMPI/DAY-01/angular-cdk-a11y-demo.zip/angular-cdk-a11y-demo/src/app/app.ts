// Componente principale dell'applicazione Angular 21
// Usa standalone components, signals e importa i moduli necessari

import { Component, signal } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  // Standalone component - non richiede NgModule
  imports: [
    RouterOutlet,      // Permette il rendering delle routes
    RouterLink,        // Direttiva per navigare tra le routes
    RouterLinkActive   // Applica classi CSS ai link attivi
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  // Signal per gestire il titolo dell'applicazione (reattività senza zone.js)
  protected readonly title = signal('CDK A11y Angular 21');
}
