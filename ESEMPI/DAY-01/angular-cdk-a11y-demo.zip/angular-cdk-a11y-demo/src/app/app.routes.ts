// Configurazione delle routes dell'applicazione
// Usa lazy loading per ottimizzare le performance

import { Routes } from '@angular/router';

export const routes: Routes = [
  // Route principale - Home
  {
    path: '',
    loadComponent: () => import('./components/home/home.component')
      .then(m => m.HomeComponent),
    title: 'Home - Angular CDK A11y Demo'
  },
  
  // Route per Focus Trap Demo
  {
    path: 'focus-trap',
    loadComponent: () => import('./components/focus-trap/focus-trap.component')
      .then(m => m.FocusTrapComponent),
    title: 'Focus Trap - Angular CDK A11y Demo'
  },
  
  // Route per Live Announcer Demo
  {
    path: 'live-announcer',
    loadComponent: () => import('./components/live-announcer/live-announcer.component')
      .then(m => m.LiveAnnouncerComponent),
    title: 'Live Announcer - Angular CDK A11y Demo'
  },
  
  // Route per Focus Monitor Demo
  {
    path: 'focus-monitor',
    loadComponent: () => import('./components/focus-monitor/focus-monitor.component')
      .then(m => m.FocusMonitorComponent),
    title: 'Focus Monitor - Angular CDK A11y Demo'
  },
  
  // Route per List Key Manager Demo
  {
    path: 'list-key-manager',
    loadComponent: () => import('./components/list-key-manager/list-key-manager.component')
      .then(m => m.ListKeyManagerComponent),
    title: 'List Key Manager - Angular CDK A11y Demo'
  },
  
  // Wildcard route - redirect a home se la route non esiste
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full'
  }
];
