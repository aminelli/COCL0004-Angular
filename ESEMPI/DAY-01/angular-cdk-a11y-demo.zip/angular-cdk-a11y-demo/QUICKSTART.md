# Guida Rapida - Angular CDK A11y Demo

## 🚀 Avvio Rapido

### 1. Verifica Installazione Dipendenze

Le dipendenze sono già state installate durante la creazione del progetto.
Se necessario, esegui:

```bash
npm install
```

### 2. Avvia l'Applicazione

```bash
npm start
```

oppure

```bash
ng serve
```

L'applicazione sarà disponibile su `http://localhost:4200`

### 3. Avvia con Server-Side Rendering (SSR)

```bash
ng serve --configuration=development
```

## 📋 Componenti Disponibili

L'applicazione include 5 pagine principali:

1. **Home** (`/`) - Panoramica generale delle funzionalità
2. **Focus Trap** (`/focus-trap`) - Demo del focus trapping nei modal
3. **Live Announcer** (`/live-announcer`) - Demo degli annunci per screen reader
4. **Focus Monitor** (`/focus-monitor`) - Demo del monitoraggio del focus
5. **List Key Manager** (`/list-key-manager`) - Demo della navigazione da tastiera

## 🧪 Test delle Funzionalità

### Focus Trap
- Apri il modal
- Premi `Tab` per navigare tra i campi
- Nota come il focus rimane confinato nel modal
- Premi `ESC` per chiudere

### Live Announcer
- Crea annunci personalizzati
- Usa i pulsanti predefiniti
- Testa con uno screen reader (NVDA su Windows, VoiceOver su Mac)

### Focus Monitor
- Clicca sui pulsanti con il mouse
- Naviga con `Tab` usando la tastiera
- Usa i pulsanti "Focus Programmatico"
- Osserva come viene rilevata l'origine del focus

### List Key Manager
- Clicca sulla lista per darle focus
- Usa le frecce `↑` `↓` per navigare
- Premi `Home` o `End`
- Digita la prima lettera di un elemento (es. "D" per Dashboard)
- Premi `Enter` per selezionare

## 🔍 Verifica Accessibilità

### Con Screen Reader

**Windows (NVDA - Gratuito):**
1. Scarica NVDA da https://www.nvaccess.org/
2. Avvia NVDA
3. Naviga l'applicazione

**macOS (VoiceOver - Integrato):**
1. Premi `Cmd + F5` per avviare VoiceOver
2. Naviga l'applicazione con `Ctrl + Option + frecce`

### Con DevTools

1. Apri Chrome DevTools (`F12`)
2. Vai su "Lighthouse"
3. Seleziona "Accessibility"
4. Esegui l'audit

## 🛠️ Build di Produzione

```bash
# Build ottimizzata
npm run build

# I file compilati saranno in dist/
```

## 📦 Struttura delle Funzionalità

```
Funzionalità A11y Implementate:
├── Focus Management
│   ├── CdkTrapFocus (Focus Trap)
│   └── FocusMonitor (Focus Origin Detection)
├── Screen Reader Support
│   └── LiveAnnouncer (Dynamic Announcements)
└── Keyboard Navigation
    └── ActiveDescendantKeyManager (List Navigation)
```

## ⚡ Caratteristiche Tecniche

- **Zoneless**: Nessuna dipendenza da zone.js
- **Signals**: Reattività moderna
- **Standalone**: Nessun NgModule
- **SSR Ready**: Server-Side Rendering configurato
- **TypeScript Strict**: Type-safe
- **SCSS**: Stili avanzati con preprocessore

## 🎯 Best Practices Dimostrate

1. **Semantic HTML**: Uso corretto di elementi HTML nativi
2. **ARIA Attributes**: Implementazione corretta di ARIA
3. **Keyboard Navigation**: Accessibilità completa da tastiera
4. **Focus Management**: Gestione professionale del focus
5. **Screen Reader**: Supporto completo per tecnologie assistive

## 📚 Cosa Imparerai

- Come usare `cdkTrapFocus` per modal accessibili
- Come annunciare messaggi con `LiveAnnouncer`
- Come monitorare il focus con `FocusMonitor`
- Come gestire liste navigabili con `ListKeyManager`
- Pattern di accessibilità moderni in Angular 21
- Uso di Signals per state management
- Architettura Standalone Components

## 🤔 Domande Comuni

**Q: L'applicazione funziona senza screen reader?**
A: Sì, tutte le funzionalità sono visibili e utilizzabili normalmente. Gli screen reader sono opzionali per testare l'accessibilità.

**Q: Posso usare questo codice in produzione?**
A: Sì, il codice è production-ready e segue le best practices di Angular 21.

**Q: Come testiamo le funzionalità di accessibilità?**
A: Usa screen reader (NVDA/VoiceOver), naviga solo con tastiera, usa Lighthouse DevTools, e verifica con utenti reali.

---

**Buon divertimento nell'esplorare Angular CDK A11y! 🎉**
