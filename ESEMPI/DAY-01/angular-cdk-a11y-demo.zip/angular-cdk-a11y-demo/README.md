# Angular CDK A11y Demo - Angular 21

## 📋 Descrizione

Applicazione demo completa che dimostra l'uso delle funzionalità di **Angular CDK A11y (Accessibility)** in Angular 21, seguendo le best practices più recenti.

Questo progetto è stato creato per insegnare come utilizzare Angular CDK A11y per rendere le applicazioni web più accessibili a tutti gli utenti, inclusi quelli che utilizzano tecnologie assistive come screen reader.

## ✨ Caratteristiche Angular 21

Questo progetto utilizza tutte le nuove funzionalità di Angular 21:

- ✅ **Zoneless**: Change detection senza zone.js per performance ottimali
- ✅ **Signals**: Gestione dello stato reattiva e performante
- ✅ **Standalone Components**: Architettura modulare senza NgModule
- ✅ **Server-Side Rendering (SSR)**: SEO e performance migliorate
- ✅ **SCSS**: Preprocessore CSS per stili avanzati
- ✅ **Bootstrap 5**: Design responsive e mobile-first

## 🎯 Funzionalità Demo

### 1. **Focus Trap**
Cattura il focus all'interno di un elemento specifico (es. modal, dialog).
- Navigazione con Tab/Shift+Tab confinata
- Auto-capture del focus
- Gestione ESC per chiusura
- Esempi pratici di modal accessibili

### 2. **Live Announcer**
Annuncia messaggi dinamici agli screen reader senza interrompere l'utente.
- Livelli di priorità: `polite` e `assertive`
- Feedback su azioni AJAX
- Notifiche accessibili
- Storico annunci

### 3. **Focus Monitor**
Monitora l'origine del focus (mouse, tastiera, touch, programmatico).
- Rilevamento automatico del metodo di input
- Stili condizionali basati sull'origine
- Tracciamento eventi per analytics
- API `focusVia()` per focus programmatico

### 4. **List Key Manager**
Gestisce la navigazione da tastiera in liste di elementi.
- Supporto frecce ↑↓, Home, End
- Typeahead (ricerca digitando)
- Wrap automatico (circolare)
- Skip elementi disabilitati
- Compatibilità con `aria-activedescendant`

## 🚀 Quick Start

### Prerequisiti

- Node.js 18+ 
- npm 9+
- Angular CLI 21+

### Installazione e Avvio

```bash
# Naviga nella directory del progetto
cd angular-cdk-a11y-demo

# Installa le dipendenze (se non già fatto)
npm install

# Avvia il server di sviluppo
ng serve

# Oppure con SSR
ng serve --configuration=development
```

L'applicazione sarà disponibile su `http://localhost:4200`

### Build

```bash
# Build di produzione
ng build

# Build SSR
ng build
```

## 📁 Struttura del Progetto

```
src/
├── app/
│   ├── components/
│   │   ├── home/                    # Pagina principale
│   │   ├── focus-trap/              # Demo Focus Trap
│   │   ├── live-announcer/          # Demo Live Announcer
│   │   ├── focus-monitor/           # Demo Focus Monitor
│   │   └── list-key-manager/        # Demo List Key Manager
│   │       └── list-item.component.ts  # Item component per la lista
│   ├── app.ts                       # Componente root
│   ├── app.html                     # Template principale
│   ├── app.scss                     # Stili principali
│   ├── app.config.ts                # Configurazione app (zoneless)
│   └── app.routes.ts                # Configurazione routes
├── styles.scss                      # Stili globali + Bootstrap
└── main.ts                          # Entry point
```

## 🎨 Tecnologie Utilizzate

### Core
- **Angular 21**: Framework principale
- **TypeScript**: Linguaggio di programmazione
- **RxJS**: Programmazione reattiva

### UI & Styling
- **Bootstrap 5**: Framework CSS responsive
- **SCSS**: Preprocessore CSS

### Accessibilità
- **@angular/cdk/a11y**: Toolkit accessibilità
  - `CdkTrapFocus`: Focus trapping
  - `LiveAnnouncer`: Annunci live
  - `FocusMonitor`: Monitoraggio focus
  - `ActiveDescendantKeyManager`: Navigazione tastiera

## 📚 Concetti Chiave

### Zoneless Change Detection

```typescript
// app.config.ts
export const appConfig: ApplicationConfig = {
  providers: [
    provideExperimentalZonelessChangeDetection(), // ✨ Zoneless!
    // ...
  ]
};
```

### Signals per State Management

```typescript
// Uso dei signals invece di variabili tradizionali
isModalOpen = signal(false);       // Creazione
this.isModalOpen.set(true);        // Aggiornamento
const value = this.isModalOpen();  // Lettura
```

### Standalone Components

```typescript
@Component({
  selector: 'app-home',
  imports: [RouterLink, CommonModule], // ✨ Import diretti, no NgModule
  // ...
})
export class HomeComponent { }
```

## 🌐 Accessibilità (A11y)

### Best Practices Implementate

1. **Supporto Screen Reader**: Tutti i componenti sono testabili con screen reader
2. **Navigazione da Tastiera**: Tutti gli elementi interattivi sono accessibili via tastiera
3. **ARIA Attributes**: Uso corretto di role, aria-label, aria-live, ecc.
4. **Focus Visibile**: Outline chiaro per la navigazione da tastiera
5. **Contrasto Colori**: Rispetto delle linee guida WCAG
6. **Motion Reduce**: Rispetto della preferenza `prefers-reduced-motion`

### Test con Screen Reader

Per testare con screen reader:

- **Windows**: NVDA (gratuito) o JAWS
- **macOS**: VoiceOver (integrato)
- **Linux**: Orca

## 🧪 Testing

```bash
# Unit tests
ng test

# E2E tests (se configurati)
ng e2e
```

## 📖 Risorse Utili

### Documentazione
- [Angular CDK A11y](https://material.angular.io/cdk/a11y/overview)
- [Angular 21 Documentation](https://angular.dev)
- [WCAG Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
- [ARIA Authoring Practices](https://www.w3.org/WAI/ARIA/apg/)

### Tools
- [axe DevTools](https://www.deque.com/axe/devtools/) - Test accessibilità
- [WAVE](https://wave.webaim.org/) - Valutazione accessibilità
- [Lighthouse](https://developers.google.com/web/tools/lighthouse) - Audit performance e a11y

## 🤝 Contribuire

Questo è un progetto educativo. Sentiti libero di esplorare, modificare e migliorare il codice.

## 📄 Licenza

Questo progetto è fornito a scopo educativo.

## 👨‍💻 Autore

Progetto creato come demo educativa per Angular 21 e Angular CDK A11y.

---

**Nota**: Questo progetto è ottimizzato per Angular 21 e utilizza solo API e pattern non deprecati.

